-- SceneSpeak per-account snapshot sync. Run this once in Supabase Dashboard → SQL Editor.
-- The browser must use the project's publishable/anon key, never service_role.

create table if not exists public.scenespeak_cloud_backups (
  user_id uuid primary key references auth.users (id) on delete cascade,
  backup jsonb not null,
  updated_at timestamptz not null default now(),
  constraint scenespeak_backup_is_object check (jsonb_typeof(backup) = 'object')
);

alter table public.scenespeak_cloud_backups enable row level security;

-- Keep grants narrow: signed-in users may operate only on their own row via policies.
revoke all on table public.scenespeak_cloud_backups from anon, authenticated;
grant select, insert, update, delete on table public.scenespeak_cloud_backups to authenticated;

drop policy if exists "Users read their own SceneSpeak backup" on public.scenespeak_cloud_backups;
create policy "Users read their own SceneSpeak backup"
  on public.scenespeak_cloud_backups for select to authenticated
  using ((select auth.uid()) = user_id);

drop policy if exists "Users insert their own SceneSpeak backup" on public.scenespeak_cloud_backups;
create policy "Users insert their own SceneSpeak backup"
  on public.scenespeak_cloud_backups for insert to authenticated
  with check ((select auth.uid()) = user_id);

drop policy if exists "Users update their own SceneSpeak backup" on public.scenespeak_cloud_backups;
create policy "Users update their own SceneSpeak backup"
  on public.scenespeak_cloud_backups for update to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

drop policy if exists "Users delete their own SceneSpeak backup" on public.scenespeak_cloud_backups;
create policy "Users delete their own SceneSpeak backup"
  on public.scenespeak_cloud_backups for delete to authenticated
  using ((select auth.uid()) = user_id);
