# SceneSpeak — Japanese speaking practice

**Real situations. Real conversations. Faster progress.**

SceneSpeak is a mobile-first, local-first Japanese learning PWA inspired by the supplied mockup. It is a personal-use course, not a commercial multi-user service. Curated practice is intended to work without an account, backend, or Gemini key.

## Included in this project

- React + TypeScript + Vite application shell, responsive layout, install guidance, PWA manifest/service-worker setup, Netlify config, and Capacitor 8 configuration.
- Four main tabs: Home, Scenes, Memory, and Profile/settings. Routes also cover onboarding, active missions, quick review, phrase detail, kana, grammar, listening, speaking, AI scene generation, and AI roleplay.
- Twelve ordered learning modules with 36 curated playable missions; a shared lesson player covers contextual introduction, synthesized audio, listening, guided recall, microphone-based speaking, transcript review, context transfer, result summary, and local resume state.
- A structured phrase bank with 267 phrase/sentence-pattern records, plus 108 scene-distributed dialogue variants (three per mission), with readings, romanization, meanings, usage notes, patterns, tags, and examples. The seed data is generated from curated common patterns and item lists plus individually authored core phrases. Content is beginner-focused, but it has not been independently reviewed by a native-speaker editor.
- Hiragana and katakana practice, including voiced/semi-voiced families, contracted sounds, small っ, and long-vowel mark coverage; grammar explainers and quick retrieval checks.
- IndexedDB-backed profiles, progress observations, sessions, review due dates, favorites, notes, saved AI scenes, kana/grammar results, event history, and active roleplay state.
- Four separate skill observations (recognition, listening, recall, transfer), a deterministic review heuristic, and a Vitest suite for the domain rules. A revealed answer does not count as successful recall.
- Optional Gemini workflows: structured scene generation, a multi-turn AI conversation partner, and tutor explanations. The UI validates AI responses and keeps AI output separate from trusted curated curriculum until saved.
- JSON full backup/restore, phrasebook CSV export, session-event export, storage health counts, and confirmed clear-data action. API keys are excluded from backups. Optional Supabase Auth + user-scoped cloud snapshots allow signed-in users to move learning data between devices without a custom server.
- Light, dark, and system theme preferences; daily quests, estimated study-time progress, XP/levels, streak indicators, and a purpose-based learning-path planner with selectable goal timelines. These game metrics encourage consistency and are not proficiency certification.
- Netlify SPA fallback, basic security headers, service-worker precache for bundled assets, and platform-specific installation help.

## Prerequisites

- Node.js 22 LTS/current (Node 20+ is required by the official Google GenAI JavaScript SDK; this package uses modern Vite/Capacitor versions).
- npm.
- Android Studio + Android SDK + a compatible JDK only if you want to build an APK.

## Run locally

```bash
npm install
npm run dev
```

Vite will print the local development URL, normally `http://localhost:5173`.

## Validate and build

```bash
npm run typecheck
npm test
npm run build
npm run preview
```

`npm run build` outputs static deployable assets to `dist/`. The Vitest suite covers review scheduling, progress scoring, answer-reveal semantics, curriculum reference integrity, kana families, and backup schema validation.

## Netlify deployment

1. Put this project in a Git repository and push it to a provider supported by Netlify.
2. In Netlify, import that repository.
3. Use build command `npm run build` and publish directory `dist`. `netlify.toml` declares both settings and a rewrite to `index.html` for client-side routes.
4. No Gemini environment variable is required for the curated app or BYOK browser mode.
5. Confirm the production URL is served over HTTPS, test direct visits to `/memory`, `/profile`, and `/mission/m4-s1`, and reload each route.

This is a static client application. A public Netlify URL is not private merely because it is for personal use. Configure separate Netlify access control if you do not want other people who know the URL to load it.

## PWA installation

- **Android / Chromium:** Open the HTTPS site. Use the app's Install app button where the browser offers `beforeinstallprompt`, or open the browser menu and choose Install app / Add to Home screen.
- **iPhone / iPad:** Open the HTTPS site in Safari, tap Share, then Add to Home Screen. iOS does not install an Android APK.
- The service worker is configured to precache bundled static assets and avoid runtime caching for Gemini requests. Confirm offline behavior after a successful production/PWA load; first install and the first fetch of assets require a connection.

PWA PNG icons are included in `public/icons/`. The source of the app icon is `public/icons/scenespeak.svg`.

## Gemini BYOK setup and security

1. Create/manage a Gemini API key in [Google AI Studio](https://aistudio.google.com/apikey).
2. Open Profile → AI provider, paste the key, choose a model, and use **Test connection**. The app only enables actual AI calls when a runtime key is available.
3. The key is session-only by default. The **Remember on this device** checkbox explicitly opts into local browser storage. **Remove key** clears both session and remembered copies.
4. The requested model IDs are centralized in `src/services/ai.ts`:
   - `gemini-4-argon` — Gemini 4 Argon (stable)
   - `gemini-3.1-pro-preview` — Gemini 3.1 Pro (preview)
   - `gemini-3.8-flash` — Gemini 3.8 Flash (stable; default)
5. The official Google SDK is `@google/genai`. See [Google's SDK guide](https://ai.google.dev/gemini-api/docs/libraries), [model list](https://ai.google.dev/gemini-api/docs/models), [key safety guide](https://ai.google.dev/gemini-api/docs/api-key), and [pricing](https://ai.google.dev/gemini-api/docs/pricing).

**Security caveat:** this direct browser-to-Google path deliberately trades API-key security for a single-user setup. Browser extensions, DevTools, injected scripts, or a compromised dependency may be able to read an active key. Browser storage is not an encrypted vault. Google controls rate limits, model access, and billing. Do not use a sensitive production key in this public-client mode. A more secure public release should use a server-side proxy with a server-owned key, not forward a user's personal key through Netlify.

Gemini failures (invalid key, quota/rate limit, missing model access, permission problems, timeout, malformed JSON, network/offline) are mapped to actionable messages. AI calls do not control deterministic progress scoring, scheduling, or durable local storage. If no key is present, use the curated course. No live Gemini connection test can pass without the user's key.

## Android APK pathway

Capacitor settings are in `capacitor.config.ts`; Android build scripts are in `package.json`.

On a computer with Android Studio, Android SDK and JDK installed:

```bash
npm install
npm run build
npx cap add android       # first time only
npx cap sync android
npx cap open android
```

In Android Studio, open the `android/` project, let Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. A debug APK is for personal installation/testing. For a release APK, create and protect your own signing keystore/passwords outside version control. Alternatively, when the command-line SDK is configured, run:

```bash
npm run android:apk
```

This environment did not have `ANDROID_HOME` or `ANDROID_SDK_ROOT` set when inspected. Therefore no APK is claimed as built here. The actual Android platform project should be generated with `npx cap add android` after dependency installation on a suitable machine; signing credentials are intentionally not included.

## Local data, backup, restore, and reset

- Curated learning works without an account. Progress and settings are stored in IndexedDB in this browser/app installation by default.
- Use Profile → Local data & backup to download a versioned JSON backup, export the phrasebook to CSV, export session event history, or restore a backup with validation, a count preview, and merge/replace choice.
- API keys are never exported. Restoring settings ignores key-shaped values and does not import a Gemini key.
- Clear all app data requires confirmation. Clearing app/browser data or uninstalling can remove local progress; download a backup before reinstalling or changing devices.
- Optional Supabase cloud sync is available after a one-time configuration. See [`docs/supabase-cloud-sync.md`](docs/supabase-cloud-sync.md). It uses Supabase Auth and a row-level-security-protected JSON snapshot, so there is no custom server to operate. Sync is deliberately user-triggered: upload from the device with the newest data, then sign in on the second device and merge from cloud. It is not continuous background sync; review the cloud snapshot behavior before each upload.

## Enhanced study paths: speaking, Minna companion, and JLPT N5

### Real microphone speaking and Memory-to-Mouth

Open **Speak** from Home or `/speaking` to practise a short intention in a real microphone round. The browser asks for microphone permission only when recording begins, records a clip for up to 15 seconds, releases the microphone when recording stops or the screen unmounts, and offers playback/cancel/re-record. After the explicit **Send audio for transcript** action, the short recording is sent directly to Google for Japanese transcription using Gemini 3.8 Flash's documented inline-audio path. The returned transcript is shown in an editable field; only after **Confirm transcript & get feedback** does the selected Gemini model evaluate communication, one useful grammar/word-choice improvement, a natural alternative and a context-aware partner reply.

If the learner edits the transcript, coaching uses the corrected text but the attempt is marked supported rather than independent, so hand-corrected text does not inflate independent recall evidence. The application stores the transcript and structured learning evidence locally, not raw recordings. Audio transmission is an explicit opt-in action; Google usage limits/pricing and the existing browser-side API-key risk still apply. A valid key and network connection are required for transcript-based evaluation. With no key, the curated non-AI learning paths continue to work; the recorder explains why it cannot evaluate a clip.

The Memory-to-Mouth loop tracks the actual transcript, intent outcome, hint support, scene/context, and date. “Usable independently” is an explicit heuristic requiring at least two transcript-supported independent successes in at least two contexts and on two different dates. This is a product rule, not a scientifically validated mastery measure. The app does not claim phoneme-level pronunciation or accent scoring; speech synthesis availability/voice quality is browser- and device-dependent.

### Minna no Nihongo Shokyu I companion sprints

The built-in **Minna companion** has 25 lessons and 250 original vocabulary records (10 per lesson), original examples/dialogues, grammar notes, listening questions and exit checks. Lessons 1–15 are tagged as the N5-focused core; lessons 16–25 retain the Shokyu I companion sequence and are tagged bridge/enrichment where some grammar may extend beyond strict N5. This is an independent N5-aligned study set, not an official exhaustive JLPT syllabus or publisher-authored list. The pack selector can download the built-in course as JSON and import separate validated JSON packs for N4, N3, or another level. Imported packs stay separate, are selectable as their own courses, and use independent local lesson sessions. Personal vocabulary can also be imported per pack and lesson as `Japanese, reading, English meaning`. See `docs/minna-content-pack-format.md` for the schema and workflow. The generated pack is also available at `public/lesson-packs/scenespeak-minna-n5-pack.json` as a standalone importable JSON file.

### JLPT N5 practice

The separate N5 area offers Learn, Drill, timed sections and a cumulative mock from an original in-app question bank covering vocabulary, grammar, reading and listening. Timed answer windows follow the currently published N5 allocations: Vocabulary 20 minutes, Grammar + Reading 40 minutes, and Listening 30 minutes. The question set is explicitly **N5-aligned practice**, not an official exhaustive checklist or a prediction that the learner will pass. The JLPT does not include a speaking test; SceneSpeak speaking remains a separate communication-skills path.

Official references: [Gemini audio understanding and inline audio input](https://ai.google.dev/gemini-api/docs/generate-content/audio), [Gemini model documentation](https://ai.google.dev/gemini-api/docs/models), [JLPT section test times and question sections](https://www.jlpt.jp/e/guideline/testsections.html), and [JLPT FAQ](https://www.jlpt.jp/e/faq/).

## Project map

```text
src/
  App.tsx                 app routes, screens, interactions
  styles.css              responsive visual system
  data/course.ts          modules, scenes, phrase bank, grammar notebook
  data/kana.ts            kana reading cards
  domain/scheduler.ts     deterministic spaced-review heuristic
  domain/scoring.ts       independent/hinted/revealed practice scoring
  domain/types.ts         data contracts
  services/storage.ts     versioned IndexedDB, backup validation/import/export
  services/ai.ts          Gemini provider adapter, audio transcript/evaluation, schema validation
  features/SpeakingRecorder.tsx real mic capture, permission states, transcript editing and feedback
  features/EnhancementPages.tsx speaking, Memory-to-Mouth, Minna and N5 pages
  domain/enhancements.ts  25 N5-aligned Minna lessons, 250 vocabulary records, pack validation, N5 bank and evidence thresholds
  styles/enhancements.css responsive styles for enhanced study paths
  main.tsx                React entry point
public/icons/             PWA and app icon assets
netlify.toml              static build, SPA fallback, response headers
capacitor.config.ts       Android package configuration
 tests/domain.test.ts     unit tests
 tests/enhancements.test.ts course-pack validation, N5 timing and speaking-evidence tests
```

## Build-error repair note (25 October 2026)

A follow-up patch addresses the TypeScript errors reported by the first local build: the Lucide `Map` icon no longer shadows the native JavaScript `Map`; map entry arrays are typed as key/value tuples; mission event writes use the route scene ID; review ratings map to the supported difficulty enum; the speaking screen uses a functional state updater; the tutor response type is imported; active roleplay state is narrowed before async callbacks; and IndexedDB roleplay reads now await the `get()` promise before accessing its value.

## Validation status for this source bundle

The authoring environment could not download npm packages: `npm install` / `npm ping` failed while resolving `registry.npmjs.org` (`EAI_AGAIN`). As a result, dependencies are intentionally not bundled, no `dist/` build was generated, and the Vite build, project typecheck, ESLint run, Vitest suite, browser walkthrough, and PWA/device checks could not be completed here.

Checks that did run successfully on the current source: TypeScript/TSX syntax transpilation for all 23 TypeScript/TSX files (zero syntax diagnostics); roadmap runtime smoke checks for progressive phase boundaries, higher-level JLPT sequencing, advanced long-horizon stages, daily success checks, four-week practice cycles, weekly schedule distribution, and progress calculation; plus previous domain checks for the enhanced course, kanji, Minna content and speaking-evidence thresholds. Earlier course smoke checks reported 12 modules, 36 scenes, 267 phrases, 108 dialogue variants, 20 grammar entries, and 213 kana cards with zero course-reference errors. These are source-level checks, not substitutes for `npm run build` or `npm test`.

A full typecheck against the actual installed React, Lucide, IndexedDB, Gemini SDK, and Zod type definitions and the new Vitest suite have not run for the current enhanced revision because package installation failed. After installing dependencies on a machine with npm registry access, run the commands in **Validate and build** before deploying or installing the app.

## Known limitations to understand

- The Android SDK is not configured in the inspected build environment, so an APK has not been built or device-tested here.
- A valid user-supplied Gemini API key was not available; live API connectivity, model access, quota behavior, and provider responses have not been live-tested.
- The course is substantial seed content generated from curated common patterns plus manual records, but no independent native-speaker copyedit has taken place. AI-generated language should be reviewed before treating it as trusted learning material.
- The service worker and PWA install path need to be verified on a real HTTPS deployment/device; merely building the static files does not prove a browser successfully installed the PWA.


## Enhancement implementation note (25 October 2026)

The existing SceneSpeak interface was preserved and extended with Home shortcuts, responsive study pages and a Profile entry point. Microphone practice is now shared by the dedicated speaking studio, the original mission player, Memory-to-Mouth, and the spoken segment of Minna sessions. Audio uses the official `@google/genai` `models.generateContent` inline-data shape documented for small audio clips; the result is transcribed first and is not scored until the learner has reviewed/edited the transcript. The evidence schema records transcript edits separately from independent results. IndexedDB schema v3 stores speaking evidence, resumable Minna lesson sessions, JLPT attempts, imported vocabulary and imported Minna content packs. Version 3 full backups include imported packs while valid v1 and v2 backups remain accepted.

The environment used to author this bundle did not have installed npm dependencies and could not reach the npm registry. Thus these enhancements have passed syntax-transpilation and pure content/domain smoke checks only; they have not passed a full Vite production build or actual Vitest execution here. They also have not been live-tested with the learner's Gemini API key, real microphone on desktop/Android, or a deployed HTTPS PWA. See Validation status and Known limitations above. Do not deploy or treat the feature as device-verified until the commands in **Validate and build** pass and microphone/API testing is completed.

## Storage recovery (schema v4)

The IndexedDB schema has been bumped to version 4. The migration repairs missing object stores and indexes without deleting existing records, addressing browsers that retained a partial schema from an earlier build. The welcome screen shows the database error and offers a retry rather than silently failing when onboarding cannot be saved. After deploying an update, close other open SceneSpeak tabs and reload before retrying. Do not clear browser data unless a backup exists.

## Kanji practice (added)

SceneSpeak now includes a curated N5-oriented companion set of 123 common kanji characters with meanings, on/kun readings, example vocabulary, kana reading, stroke count, and links to Minna lesson numbers and practical scene modules. This is a study selection, not an official exhaustive JLPT list.

- Open **Home → Kanji practice**, the Profile shortcut, or JLPT N5 practice → Kanji foundations.
- Inside Minna vocabulary sprints, use the lesson-specific **Kanji moment**; the larger practice page supports all lessons or an individual lesson filter.
- On normal scene missions, the introduction step includes a scene-linked kanji meaning check.
- Practice evidence is recorded as local practice events; it does not automatically mark characters as permanently mastered.
- Modes: meaning recognition, reading a real example word, meaning-to-kanji recall, and exact character input. Character input checks the typed Unicode character and does not evaluate handwriting or stroke order. Japanese speech uses browser SpeechSynthesis when available.

Tests: `tests/kanji.test.ts` validates dataset uniqueness, examples, lesson coverage, and scene-module coverage.


## Structured daily learning roadmap

The Learning Path page creates a saved day-by-day curriculum with progressive phases, weekly schedules, concrete daily actions, estimated minutes, purpose-specific topic blocks, four-week learn/practise/transfer/retrieve cycles, success checks, focus for vocabulary/kanji, grammar, listening, speaking and review, plus a manual completion tracker measured against study days (not optional rest days). The active roadmap is stored inside the learner profile, so it is included in existing local backups and cloud snapshots. See [`docs/daily-learning-roadmap.md`](docs/daily-learning-roadmap.md) for the data model and limitations.

Learners can also generate an AI-custom roadmap using a Gemini key entered in Profile & Settings. Gemini produces the phase blueprint; SceneSpeak expands it into daily entries offline. AI roadmaps are study guidance, not certified curriculum. Built-in structured content is strongest at beginner/N5, so N4–N1 and advanced anime/work targets still require verified level-matched study material.

## On-demand AI lessons for each roadmap day

Every Learning Path day card now opens a dedicated day lesson instead of navigating directly to a generic existing activity. The first time a day is opened, Gemini generates the study material for that day's focus, phase, learner level, goal, and time budget: vocabulary and examples, grammar, relevant kanji, dialogue/readings, listening prompts, guided exercises, a quiz, and a speaking/transfer mission. The lesson is stored with the active profile so it can be reused and reviewed offline. SceneSpeak keeps a rolling cache of up to 30 recent lessons; older ones may be regenerated when opened again. New lesson generation requires a configured Gemini API key and internet access. The learner must answer all quiz questions and meet a 60% pass threshold (rounded up) before marking the day complete. This is a learning checkpoint, not a validated proficiency measure. See [`docs/roadmap-ai-day-lessons.md`](docs/roadmap-ai-day-lessons.md) for behavior and smoke-test guidance.
