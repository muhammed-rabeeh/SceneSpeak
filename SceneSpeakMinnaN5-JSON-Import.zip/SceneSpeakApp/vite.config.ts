import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  plugins: [react(), VitePWA({
    registerType: 'autoUpdate',
    includeAssets: ['icons/scenespeak.svg'],
    manifest: {
      name: 'SceneSpeak — Japanese Speaking Practice', short_name: 'SceneSpeak',
      id: '/', start_url: '/', scope: '/', display: 'standalone',
      description: 'Practice practical Japanese through real situations and retrieval.',
      theme_color: '#fff7ef', background_color: '#fff7ef',
      icons: [
        { src: '/icons/icon-192.png', sizes: '192x192', type: 'image/png' },
        { src: '/icons/icon-512.png', sizes: '512x512', type: 'image/png' },
        { src: '/icons/icon-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }
      ]
    },
    workbox: {
      navigateFallback: '/index.html',
      globPatterns: ['**/*.{js,css,html,svg,png,woff2,json}'],
      runtimeCaching: []
    }
  })]
});
