export interface KanaCard { character: string; romaji: string; group: string; kind: 'hiragana'|'katakana'; note?: string }
const rows: [string,string,string][] = [
 ['あいうえお','a i u e o','vowels'],['かきくけこ','ka ki ku ke ko','k'],['さしすせそ','sa shi su se so','s'],['たちつてと','ta chi tsu te to','t'],['なにぬねの','na ni nu ne no','n'],['はひふへほ','ha hi fu he ho','h'],['まみむめも','ma mi mu me mo','m'],['や　ゆ　よ','ya yu yo','y'],['らりるれろ','ra ri ru re ro','r'],['わ　　　を','wa o (particle)','w'],['ん','n','n'],
 ['がぎぐげご','ga gi gu ge go','voiced g'],['ざじずぜぞ','za ji zu ze zo','voiced z'],['だぢづでど','da ji zu de do','voiced d'],['ばびぶべぼ','ba bi bu be bo','voiced b'],['ぱぴぷぺぽ','pa pi pu pe po','semi-voiced p'],
 ['きゃきゅきょ','kya kyu kyo','yōon'],['しゃしゅしょ','sha shu sho','yōon'],['ちゃちゅちょ','cha chu cho','yōon'],['にゃにゅにょ','nya nyu nyo','yōon'],['ひゃひゅひょ','hya hyu hyo','yōon'],['みゃみゅみょ','mya myu myo','yōon'],['りゃりゅりょ','rya ryu ryo','yōon'],['ぎゃぎゅぎょ','gya gyu gyo','voiced yōon'],['じゃじゅじょ','ja ju jo','voiced yōon'],['びゃびゅびょ','bya byu byo','voiced yōon'],['ぴゃぴゅぴょ','pya pyu pyo','semi-voiced yōon']
];
const kataRows: [string,string,string][] = [
 ['アイウエオ','a i u e o','vowels'],['カキクケコ','ka ki ku ke ko','k'],['サシスセソ','sa shi su se so','s'],['タチツテト','ta chi tsu te to','t'],['ナニヌネノ','na ni nu ne no','n'],['ハヒフヘホ','ha hi fu he ho','h'],['マミムメモ','ma mi mu me mo','m'],['ヤ　ユ　ヨ','ya yu yo','y'],['ラリルレロ','ra ri ru re ro','r'],['ワ　　　ヲ','wa o (particle)','w'],['ン','n','n'],
 ['ガギグゲゴ','ga gi gu ge go','voiced g'],['ザジズゼゾ','za ji zu ze zo','voiced z'],['ダヂヅデド','da ji zu de do','voiced d'],['バビブベボ','ba bi bu be bo','voiced b'],['パピプペポ','pa pi pu pe po','semi-voiced p'],
 ['キャキュキョ','kya kyu kyo','yōon'],['シャシュショ','sha shu sho','yōon'],['チャチュチョ','cha chu cho','yōon'],['ニャニュニョ','nya nyu nyo','yōon'],['ヒャヒュヒョ','hya hyu hyo','yōon'],['ミャミュミョ','mya myu myo','yōon'],['リャリュリョ','rya ryu ryo','yōon'],['ギャギュギョ','gya gyu gyo','voiced yōon'],['ジャジュジョ','ja ju jo','voiced yōon'],['ビャビュビョ','bya byu byo','voiced yōon'],['ピャピュピョ','pya pyu pyo','semi-voiced yōon']
];
function splitGroups(data:[string,string,string][], kind:'hiragana'|'katakana'):KanaCard[]{
 const result:KanaCard[]=[];
 for(const [chars,roman,group] of data){
  const characterList=chars.replaceAll('　',' ').split(' ').filter(Boolean);
  // Most gojūon rows are written without spaces. Handle small combinations by groups of three.
  const roma=roman.split(' ');
  const width=group.includes('yōon')?3:Math.max(1,characterList.length===1?1:chars.replaceAll('　','').length);
  const raw=chars.replaceAll('　','');
  if(group.includes('yōon')){
   for(let i=0;i<raw.length;i+=2) result.push({character:raw.slice(i,i+2),romaji:roma[i/2]??'',group,kind});
  } else {
   for(let i=0;i<raw.length;i++) result.push({character:raw[i],romaji:roma[i]??'',group,kind,note:raw[i]==='っ'||raw[i]==='ッ'?'Small tsu doubles the following consonant.':undefined});
  }
  void width;
 }
 return result;
}
export const kanaCards: KanaCard[] = [...splitGroups(rows,'hiragana'),...splitGroups(kataRows,'katakana'),
 {character:'っ',romaji:'small tsu',group:'special',kind:'hiragana',note:'Creates a brief pause and doubles the next consonant.'},
 {character:'ッ',romaji:'small tsu',group:'special',kind:'katakana',note:'Creates a brief pause and doubles the next consonant.'},
 {character:'ー',romaji:'long vowel mark',group:'special',kind:'katakana',note:'Extends the preceding vowel in many loanwords.'},
 {character:'きって',romaji:'kitte',group:'special',kind:'hiragana',note:'きって means “stamp”; compare きて (kite).'},
 {character:'コーヒー',romaji:'kōhī',group:'special',kind:'katakana',note:'Loanwords commonly use ー to mark long vowels.'}
];
export const kanaUnique = kanaCards.filter((c,i,a)=>a.findIndex(x=>x.kind===c.kind&&x.character===c.character)===i);
