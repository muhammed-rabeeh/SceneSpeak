/**
 * Original SceneSpeak N5-oriented kanji companion data.
 * JLPT no longer publishes a definitive exhaustive kanji checklist; this is a curated study set,
 * not an official or exhaustive list. Readings are shown through common beginner vocabulary.
 */
export type N5Kanji = {
  id: string;
  character: string;
  meanings: string[];
  onReadings: string[];
  kunReadings: string[];
  example: string;
  exampleReading: string;
  exampleMeaning: string;
  lessonNumbers: number[];
  moduleIds: string[];
  strokeCount: number;
};

type KanjiSeed = Omit<N5Kanji, 'id'>;
const seeds: KanjiSeed[] = [
 {character:'一',meanings:['one'],onReadings:['いち','いつ'],kunReadings:['ひと'],example:'一つ',exampleReading:'ひとつ',exampleMeaning:'one thing',lessonNumbers:[3],moduleIds:['m3'],strokeCount:1},
 {character:'二',meanings:['two'],onReadings:['に'],kunReadings:['ふた'],example:'二つ',exampleReading:'ふたつ',exampleMeaning:'two things',lessonNumbers:[3],moduleIds:['m3'],strokeCount:2},
 {character:'三',meanings:['three'],onReadings:['さん'],kunReadings:['みっ'],example:'三つ',exampleReading:'みっつ',exampleMeaning:'three things',lessonNumbers:[3],moduleIds:['m3'],strokeCount:3},
 {character:'四',meanings:['four'],onReadings:['し'],kunReadings:['よん','よっ'],example:'四時',exampleReading:'よじ',exampleMeaning:'four o’clock',lessonNumbers:[3,4],moduleIds:['m3'],strokeCount:5},
 {character:'五',meanings:['five'],onReadings:['ご'],kunReadings:['いつ'],example:'五分',exampleReading:'ごふん',exampleMeaning:'five minutes',lessonNumbers:[3,4],moduleIds:['m3'],strokeCount:4},
 {character:'六',meanings:['six'],onReadings:['ろく'],kunReadings:['むっ'],example:'六時',exampleReading:'ろくじ',exampleMeaning:'six o’clock',lessonNumbers:[3,4],moduleIds:['m3'],strokeCount:4},
 {character:'七',meanings:['seven'],onReadings:['しち'],kunReadings:['なな'],example:'七時',exampleReading:'しちじ',exampleMeaning:'seven o’clock',lessonNumbers:[3,4],moduleIds:['m3'],strokeCount:2},
 {character:'八',meanings:['eight'],onReadings:['はち'],kunReadings:['やっ'],example:'八時',exampleReading:'はちじ',exampleMeaning:'eight o’clock',lessonNumbers:[3,4],moduleIds:['m3'],strokeCount:2},
 {character:'九',meanings:['nine'],onReadings:['きゅう','く'],kunReadings:['ここの'],example:'九時',exampleReading:'くじ',exampleMeaning:'nine o’clock',lessonNumbers:[3,4],moduleIds:['m3'],strokeCount:2},
 {character:'十',meanings:['ten'],onReadings:['じゅう'],kunReadings:['とお'],example:'十円',exampleReading:'じゅうえん',exampleMeaning:'ten yen',lessonNumbers:[3],moduleIds:['m3','m9'],strokeCount:2},
 {character:'百',meanings:['hundred'],onReadings:['ひゃく'],kunReadings:[],example:'百円',exampleReading:'ひゃくえん',exampleMeaning:'one hundred yen',lessonNumbers:[3,9],moduleIds:['m3','m9'],strokeCount:6},
 {character:'千',meanings:['thousand'],onReadings:['せん'],kunReadings:[],example:'千円',exampleReading:'せんえん',exampleMeaning:'one thousand yen',lessonNumbers:[3,9],moduleIds:['m3','m9'],strokeCount:3},
 {character:'万',meanings:['ten thousand'],onReadings:['まん'],kunReadings:[],example:'一万円',exampleReading:'いちまんえん',exampleMeaning:'ten thousand yen',lessonNumbers:[3,9],moduleIds:['m3','m9'],strokeCount:3},
 {character:'円',meanings:['yen; circle'],onReadings:['えん'],kunReadings:[],example:'百円',exampleReading:'ひゃくえん',exampleMeaning:'one hundred yen',lessonNumbers:[3,5,9,25],moduleIds:['m3','m5','m9'],strokeCount:4},
 {character:'日',meanings:['day; sun'],onReadings:['にち','じつ'],kunReadings:['ひ','か'],example:'日本',exampleReading:'にほん',exampleMeaning:'Japan',lessonNumbers:[1,4,10,17,19,25],moduleIds:['m1','m2','m10'],strokeCount:4},
 {character:'月',meanings:['month; moon'],onReadings:['げつ','がつ'],kunReadings:['つき'],example:'月曜日',exampleReading:'げつようび',exampleMeaning:'Monday',lessonNumbers:[4,10],moduleIds:['m3','m10'],strokeCount:4},
 {character:'火',meanings:['fire'],onReadings:['か'],kunReadings:['ひ'],example:'火曜日',exampleReading:'かようび',exampleMeaning:'Tuesday',lessonNumbers:[4,10],moduleIds:['m3','m10'],strokeCount:4},
 {character:'水',meanings:['water'],onReadings:['すい'],kunReadings:['みず'],example:'水',exampleReading:'みず',exampleMeaning:'water',lessonNumbers:[4,6],moduleIds:['m4','m5','m6','m10'],strokeCount:4},
 {character:'木',meanings:['tree; wood'],onReadings:['もく','ぼく'],kunReadings:['き'],example:'木曜日',exampleReading:'もくようび',exampleMeaning:'Thursday',lessonNumbers:[4,10],moduleIds:['m10'],strokeCount:4},
 {character:'金',meanings:['gold; money'],onReadings:['きん','こん'],kunReadings:['かね','かな'],example:'お金',exampleReading:'おかね',exampleMeaning:'money',lessonNumbers:[3,9],moduleIds:['m3','m5','m9'],strokeCount:8},
 {character:'土',meanings:['earth; soil'],onReadings:['ど','と'],kunReadings:['つち'],example:'土曜日',exampleReading:'どようび',exampleMeaning:'Saturday',lessonNumbers:[4,10],moduleIds:['m10'],strokeCount:3},
 {character:'年',meanings:['year'],onReadings:['ねん'],kunReadings:['とし'],example:'今年',exampleReading:'ことし',exampleMeaning:'this year',lessonNumbers:[4,10,25],moduleIds:['m3','m10'],strokeCount:6},
 {character:'時',meanings:['time; hour'],onReadings:['じ'],kunReadings:['とき'],example:'何時',exampleReading:'なんじ',exampleMeaning:'what time',lessonNumbers:[4,17,19,25],moduleIds:['m3','m10'],strokeCount:10},
 {character:'分',meanings:['minute; part'],onReadings:['ふん','ぶん'],kunReadings:['わ'],example:'五分',exampleReading:'ごふん',exampleMeaning:'five minutes',lessonNumbers:[3,4,17,19],moduleIds:['m3'],strokeCount:4},
 {character:'半',meanings:['half'],onReadings:['はん'],kunReadings:[],example:'三時半',exampleReading:'さんじはん',exampleMeaning:'half past three',lessonNumbers:[4],moduleIds:['m3'],strokeCount:5},
 {character:'今',meanings:['now'],onReadings:['こん'],kunReadings:['いま'],example:'今',exampleReading:'いま',exampleMeaning:'now',lessonNumbers:[4,10,25],moduleIds:['m3','m10'],strokeCount:4},
 {character:'午',meanings:['noon'],onReadings:['ご'],kunReadings:[],example:'午前',exampleReading:'ごぜん',exampleMeaning:'morning; a.m.',lessonNumbers:[4,25],moduleIds:['m3'],strokeCount:4},
 {character:'前',meanings:['before; front'],onReadings:['ぜん'],kunReadings:['まえ'],example:'午前',exampleReading:'ごぜん',exampleMeaning:'morning; a.m.',lessonNumbers:[4,7,17,19],moduleIds:['m3','m7'],strokeCount:9},
 {character:'後',meanings:['after; behind'],onReadings:['ご','こう'],kunReadings:['あと','うしろ'],example:'午後',exampleReading:'ごご',exampleMeaning:'afternoon; p.m.',lessonNumbers:[4,7,17,19],moduleIds:['m3','m7'],strokeCount:9},
 {character:'毎',meanings:['every'],onReadings:['まい'],kunReadings:[],example:'毎日',exampleReading:'まいにち',exampleMeaning:'every day',lessonNumbers:[4,10,17,19,25],moduleIds:['m3','m10'],strokeCount:6},
 {character:'週',meanings:['week'],onReadings:['しゅう'],kunReadings:[],example:'今週',exampleReading:'こんしゅう',exampleMeaning:'this week',lessonNumbers:[4,10,17,19,25],moduleIds:['m3','m10'],strokeCount:11},
 {character:'曜',meanings:['weekday'],onReadings:['よう'],kunReadings:[],example:'日曜日',exampleReading:'にちようび',exampleMeaning:'Sunday',lessonNumbers:[4,10,17,19],moduleIds:['m3','m10'],strokeCount:18},
 {character:'上',meanings:['above; up'],onReadings:['じょう'],kunReadings:['うえ','あ'],example:'上',exampleReading:'うえ',exampleMeaning:'above; on top',lessonNumbers:[3,7],moduleIds:['m7'],strokeCount:3},
 {character:'下',meanings:['below; down'],onReadings:['か','げ'],kunReadings:['した','さ'],example:'下',exampleReading:'した',exampleMeaning:'below; underneath',lessonNumbers:[3,7],moduleIds:['m7'],strokeCount:3},
 {character:'中',meanings:['inside; middle'],onReadings:['ちゅう','じゅう'],kunReadings:['なか'],example:'中',exampleReading:'なか',exampleMeaning:'inside',lessonNumbers:[2,3,7],moduleIds:['m5','m7','m10'],strokeCount:4},
 {character:'外',meanings:['outside'],onReadings:['がい','げ'],kunReadings:['そと','ほか'],example:'外国',exampleReading:'がいこく',exampleMeaning:'foreign country',lessonNumbers:[2,3],moduleIds:['m2','m7'],strokeCount:5},
 {character:'右',meanings:['right'],onReadings:['う','ゆう'],kunReadings:['みぎ'],example:'右',exampleReading:'みぎ',exampleMeaning:'right side',lessonNumbers:[3,7],moduleIds:['m7'],strokeCount:5},
 {character:'左',meanings:['left'],onReadings:['さ'],kunReadings:['ひだり'],example:'左',exampleReading:'ひだり',exampleMeaning:'left side',lessonNumbers:[3,7],moduleIds:['m7'],strokeCount:5},
 {character:'東',meanings:['east'],onReadings:['とう'],kunReadings:['ひがし'],example:'東京',exampleReading:'とうきょう',exampleMeaning:'Tokyo',lessonNumbers:[3,5,22,25],moduleIds:['m7','m8'],strokeCount:8},
 {character:'西',meanings:['west'],onReadings:['せい','さい'],kunReadings:['にし'],example:'西',exampleReading:'にし',exampleMeaning:'west',lessonNumbers:[3,7,22,25],moduleIds:['m7'],strokeCount:6},
 {character:'南',meanings:['south'],onReadings:['なん'],kunReadings:['みなみ'],example:'南',exampleReading:'みなみ',exampleMeaning:'south',lessonNumbers:[3,7,22,25],moduleIds:['m7'],strokeCount:9},
 {character:'北',meanings:['north'],onReadings:['ほく'],kunReadings:['きた'],example:'北',exampleReading:'きた',exampleMeaning:'north',lessonNumbers:[3,7,22,25],moduleIds:['m7'],strokeCount:5},
 {character:'口',meanings:['mouth; opening'],onReadings:['こう','く'],kunReadings:['くち'],example:'入口',exampleReading:'いりぐち',exampleMeaning:'entrance',lessonNumbers:[2,3,12,23,25],moduleIds:['m5','m7','m12'],strokeCount:3},
 {character:'目',meanings:['eye'],onReadings:['もく'],kunReadings:['め'],example:'目',exampleReading:'め',exampleMeaning:'eye',lessonNumbers:[2,24],moduleIds:['m1','m2'],strokeCount:5},
 {character:'耳',meanings:['ear'],onReadings:['じ'],kunReadings:['みみ'],example:'耳',exampleReading:'みみ',exampleMeaning:'ear',lessonNumbers:[2,24],moduleIds:['m1'],strokeCount:6},
 {character:'手',meanings:['hand'],onReadings:['しゅ'],kunReadings:['て'],example:'手',exampleReading:'て',exampleMeaning:'hand',lessonNumbers:[2,7,12,14,18,20,24],moduleIds:['m5','m12'],strokeCount:4},
 {character:'足',meanings:['foot; leg'],onReadings:['そく'],kunReadings:['あし','た'],example:'足',exampleReading:'あし',exampleMeaning:'foot; leg',lessonNumbers:[2,7,24],moduleIds:['m7'],strokeCount:7},
 {character:'力',meanings:['power; strength'],onReadings:['りょく','りき'],kunReadings:['ちから'],example:'力',exampleReading:'ちから',exampleMeaning:'strength',lessonNumbers:[12,24],moduleIds:['m12'],strokeCount:2},
 {character:'人',meanings:['person'],onReadings:['じん','にん'],kunReadings:['ひと'],example:'日本人',exampleReading:'にほんじん',exampleMeaning:'Japanese person',lessonNumbers:[1,2,11,16,18,24],moduleIds:['m1','m2','m11'],strokeCount:2},
 {character:'男',meanings:['man; male'],onReadings:['だん','なん'],kunReadings:['おとこ'],example:'男の人',exampleReading:'おとこのひと',exampleMeaning:'man',lessonNumbers:[1,2,11],moduleIds:['m2','m11'],strokeCount:7},
 {character:'女',meanings:['woman; female'],onReadings:['じょ','にょ'],kunReadings:['おんな'],example:'女の人',exampleReading:'おんなのひと',exampleMeaning:'woman',lessonNumbers:[1,2,11],moduleIds:['m2','m11'],strokeCount:3},
 {character:'子',meanings:['child'],onReadings:['し','す'],kunReadings:['こ'],example:'子ども',exampleReading:'こども',exampleMeaning:'child',lessonNumbers:[1,2,11,18],moduleIds:['m2','m11'],strokeCount:3},
 {character:'父',meanings:['father'],onReadings:['ふ'],kunReadings:['ちち','とう'],example:'父',exampleReading:'ちち',exampleMeaning:'my father',lessonNumbers:[11,18],moduleIds:['m11'],strokeCount:4},
 {character:'母',meanings:['mother'],onReadings:['ぼ'],kunReadings:['はは','かあ'],example:'母',exampleReading:'はは',exampleMeaning:'my mother',lessonNumbers:[11,18],moduleIds:['m11'],strokeCount:5},
 {character:'友',meanings:['friend'],onReadings:['ゆう'],kunReadings:['とも'],example:'友だち',exampleReading:'ともだち',exampleMeaning:'friend',lessonNumbers:[1,11,16,18,24],moduleIds:['m2','m11'],strokeCount:4},
 {character:'名',meanings:['name'],onReadings:['めい','みょう'],kunReadings:['な'],example:'名前',exampleReading:'なまえ',exampleMeaning:'name',lessonNumbers:[1,2,16],moduleIds:['m2'],strokeCount:6},
 {character:'先',meanings:['ahead; previous'],onReadings:['せん'],kunReadings:['さき'],example:'先生',exampleReading:'せんせい',exampleMeaning:'teacher',lessonNumbers:[1,2,16,18],moduleIds:['m2'],strokeCount:6},
 {character:'生',meanings:['life; birth'],onReadings:['せい','しょう'],kunReadings:['い','う'],example:'学生',exampleReading:'がくせい',exampleMeaning:'student',lessonNumbers:[1,2,20,21],moduleIds:['m2'],strokeCount:5},
 {character:'学',meanings:['study; learning'],onReadings:['がく'],kunReadings:['まな'],example:'学校',exampleReading:'がっこう',exampleMeaning:'school',lessonNumbers:[1,2,20,21,24],moduleIds:['m2'],strokeCount:8},
 {character:'校',meanings:['school'],onReadings:['こう'],kunReadings:[],example:'学校',exampleReading:'がっこう',exampleMeaning:'school',lessonNumbers:[1,2],moduleIds:['m2'],strokeCount:10},
 {character:'国',meanings:['country'],onReadings:['こく'],kunReadings:['くに'],example:'外国',exampleReading:'がいこく',exampleMeaning:'foreign country',lessonNumbers:[1,2],moduleIds:['m2'],strokeCount:8},
 {character:'語',meanings:['language; word'],onReadings:['ご'],kunReadings:['かた'],example:'日本語',exampleReading:'にほんご',exampleMeaning:'Japanese language',lessonNumbers:[1,2],moduleIds:['m2'],strokeCount:14},
 {character:'本',meanings:['book; origin'],onReadings:['ほん'],kunReadings:['もと'],example:'本',exampleReading:'ほん',exampleMeaning:'book',lessonNumbers:[2,16,21],moduleIds:['m1','m2'],strokeCount:5},
 {character:'文',meanings:['sentence; writing'],onReadings:['ぶん','もん'],kunReadings:['ふみ'],example:'作文',exampleReading:'さくぶん',exampleMeaning:'composition; essay',lessonNumbers:[1,2,16,21],moduleIds:['m2','m10'],strokeCount:4},
 {character:'字',meanings:['character; letter'],onReadings:['じ'],kunReadings:['あざ'],example:'漢字',exampleReading:'かんじ',exampleMeaning:'kanji character',lessonNumbers:[1,2,16,21],moduleIds:['m1','m2'],strokeCount:6},
 {character:'何',meanings:['what'],onReadings:['か'],kunReadings:['なに','なん'],example:'何時',exampleReading:'なんじ',exampleMeaning:'what time',lessonNumbers:[2,4],moduleIds:['m2','m3'],strokeCount:7},
 {character:'山',meanings:['mountain'],onReadings:['さん'],kunReadings:['やま'],example:'山',exampleReading:'やま',exampleMeaning:'mountain',lessonNumbers:[3,7,22,25],moduleIds:['m7','m8'],strokeCount:3},
 {character:'川',meanings:['river'],onReadings:['せん'],kunReadings:['かわ'],example:'川',exampleReading:'かわ',exampleMeaning:'river',lessonNumbers:[3,7,22,25],moduleIds:['m7'],strokeCount:3},
 {character:'田',meanings:['rice field'],onReadings:['でん'],kunReadings:['た'],example:'田中さん',exampleReading:'たなかさん',exampleMeaning:'Mr./Ms. Tanaka (surname)',lessonNumbers:[1,2,16],moduleIds:['m2'],strokeCount:5},
 {character:'天',meanings:['heaven; sky'],onReadings:['てん'],kunReadings:['あま'],example:'天気',exampleReading:'てんき',exampleMeaning:'weather',lessonNumbers:[11,19,25],moduleIds:['m11'],strokeCount:4},
 {character:'気',meanings:['spirit; feeling'],onReadings:['き','け'],kunReadings:[],example:'天気',exampleReading:'てんき',exampleMeaning:'weather',lessonNumbers:[11,19,25],moduleIds:['m10','m11'],strokeCount:6},
 {character:'雨',meanings:['rain'],onReadings:['う'],kunReadings:['あめ','あま'],example:'雨',exampleReading:'あめ',exampleMeaning:'rain',lessonNumbers:[11,19,25],moduleIds:['m10','m11'],strokeCount:8},
 {character:'電',meanings:['electricity'],onReadings:['でん'],kunReadings:[],example:'電車',exampleReading:'でんしゃ',exampleMeaning:'train',lessonNumbers:[5,8,23,25],moduleIds:['m8'],strokeCount:13},
 {character:'車',meanings:['vehicle; car'],onReadings:['しゃ'],kunReadings:['くるま'],example:'電車',exampleReading:'でんしゃ',exampleMeaning:'train',lessonNumbers:[5,8,23,25],moduleIds:['m8'],strokeCount:7},
 {character:'駅',meanings:['station'],onReadings:['えき'],kunReadings:[],example:'駅',exampleReading:'えき',exampleMeaning:'station',lessonNumbers:[3,5,8,23,25],moduleIds:['m7','m8'],strokeCount:14},
 {character:'道',meanings:['road; way'],onReadings:['どう'],kunReadings:['みち'],example:'道',exampleReading:'みち',exampleMeaning:'road; way',lessonNumbers:[3,7,8,19,21,25],moduleIds:['m7','m8'],strokeCount:12},
 {character:'行',meanings:['go'],onReadings:['こう','ぎょう'],kunReadings:['い','ゆ'],example:'行く',exampleReading:'いく',exampleMeaning:'to go',lessonNumbers:[5,8,13,19,20,21,25],moduleIds:['m8','m10'],strokeCount:6},
 {character:'来',meanings:['come'],onReadings:['らい'],kunReadings:['く'],example:'来る',exampleReading:'くる',exampleMeaning:'to come',lessonNumbers:[5,8,13,18,19,25],moduleIds:['m8','m11'],strokeCount:7},
 {character:'帰',meanings:['return; go home'],onReadings:['き'],kunReadings:['かえ'],example:'帰る',exampleReading:'かえる',exampleMeaning:'to return; go home',lessonNumbers:[5,10,13,19,25],moduleIds:['m8','m10'],strokeCount:10},
 {character:'食',meanings:['eat; food'],onReadings:['しょく'],kunReadings:['た'],example:'食べる',exampleReading:'たべる',exampleMeaning:'to eat',lessonNumbers:[6,10,13,20],moduleIds:['m4','m6','m10'],strokeCount:9},
 {character:'飲',meanings:['drink'],onReadings:['いん'],kunReadings:['の'],example:'飲む',exampleReading:'のむ',exampleMeaning:'to drink',lessonNumbers:[6,10],moduleIds:['m4','m6','m10'],strokeCount:12},
 {character:'見',meanings:['see; look'],onReadings:['けん'],kunReadings:['み'],example:'見る',exampleReading:'みる',exampleMeaning:'to see; look',lessonNumbers:[6,7,10,14,15,20,21],moduleIds:['m6','m7','m10'],strokeCount:7},
 {character:'聞',meanings:['hear; listen; ask'],onReadings:['ぶん','もん'],kunReadings:['き'],example:'聞く',exampleReading:'きく',exampleMeaning:'to listen; ask',lessonNumbers:[6,8,14,20,21],moduleIds:['m1','m8'],strokeCount:14},
 {character:'読',meanings:['read'],onReadings:['どく'],kunReadings:['よ'],example:'読む',exampleReading:'よむ',exampleMeaning:'to read',lessonNumbers:[6,14,20,21],moduleIds:['m1','m10'],strokeCount:14},
 {character:'書',meanings:['write'],onReadings:['しょ'],kunReadings:['か'],example:'書く',exampleReading:'かく',exampleMeaning:'to write',lessonNumbers:[6,7,14,20,21],moduleIds:['m1','m10'],strokeCount:10},
 {character:'話',meanings:['talk; story'],onReadings:['わ'],kunReadings:['はな'],example:'話す',exampleReading:'はなす',exampleMeaning:'to speak',lessonNumbers:[6,8,12,14,20,21,24],moduleIds:['m1','m8','m12'],strokeCount:13},
 {character:'買',meanings:['buy'],onReadings:['ばい'],kunReadings:['か'],example:'買う',exampleReading:'かう',exampleMeaning:'to buy',lessonNumbers:[5,9,13,20,21],moduleIds:['m5','m9'],strokeCount:12},
 {character:'休',meanings:['rest; holiday'],onReadings:['きゅう'],kunReadings:['やす'],example:'休む',exampleReading:'やすむ',exampleMeaning:'to rest',lessonNumbers:[10,15,19,25],moduleIds:['m10'],strokeCount:6},
 {character:'立',meanings:['stand'],onReadings:['りつ','りゅう'],kunReadings:['た'],example:'立つ',exampleReading:'たつ',exampleMeaning:'to stand',lessonNumbers:[7,15],moduleIds:['m7'],strokeCount:5},
 {character:'入',meanings:['enter'],onReadings:['にゅう'],kunReadings:['はい','い'],example:'入口',exampleReading:'いりぐち',exampleMeaning:'entrance',lessonNumbers:[3,5,12,15,23],moduleIds:['m5','m7'],strokeCount:2},
 {character:'出',meanings:['exit; go out'],onReadings:['しゅつ'],kunReadings:['で','だ'],example:'出口',exampleReading:'でぐち',exampleMeaning:'exit',lessonNumbers:[3,5,12,15,23],moduleIds:['m5','m7','m12'],strokeCount:5},
 {character:'小',meanings:['small'],onReadings:['しょう'],kunReadings:['ちい','こ'],example:'小さい',exampleReading:'ちいさい',exampleMeaning:'small',lessonNumbers:[8,9],moduleIds:['m9'],strokeCount:3},
 {character:'大',meanings:['big; large'],onReadings:['だい','たい'],kunReadings:['おお'],example:'大きい',exampleReading:'おおきい',exampleMeaning:'big; large',lessonNumbers:[8,9],moduleIds:['m4','m6','m9'],strokeCount:3},
 {character:'高',meanings:['high; expensive'],onReadings:['こう'],kunReadings:['たか'],example:'高い',exampleReading:'たかい',exampleMeaning:'high; expensive',lessonNumbers:[8,9,22],moduleIds:['m9'],strokeCount:10},
 {character:'安',meanings:['cheap; safe'],onReadings:['あん'],kunReadings:['やす'],example:'安い',exampleReading:'やすい',exampleMeaning:'cheap; inexpensive',lessonNumbers:[8,9,22],moduleIds:['m5','m9'],strokeCount:6},
 {character:'新',meanings:['new'],onReadings:['しん'],kunReadings:['あたら','あら'],example:'新しい',exampleReading:'あたらしい',exampleMeaning:'new',lessonNumbers:[8,9,22],moduleIds:['m9'],strokeCount:13},
 {character:'古',meanings:['old'],onReadings:['こ'],kunReadings:['ふる'],example:'古い',exampleReading:'ふるい',exampleMeaning:'old',lessonNumbers:[8,9,22],moduleIds:['m9'],strokeCount:5},
 {character:'長',meanings:['long; leader'],onReadings:['ちょう'],kunReadings:['なが'],example:'長い',exampleReading:'ながい',exampleMeaning:'long',lessonNumbers:[8,22],moduleIds:['m9'],strokeCount:8},
 {character:'多',meanings:['many; much'],onReadings:['た'],kunReadings:['おお'],example:'多い',exampleReading:'おおい',exampleMeaning:'many; much',lessonNumbers:[8,9,22],moduleIds:['m9'],strokeCount:6},
 {character:'少',meanings:['few; little'],onReadings:['しょう'],kunReadings:['すく','すこ'],example:'少ない',exampleReading:'すくない',exampleMeaning:'few; not many',lessonNumbers:[8,9,22],moduleIds:['m9'],strokeCount:4},
 {character:'白',meanings:['white'],onReadings:['はく','びゃく'],kunReadings:['しろ','しら'],example:'白い',exampleReading:'しろい',exampleMeaning:'white',lessonNumbers:[9],moduleIds:['m9'],strokeCount:5},
 {character:'黒',meanings:['black'],onReadings:['こく'],kunReadings:['くろ'],example:'黒い',exampleReading:'くろい',exampleMeaning:'black',lessonNumbers:[9],moduleIds:['m9'],strokeCount:11},
 {character:'赤',meanings:['red'],onReadings:['せき','しゃく'],kunReadings:['あか'],example:'赤い',exampleReading:'あかい',exampleMeaning:'red',lessonNumbers:[9],moduleIds:['m9'],strokeCount:7},
 {character:'青',meanings:['blue'],onReadings:['せい','しょう'],kunReadings:['あお'],example:'青い',exampleReading:'あおい',exampleMeaning:'blue',lessonNumbers:[9],moduleIds:['m9'],strokeCount:8},
 {character:'早',meanings:['early; fast'],onReadings:['そう'],kunReadings:['はや'],example:'早い',exampleReading:'はやい',exampleMeaning:'early; fast',lessonNumbers:[4,10],moduleIds:['m3','m10'],strokeCount:6},
 {character:'好',meanings:['like'],onReadings:['こう'],kunReadings:['す'],example:'好き',exampleReading:'すき',exampleMeaning:'to like; liked',lessonNumbers:[9,10,20,21,24],moduleIds:['m10'],strokeCount:6},
 {character:'会',meanings:['meet; meeting'],onReadings:['かい'],kunReadings:['あ'],example:'会う',exampleReading:'あう',exampleMeaning:'to meet',lessonNumbers:[11,13,18,21,24,25],moduleIds:['m2','m11'],strokeCount:6},
 {character:'社',meanings:['company; shrine'],onReadings:['しゃ'],kunReadings:['やしろ'],example:'会社',exampleReading:'かいしゃ',exampleMeaning:'company',lessonNumbers:[1,11,18,24],moduleIds:['m2','m11'],strokeCount:7},
 {character:'店',meanings:['shop; store'],onReadings:['てん'],kunReadings:['みせ'],example:'店',exampleReading:'みせ',exampleMeaning:'shop; store',lessonNumbers:[3,5,9,21],moduleIds:['m4','m5','m6','m9'],strokeCount:8},
 {character:'魚',meanings:['fish'],onReadings:['ぎょ'],kunReadings:['さかな'],example:'魚',exampleReading:'さかな',exampleMeaning:'fish',lessonNumbers:[6,23],moduleIds:['m6'],strokeCount:11},
 {character:'肉',meanings:['meat'],onReadings:['にく'],kunReadings:[],example:'肉',exampleReading:'にく',exampleMeaning:'meat',lessonNumbers:[6,23],moduleIds:['m6'],strokeCount:6},
 {character:'茶',meanings:['tea'],onReadings:['ちゃ','さ'],kunReadings:[],example:'お茶',exampleReading:'おちゃ',exampleMeaning:'tea',lessonNumbers:[4,6,23],moduleIds:['m4','m6'],strokeCount:9},
 {character:'朝',meanings:['morning'],onReadings:['ちょう'],kunReadings:['あさ'],example:'朝',exampleReading:'あさ',exampleMeaning:'morning',lessonNumbers:[4,10],moduleIds:['m3','m10'],strokeCount:12},
 {character:'昼',meanings:['noon; daytime'],onReadings:['ちゅう'],kunReadings:['ひる'],example:'昼',exampleReading:'ひる',exampleMeaning:'noon; daytime',lessonNumbers:[4,10],moduleIds:['m3','m10'],strokeCount:9},
 {character:'夜',meanings:['night'],onReadings:['や'],kunReadings:['よる'],example:'夜',exampleReading:'よる',exampleMeaning:'night',lessonNumbers:[4,10],moduleIds:['m3','m10'],strokeCount:8}, {character:'言',meanings:['say; word'],onReadings:['げん','ごん'],kunReadings:['い'],example:'言う',exampleReading:'いう',exampleMeaning:'to say',lessonNumbers:[13,14,21,25],moduleIds:['m1','m8','m12'],strokeCount:7},
 {character:'思',meanings:['think'],onReadings:['し'],kunReadings:['おも'],example:'思う',exampleReading:'おもう',exampleMeaning:'to think',lessonNumbers:[20,21,25],moduleIds:['m10','m11'],strokeCount:9},
 {character:'知',meanings:['know'],onReadings:['ち'],kunReadings:['し'],example:'知る',exampleReading:'しる',exampleMeaning:'to know',lessonNumbers:[20,21,25],moduleIds:['m10','m12'],strokeCount:8},
 {character:'作',meanings:['make; create'],onReadings:['さく'],kunReadings:['つく'],example:'作る',exampleReading:'つくる',exampleMeaning:'to make',lessonNumbers:[13,20,21,25],moduleIds:['m10','m12'],strokeCount:7},
 {character:'使',meanings:['use'],onReadings:['し'],kunReadings:['つか'],example:'使う',exampleReading:'つかう',exampleMeaning:'to use',lessonNumbers:[13,14,20,21,25],moduleIds:['m5','m10','m12'],strokeCount:8},
 {character:'家',meanings:['house; home'],onReadings:['か','け'],kunReadings:['いえ','うち'],example:'家',exampleReading:'いえ',exampleMeaning:'house; home',lessonNumbers:[10,16,17,19,21,25],moduleIds:['m10','m12'],strokeCount:10},
 {character:'住',meanings:['live; reside'],onReadings:['じゅう'],kunReadings:['す'],example:'住む',exampleReading:'すむ',exampleMeaning:'to live; reside',lessonNumbers:[16,17,19,21,25],moduleIds:['m2','m10'],strokeCount:7},
 {character:'待',meanings:['wait'],onReadings:['たい'],kunReadings:['ま'],example:'待つ',exampleReading:'まつ',exampleMeaning:'to wait',lessonNumbers:[13,14,15,17],moduleIds:['m8','m12'],strokeCount:9},
];


export const N5_KANJI: N5Kanji[] = seeds.map((row) => ({ ...row, id: `kanji-${row.character.codePointAt(0)?.toString(16) ?? 'unknown'}` }));

export function getKanjiForLesson(lessonNumber: number): N5Kanji[] {
  return N5_KANJI.filter((item) => item.lessonNumbers.includes(lessonNumber));
}
export function getKanjiForModule(moduleId: string): N5Kanji[] {
  return N5_KANJI.filter((item) => item.moduleIds.includes(moduleId));
}
export function getKanjiById(id: string): N5Kanji | undefined {
  return N5_KANJI.find((item) => item.id === id);
}
export function validateKanjiData(): string[] {
  const errors: string[] = [];
  const ids = new Set<string>();
  const characters = new Set<string>();
  for (const item of N5_KANJI) {
    if (ids.has(item.id)) errors.push(`Duplicate id: ${item.id}`);
    if (characters.has(item.character)) errors.push(`Duplicate character: ${item.character}`);
    ids.add(item.id); characters.add(item.character);
    if (!item.meanings.length || !item.example || !item.exampleReading || !item.exampleMeaning) errors.push(`Incomplete kanji record: ${item.character}`);
    if (!item.lessonNumbers.length || item.lessonNumbers.some((n) => n < 1 || n > 25)) errors.push(`Invalid Minna lesson mapping: ${item.character}`);
  }
  return errors;
}
