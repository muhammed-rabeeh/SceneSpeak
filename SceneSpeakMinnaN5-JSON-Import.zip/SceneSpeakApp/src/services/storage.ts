import { openDB, type DBSchema, type IDBPDatabase } from 'idb';
import type { ActiveRoleplay, AppBackup, AppSettings, PhraseProgress, Profile, SavedScene, SessionRecord, PracticeEvent } from '../domain/types';
import { validateMinnaPack, type JLPTAttempt, type MinnaSession, type MinnaContentPack, type PersonalVocabulary, type SpeakingEvidence } from '../domain/enhancements';

interface ValueRow<T> { key: string; value: T }
interface NoteRow { phraseId:string; note:string }
interface FavoriteRow { phraseId:string; savedAt:string }
interface KanaRow { character:string; score:number }
interface GrammarRow { entryId:string; score:number; correct:number; attempts:number }
interface SceneRow extends SavedScene {}
interface SceneSpeakDB extends DBSchema {
  profile: { key:string; value:ValueRow<Profile> };
  settings: { key:string; value:ValueRow<AppSettings> };
  progress: { key:string; value:PhraseProgress; indexes:{ 'by-next-review':'nextReviewAt' } };
  sessions: { key:string; value:SessionRecord; indexes:{ 'by-started':'startedAt' } };
  favorites: { key:string; value:FavoriteRow };
  notes: { key:string; value:NoteRow };
  savedScenes: { key:string; value:SceneRow };
  events: { key:string; value:PracticeEvent; indexes:{ 'by-at':'at' } };
  kana: { key:string; value:KanaRow };
  grammar: { key:string; value:GrammarRow };
  roleplay: { key:string; value:{key:string;value:ActiveRoleplay|null} };
  speakingEvidence: { key:string; value:SpeakingEvidence; indexes:{ 'by-at':'at'; 'by-phrase':'phraseId' } };
  minnaSessions: { key:string; value:MinnaSession; indexes:{ 'by-updated':'updatedAt' } };
  jlptAttempts: { key:string; value:JLPTAttempt; indexes:{ 'by-updated':'updatedAt' } };
  personalVocabulary: { key:string; value:PersonalVocabulary; indexes:{ 'by-lesson':'lessonNumber' } };
  minnaPacks: { key:string; value:MinnaContentPack }; 
}
let dbPromise:Promise<IDBPDatabase<SceneSpeakDB>>|undefined;
function db(){
 if(!dbPromise) dbPromise=openDB<SceneSpeakDB>('scenespeak-local',3,{
  upgrade(database,_transaction,oldVersion){
   const version=oldVersion??0;
   if(version<1){
    database.createObjectStore('profile',{keyPath:'key'});
    database.createObjectStore('settings',{keyPath:'key'});
    const p=database.createObjectStore('progress',{keyPath:'phraseId'}); p.createIndex('by-next-review','nextReviewAt');
    const s=database.createObjectStore('sessions',{keyPath:'id'}); s.createIndex('by-started','startedAt');
    database.createObjectStore('favorites',{keyPath:'phraseId'});
    database.createObjectStore('notes',{keyPath:'phraseId'});
    database.createObjectStore('savedScenes',{keyPath:'id'});
    const e=database.createObjectStore('events',{keyPath:'id'}); e.createIndex('by-at','at');
    database.createObjectStore('kana',{keyPath:'character'});
    database.createObjectStore('grammar',{keyPath:'entryId'});
    database.createObjectStore('roleplay',{keyPath:'key'});
   }
   if(version<2){
    const v=database.createObjectStore('speakingEvidence',{keyPath:'id'}); v.createIndex('by-at','at'); v.createIndex('by-phrase','phraseId');
    const m=database.createObjectStore('minnaSessions',{keyPath:'id'}); m.createIndex('by-updated','updatedAt');
    const j=database.createObjectStore('jlptAttempts',{keyPath:'id'}); j.createIndex('by-updated','updatedAt');
    const u=database.createObjectStore('personalVocabulary',{keyPath:'id'}); u.createIndex('by-lesson','lessonNumber');
   }
   if(version<3){ database.createObjectStore('minnaPacks',{keyPath:'id'}); }
  }
 });
 return dbPromise;
}
export const DEFAULT_PROFILE:Profile={nativeLanguage:'English',targetLanguage:'Japanese',level:'Complete beginner',dailyGoalMinutes:10,goal:'Speak while traveling',onboardingComplete:false,showRomanization:true};
export const DEFAULT_SETTINGS:AppSettings={selectedModel:'gemini-3.8-flash',aiEnabled:false};
export async function getProfile():Promise<Profile>{const d=await db();return (await d.get('profile','main'))?.value??DEFAULT_PROFILE;}
export async function saveProfile(value:Profile):Promise<void>{const d=await db();await d.put('profile',{key:'main',value});}
export async function getSettings():Promise<AppSettings>{const d=await db();return (await d.get('settings','main'))?.value??DEFAULT_SETTINGS;}
export async function saveSettings(value:AppSettings):Promise<void>{const d=await db();await d.put('settings',{key:'main',value});}
export async function getProgress(phraseId:string):Promise<PhraseProgress|undefined>{return (await db()).get('progress',phraseId);}
export async function getAllProgress():Promise<PhraseProgress[]>{return (await db()).getAll('progress');}
export async function saveProgress(value:PhraseProgress):Promise<void>{await (await db()).put('progress',value);}
export async function getSessions():Promise<SessionRecord[]>{return (await db()).getAllFromIndex('sessions','by-started');}
export async function saveSession(value:SessionRecord):Promise<void>{await (await db()).put('sessions',value);}
export async function getFavorites():Promise<string[]>{return (await (await db()).getAll('favorites')).map(row=>row.phraseId);}
export async function setFavorite(phraseId:string,favorite:boolean):Promise<void>{const d=await db();if(favorite) await d.put('favorites',{phraseId,savedAt:new Date().toISOString()});else await d.delete('favorites',phraseId);}
export async function getNotes():Promise<Record<string,string>>{const rows=await (await db()).getAll('notes');return Object.fromEntries(rows.map(x=>[x.phraseId,x.note]));}
export async function saveNote(phraseId:string,note:string):Promise<void>{const d=await db();if(note.trim()) await d.put('notes',{phraseId,note});else await d.delete('notes',phraseId);}
export async function getSavedScenes():Promise<SavedScene[]>{return (await db()).getAll('savedScenes');}
export async function getActiveRoleplay():Promise<ActiveRoleplay|null>{return (await (await db()).get('roleplay','main'))?.value??null;}
export async function saveActiveRoleplay(value:ActiveRoleplay|null):Promise<void>{await (await db()).put('roleplay',{key:'main',value});}
export async function saveScene(scene:SavedScene):Promise<void>{await (await db()).put('savedScenes',scene);}
export async function deleteScene(sceneId:string):Promise<void>{await (await db()).delete('savedScenes',sceneId);}
export async function addEvent(event:PracticeEvent):Promise<void>{await (await db()).put('events',event);}
export async function getEvents():Promise<PracticeEvent[]>{return (await db()).getAllFromIndex('events','by-at');}
export async function getKanaProgress():Promise<Record<string,number>>{const rows=await (await db()).getAll('kana');return Object.fromEntries(rows.map(x=>[x.character,x.score]));}
export async function setKanaScore(character:string,score:number):Promise<void>{await (await db()).put('kana',{character,score:Math.max(0,Math.min(100,Math.round(score)))});}
export async function getGrammarProgress():Promise<Record<string,number>>{const rows=await (await db()).getAll('grammar');return Object.fromEntries(rows.map(x=>[x.entryId,x.score]));}
export async function setGrammarResult(entryId:string,correct:boolean):Promise<void>{const d=await db();const current=await d.get('grammar',entryId)??{entryId,score:0,correct:0,attempts:0};const attempts=current.attempts+1;const good=current.correct+(correct?1:0);await d.put('grammar',{entryId,score:Math.round(100*good/attempts),correct:good,attempts});}
export async function exportBackup():Promise<AppBackup>{
 const [profile,settings,progress,sessions,favorites,notes,savedScenes,kanaProgress,grammarProgress,events]=await Promise.all([getProfile(),getSettings(),getAllProgress(),getSessions(),getFavorites(),getNotes(),getSavedScenes(),getKanaProgress(),getGrammarProgress(),getEvents()]);
 const [speakingEvidence,minnaSessions,jlptAttempts,personalVocabulary,minnaPacks]=await Promise.all([getSpeakingEvidence(),getMinnaSessions(),getJLPTAttempts(),getPersonalVocabulary(),getMinnaPacks()]);
 return {schema:'scenespeak-backup',version:3,exportedAt:new Date().toISOString(),profile,settings,progress,sessions,favorites,notes,savedScenes,kanaProgress,grammarProgress,events,activeRoleplay:await getActiveRoleplay(),speakingEvidence,minnaSessions,jlptAttempts,personalVocabulary,minnaPacks};
}
export function validateBackup(input:unknown):{ok:true;data:AppBackup}|{ok:false;error:string}{
 if(!input||typeof input!=='object')return {ok:false,error:'The file is not a JSON object.'};
 const b=input as Partial<AppBackup>;
 if(b.schema!=='scenespeak-backup'||(b.version!==1&&b.version!==2&&b.version!==3))return {ok:false,error:'This backup format or version is not supported.'};
 if(!b.profile||typeof b.profile!=='object'||!b.settings||typeof b.settings!=='object'||!Array.isArray(b.progress)||!Array.isArray(b.sessions)||!Array.isArray(b.favorites)||!Array.isArray(b.savedScenes)||!b.notes||typeof b.notes!=='object'||Array.isArray(b.notes)||!b.kanaProgress||typeof b.kanaProgress!=='object'||!b.grammarProgress||typeof b.grammarProgress!=='object'||!Array.isArray(b.events)) return {ok:false,error:'The backup is missing required data sections.'};
 const profile=b.profile as Partial<Profile>;const settings=b.settings as Partial<AppSettings>;
 if(typeof profile.nativeLanguage!=='string'||typeof profile.targetLanguage!=='string'||!['Complete beginner','Beginner','Returning learner'].includes(profile.level??'')||![5,10,15].includes(profile.dailyGoalMinutes??0)||typeof profile.goal!=='string'||typeof profile.onboardingComplete!=='boolean'||typeof profile.showRomanization!=='boolean')return {ok:false,error:'The learner profile is invalid or incomplete.'};
 if(typeof settings.selectedModel!=='string'||typeof settings.aiEnabled!=='boolean')return {ok:false,error:'The settings section is invalid or incomplete.'};
 if(b.progress.some(p=>!p||typeof p.phraseId!=='string'||!Array.isArray(p.history)||![p.recognitionScore,p.listeningScore,p.recallScore,p.transferScore].every(n=>typeof n==='number'&&Number.isFinite(n)&&n>=0&&n<=100)||![p.attempts,p.correctWithoutHint,p.correctWithHint,p.incorrectAttempts,p.consecutiveSuccessfulReviews].every(n=>typeof n==='number'&&Number.isFinite(n)&&n>=0)||p.history.some(h=>!h||typeof h.at!=='string'||!['recognition','listening','recall','transfer'].includes(h.skill)||!['independent','hinted','revealed','missed'].includes(h.result))))return {ok:false,error:'One or more phrase progress records are invalid.'};
 if(b.sessions.some(s=>!s||typeof s.id!=='string'||typeof s.sceneId!=='string'||typeof s.startedAt!=='string'))return {ok:false,error:'One or more session records are invalid.'};
 if(b.favorites.some(x=>typeof x!=='string')||b.savedScenes.some(x=>!x||typeof x.id!=='string'||typeof x.title!=='string'||typeof x.moduleId!=='string')||b.events.some(x=>!x||typeof x.id!=='string'||typeof x.at!=='string'||typeof x.type!=='string'))return {ok:false,error:'One or more favorite, scene, or event records are invalid.'};
 if(Object.entries(b.notes as Record<string,unknown>).some(([k,v])=>typeof k!=='string'||typeof v!=='string')||Object.values(b.kanaProgress as Record<string,unknown>).some(v=>typeof v!=='number'||!Number.isFinite(v)||v<0||v>100)||Object.values(b.grammarProgress as Record<string,unknown>).some(v=>typeof v!=='number'||!Number.isFinite(v)||v<0||v>100))return {ok:false,error:'One or more note, kana, or grammar records are invalid.'};
 if(b.activeRoleplay!==undefined&&b.activeRoleplay!==null&&(typeof b.activeRoleplay!=='object'||typeof b.activeRoleplay.id!=='string'||!Array.isArray(b.activeRoleplay.turns)))return {ok:false,error:'The active roleplay record is invalid.'};
 const evidence=(b.speakingEvidence??[]) as unknown[]; const minna=(b.minnaSessions??[]) as unknown[]; const attempts=(b.jlptAttempts??[]) as unknown[]; const personal=(b.personalVocabulary??[]) as unknown[]; const packs=(b.minnaPacks??[]) as unknown[];
 if(!Array.isArray(evidence)||evidence.some(x=>!x||typeof x!=='object'||typeof (x as SpeakingEvidence).id!=='string'||typeof (x as SpeakingEvidence).phraseId!=='string'||typeof (x as SpeakingEvidence).transcript!=='string'||typeof (x as SpeakingEvidence).at!=='string'||typeof (x as SpeakingEvidence).intentUnderstood!=='boolean'||((x as SpeakingEvidence).transcriptEdited!==undefined&&typeof (x as SpeakingEvidence).transcriptEdited!=='boolean')))return {ok:false,error:'One or more speaking-evidence records are invalid.'};
 if(!Array.isArray(minna)||minna.some(x=>!x||typeof x!=='object'||typeof (x as MinnaSession).id!=='string'||typeof (x as MinnaSession).lessonNumber!=='number'||!Array.isArray((x as MinnaSession).answers)))return {ok:false,error:'One or more Minna session records are invalid.'};
 if(!Array.isArray(attempts)||attempts.some(x=>!x||typeof x!=='object'||typeof (x as JLPTAttempt).id!=='string'||!Array.isArray((x as JLPTAttempt).answers)||!Array.isArray((x as JLPTAttempt).questionIds)))return {ok:false,error:'One or more JLPT attempt records are invalid.'};
 if(!Array.isArray(personal)||personal.some(x=>!x||typeof x!=='object'||typeof (x as PersonalVocabulary).id!=='string'||typeof (x as PersonalVocabulary).japanese!=='string'||typeof (x as PersonalVocabulary).lessonNumber!=='number'))return {ok:false,error:'One or more personal vocabulary records are invalid.'};
 if(!Array.isArray(packs)||packs.some(x=>!validateMinnaPack(x).ok))return {ok:false,error:'One or more imported lesson packs are invalid.'};
 const safePacks= packs.map(x=>{const result=validateMinnaPack(x); return result.ok?result.data:null;}).filter((x):x is MinnaContentPack=>x!==null);
 const data={...(b as AppBackup),version:3 as const,speakingEvidence:evidence as SpeakingEvidence[],minnaSessions:minna as MinnaSession[],jlptAttempts:attempts as JLPTAttempt[],personalVocabulary:personal as PersonalVocabulary[],minnaPacks:safePacks};
 return {ok:true,data};
}
export async function restoreBackup(backup:AppBackup,mode:'merge'|'replace'):Promise<void>{
 const d=await db();
 const tx=d.transaction(['profile','settings','progress','sessions','favorites','notes','savedScenes','events','kana','grammar','roleplay','speakingEvidence','minnaSessions','jlptAttempts','personalVocabulary','minnaPacks'], 'readwrite');
 if(mode==='replace') for(const name of ['profile','settings','progress','sessions','favorites','notes','savedScenes','events','kana','grammar','roleplay','speakingEvidence','minnaSessions','jlptAttempts','personalVocabulary','minnaPacks'] as const) await tx.objectStore(name).clear();
 await tx.objectStore('profile').put({key:'main',value:backup.profile});
 // Security boundary: keys are never part of backups. Remove any stale exported key-shaped field before persistence.
 const safeSettings:AppSettings={selectedModel:backup.settings.selectedModel,aiEnabled:backup.settings.aiEnabled,installDismissed:backup.settings.installDismissed,lastBackupAt:backup.settings.lastBackupAt,lastRoute:backup.settings.lastRoute};
 await tx.objectStore('settings').put({key:'main',value:safeSettings});
 await tx.objectStore('roleplay').put({key:'main',value:backup.activeRoleplay??null});
 for(const x of backup.progress) await tx.objectStore('progress').put(x);
 for(const x of backup.sessions) await tx.objectStore('sessions').put(x);
 for(const x of backup.favorites) await tx.objectStore('favorites').put({phraseId:x,savedAt:new Date().toISOString()});
 for(const [phraseId,note] of Object.entries(backup.notes)) await tx.objectStore('notes').put({phraseId,note});
 for(const x of backup.savedScenes) await tx.objectStore('savedScenes').put(x);
 for(const x of backup.events) await tx.objectStore('events').put(x);
 for(const [character,score] of Object.entries(backup.kanaProgress)) await tx.objectStore('kana').put({character,score});
 for(const [entryId,score] of Object.entries(backup.grammarProgress)) await tx.objectStore('grammar').put({entryId,score,correct:score,attempts:1});
 for(const x of backup.speakingEvidence??[]) await tx.objectStore('speakingEvidence').put(x);
 for(const x of backup.minnaSessions??[]) await tx.objectStore('minnaSessions').put(x);
 for(const x of backup.jlptAttempts??[]) await tx.objectStore('jlptAttempts').put(x);
 for(const x of backup.personalVocabulary??[]) await tx.objectStore('personalVocabulary').put(x);
 for(const x of backup.minnaPacks??[]) await tx.objectStore('minnaPacks').put(x);
 await tx.done;
}
export async function clearAllData():Promise<void>{
 const d=await db(); const tx=d.transaction(['profile','settings','progress','sessions','favorites','notes','savedScenes','events','kana','grammar','roleplay','speakingEvidence','minnaSessions','jlptAttempts','personalVocabulary','minnaPacks'],'readwrite');
 for(const name of ['profile','settings','progress','sessions','favorites','notes','savedScenes','events','kana','grammar','roleplay','speakingEvidence','minnaSessions','jlptAttempts','personalVocabulary','minnaPacks'] as const) await tx.objectStore(name).clear(); await tx.done;
 sessionStorage.removeItem('scenespeak-gemini-key'); localStorage.removeItem('scenespeak-gemini-key'); localStorage.removeItem('scenespeak-show-romaji');
}
export async function dataCounts(){const [progress,sessions,favorites,savedScenes,events]=await Promise.all([getAllProgress(),getSessions(),getFavorites(),getSavedScenes(),getEvents()]);return {progress:progress.length,sessions:sessions.length,favorites:favorites.length,savedScenes:savedScenes.length,events:events.length,due:progress.filter(p=>!p.nextReviewAt||new Date(p.nextReviewAt).getTime()<=Date.now()).length};}


// Schema-v2 enhancement stores. Existing v1 learner data is preserved by IndexedDB upgrade.
export async function getSpeakingEvidence():Promise<SpeakingEvidence[]>{return (await db()).getAllFromIndex('speakingEvidence','by-at');}
export async function getSpeakingEvidenceForPhrase(phraseId:string):Promise<SpeakingEvidence[]>{return (await db()).getAllFromIndex('speakingEvidence','by-phrase',IDBKeyRange.only(phraseId));}
export async function saveSpeakingEvidence(value:SpeakingEvidence):Promise<void>{await (await db()).put('speakingEvidence',value);}
export async function getMinnaSessions():Promise<MinnaSession[]>{return (await db()).getAllFromIndex('minnaSessions','by-updated');}
export async function getMinnaSession(id:string):Promise<MinnaSession|undefined>{return (await db()).get('minnaSessions',id);}
export async function saveMinnaSession(value:MinnaSession):Promise<void>{await (await db()).put('minnaSessions',value);}
export async function getJLPTAttempts():Promise<JLPTAttempt[]>{return (await db()).getAllFromIndex('jlptAttempts','by-updated');}
export async function saveJLPTAttempt(value:JLPTAttempt):Promise<void>{await (await db()).put('jlptAttempts',value);}
export async function getPersonalVocabulary(lessonNumber?:number):Promise<PersonalVocabulary[]>{const d=await db();return lessonNumber===undefined?d.getAll('personalVocabulary'):d.getAllFromIndex('personalVocabulary','by-lesson',IDBKeyRange.only(lessonNumber));}
export async function savePersonalVocabulary(value:PersonalVocabulary):Promise<void>{await (await db()).put('personalVocabulary',value);}
export async function deletePersonalVocabulary(id:string):Promise<void>{await (await db()).delete('personalVocabulary',id);}
export async function getMinnaPacks():Promise<MinnaContentPack[]>{return (await db()).getAll('minnaPacks');}
export async function saveMinnaPack(value:MinnaContentPack):Promise<void>{await (await db()).put('minnaPacks',value);}
export async function deleteMinnaPack(id:string):Promise<void>{await (await db()).delete('minnaPacks',id);}
