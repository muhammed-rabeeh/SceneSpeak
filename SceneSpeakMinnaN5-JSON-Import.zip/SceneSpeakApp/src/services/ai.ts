import { GoogleGenAI, ThinkingLevel } from '@google/genai';
import { z } from 'zod';
import type { LearningRoadmapPhase, LearningPurpose, LearningTarget, LearningTimelineDays, Profile, Phrase, SavedScene } from '../domain/types';

export const GEMINI_MODELS = [
 {id:'gemini-4-argon',name:'Gemini 4 Argon',badge:'Most capable',status:'Stable'},
 {id:'gemini-3.1-pro-preview',name:'Gemini 3.1 Pro',badge:'Advanced reasoning',status:'Preview'},
 {id:'gemini-3.8-flash',name:'Gemini 3.8 Flash',badge:'Default',status:'Stable'},
] as const;
export type GeminiModelId = typeof GEMINI_MODELS[number]['id'];
export const DEFAULT_MODEL:GeminiModelId='gemini-3.8-flash';

const phraseSchema = z.object({
 japanese:z.string().min(1).max(100), kana:z.string().min(1).max(120), romanization:z.string().min(1).max(160),
 meaning:z.string().min(1).max(180), usageNote:z.string().min(1).max(240), pattern:z.string().min(1).max(80),
});
const generatedSceneSchema = z.object({
 title:z.string().min(2).max(70), setting:z.string().min(2).max(100), learnerGoal:z.string().min(4).max(180),
 estimatedMinutes:z.number().int().min(3).max(20), level:z.enum(['starter','beginner','elementary']),
 targetPatterns:z.array(phraseSchema).min(1).max(4), newVocabulary:z.array(phraseSchema).max(8),
 npcOpeningLine:z.string().min(1).max(160), turnPrompts:z.array(z.string().min(1).max(180)).min(2).max(8),
 expectedUsefulPhrases:z.array(phraseSchema).min(1).max(8), hints:z.array(z.string().min(1).max(140)).max(8),
 translations:z.array(z.string().min(1).max(180)).min(1).max(8), culturalNotes:z.string().max(360),
 transferVariations:z.array(z.string().min(1).max(180)).min(1).max(4),
});
export type GeneratedScene = z.infer<typeof generatedSceneSchema>;

export function getGeminiKey():string {
 return sessionStorage.getItem('scenespeak-gemini-key') ?? localStorage.getItem('scenespeak-gemini-key') ?? '';
}
export function setGeminiKey(key:string,remember=false):void {
 const cleaned=key.trim();
 sessionStorage.removeItem('scenespeak-gemini-key'); localStorage.removeItem('scenespeak-gemini-key');
 if(cleaned) (remember?localStorage:sessionStorage).setItem('scenespeak-gemini-key',cleaned);
}
export function removeGeminiKey():void { sessionStorage.removeItem('scenespeak-gemini-key'); localStorage.removeItem('scenespeak-gemini-key'); }
export function mapAiError(error:unknown):string {
 const msg=error instanceof Error?error.message:String(error??''); const lower=msg.toLowerCase();
 if(typeof navigator!=='undefined'&&navigator.onLine===false) return 'You appear to be offline. Curated lessons still work; reconnect to use AI.';
 if(lower.includes('api_key_invalid')||lower.includes('invalid api key')||lower.includes('api key not valid')||lower.includes('unauthenticated')||lower.includes('401')) return 'Google rejected this API key. Check the key in Google AI Studio and confirm it is enabled for the Gemini API.';
 if(lower.includes('429')||lower.includes('quota')||lower.includes('resource_exhausted')||lower.includes('rate limit')) return 'Google reported a quota or rate limit. Check your project’s usage and billing settings, or retry later.';
 if(lower.includes('404')||lower.includes('not found')||lower.includes('model not found')||lower.includes('unsupported model')) return 'This model is unavailable to your key or project. Choose another model in Settings.';
 if(lower.includes('403')||lower.includes('permission')||lower.includes('forbidden')) return 'Google denied permission for this request. Check your project, API access, and key restrictions.';
 if(lower.includes('timeout')||lower.includes('timed out')||lower.includes('aborted')) return 'The request took too long. Try again on a stronger connection, or continue with a scripted scene.';
 if(lower.includes('blocked')||lower.includes('safety')) return 'Gemini did not return text because the request was blocked by a safety or policy filter. Try a shorter prompt or another model.';
 if(lower.includes('no visible text')||lower.includes('empty response')) return 'Gemini received the request but returned no visible text. Try Gemini 3.8 Flash, check model access, and test again.';
 if(lower.includes('json')||lower.includes('parse')) return 'The AI response was not in the structured format needed for this activity. Nothing was saved; retry or use a curated lesson.';
 return 'The AI request failed. Your local learning progress is safe. Check the connection and model settings, then retry.';
}
async function withTimeout<T>(promise:Promise<T>,ms=25000):Promise<T>{
 let timer:ReturnType<typeof setTimeout>|undefined;
 try { return await Promise.race([promise,new Promise<T>((_,reject)=>{timer=setTimeout(()=>reject(new Error('Request timed out')),ms);})]); }
 finally { if(timer!==undefined) clearTimeout(timer); }
}
function client(apiKey:string):GoogleGenAI {
 if(!apiKey.trim()) throw new Error('Missing API key');
 // The user enters this key at runtime. Browser use is an explicit personal-use risk trade-off explained in Settings.
 return new GoogleGenAI({apiKey:apiKey.trim(),httpOptions:{apiVersion:'v1beta'}});
}
async function generateText(apiKey:string,model:string,prompt:string,maxOutputTokens=1200):Promise<string>{
 const ai=client(apiKey);
 // Gemini 3/4 count internal reasoning tokens toward maxOutputTokens. Keep
 // reasoning low for these short tutor tasks and give the model enough headroom
 // that JSON isn't cut off before any visible answer is produced.
 const outputLimit=model.startsWith('gemini-4-argon')?Math.max(maxOutputTokens,32768):Math.max(maxOutputTokens,8192);
 const response=await withTimeout(ai.models.generateContent({model,contents:prompt,config:{maxOutputTokens:outputLimit,responseMimeType:'application/json',thinkingConfig:{thinkingLevel:ThinkingLevel.LOW}}}));
 const text=response.text?.trim(); if(!text) throw new Error('Gemini returned no visible text for the structured response'); return text;
}
function parseJson<T>(raw:string,schema:z.ZodType<T>):T{
 const trimmed=raw.replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'');
 let parsed:unknown; try {parsed=JSON.parse(trimmed);} catch {throw new Error('Invalid JSON response');}
 return schema.parse(parsed);
}
export async function testConnection(apiKey:string,model:string):Promise<string>{
 const ai=client(apiKey);
 // This is a connectivity test, not a structured-generation test. Requiring JSON
 // here made an otherwise successful request look broken when a model returned
 // no visible JSON (for example, a blocked or token-limited response).
 const response=await withTimeout(ai.models.generateContent({
  model,
  contents:'Reply with exactly the word OK and no other text.',
  config:{thinkingConfig:{thinkingLevel:ThinkingLevel.LOW}},
 }),20000);
 const text=typeof response.text==='string'?response.text.trim():'';
 if(!text){
  const details=response as unknown as {promptFeedback?:{blockReason?:string};candidates?:Array<{finishReason?:string}>};
  const reason=details.promptFeedback?.blockReason??details.candidates?.[0]?.finishReason;
  if(reason&&/safety|blocklist|prohibited|recitation/i.test(reason)){
   throw new Error(`Gemini returned no visible text because the response was blocked (${reason}).`);
  }
  throw new Error(`Gemini returned no visible text${reason?` (finish reason: ${reason})`:''}. The request reached the API but did not produce a reply.`);
 }
 return `Connected to ${model}. Gemini returned a text response.`;
}

const speechEvaluationSchema = z.object({
 intentUnderstood:z.boolean(),
 oneImprovement:z.string().min(1).max(220),
 grammarFeedback:z.string().min(1).max(260),
 naturalAlternative:z.string().min(1).max(160),
 partnerReply:z.string().min(1).max(160),
 replyMeaning:z.string().min(1).max(180),
 hint:z.string().min(1).max(180),
});
export type SpeechEvaluation = z.infer<typeof speechEvaluationSchema> & { transcript:string };

/** Transcribe a learner-approved short recording using the documented inlineData path. */
export async function transcribeJapaneseAudio(input:{apiKey:string;audioBase64:string;mimeType:string}):Promise<string>{
 if(!input.apiKey.trim())throw new Error('Missing API key');
 if(!input.audioBase64)throw new Error('No recorded audio was provided');
 if(input.audioBase64.length>18_000_000)throw new Error('Recording is too large. Keep the clip under 15 seconds and try again.');
 const ai=client(input.apiKey);
 const response=await withTimeout(ai.models.generateContent({
  model:'gemini-3.8-flash',
  contents:[
   {text:'Transcribe the Japanese speech in the attached short audio clip. Return only the words actually heard, in Japanese writing. Do not translate, explain, or guess the intended answer. If no clear speech is audible, return an empty response.'},
   {inlineData:{data:input.audioBase64,mimeType:input.mimeType.split(';')[0]}}
  ],
  config:{maxOutputTokens:2048,thinkingConfig:{thinkingLevel:ThinkingLevel.LOW}},
 }),30000);
 return String(response?.text??'').trim().slice(0,600);
}

/** Evaluate a visible transcript; learners may correct transcription errors before this call. */
export async function evaluateTranscriptText(input:{apiKey:string;model:string;transcript:string;scene:string;goal:string;targetPhrase:string;acceptedMeanings?:string[];conversationContext?:string}):Promise<SpeechEvaluation>{
 const transcript=input.transcript.trim().slice(0,600);
 if(!input.apiKey.trim())throw new Error('Missing API key');
 if(!transcript)throw new Error('Enter or correct the transcript before requesting feedback.');
 const prompt=`You are a supportive Japanese conversation coach. Evaluate the learner-confirmed transcript from a short recording. Do not claim pronunciation/accent assessment, or treat the reference phrase as the only correct answer. Accept natural Japanese variants that communicate the same goal. Assess meaning and one high-value grammar/word-choice point only. If the transcript does not communicate the goal, say so kindly and respond in character with a short Japanese reply that helps repair the conversation. Return JSON only with keys intentUnderstood (boolean), oneImprovement (brief English sentence), grammarFeedback (brief English sentence about particles/form/naturalness, or say it is understandable), naturalAlternative (a natural Japanese sentence), partnerReply (short Japanese character response appropriate to the scene and actual transcript), replyMeaning (English meaning of partnerReply), hint (a short cue for retry). Never claim objective pronunciation scoring.
Scene: ${input.scene}
Communication goal: ${input.goal}
Target phrase example, not the only acceptable answer: ${input.targetPhrase}
Possible intent meanings: ${(input.acceptedMeanings??[]).slice(0,6).join(' | ')}
Prior conversation: ${(input.conversationContext??'').slice(0,1000)}
Transcript from the recording, checked by the learner: ${transcript}`;
 const raw=await generateText(input.apiKey,input.model,prompt,700);
 const evaluation=parseJson(raw,speechEvaluationSchema);
 return {...evaluation,transcript};
}

/** Convenience adapter for callers that want transcription and evaluation in one step. */
export async function evaluateRecordedJapanese(input:{apiKey:string;model:string;audioBase64:string;mimeType:string;scene:string;goal:string;targetPhrase:string;acceptedMeanings?:string[];conversationContext?:string}):Promise<SpeechEvaluation>{
 const transcript=await transcribeJapaneseAudio({apiKey:input.apiKey,audioBase64:input.audioBase64,mimeType:input.mimeType});
 if(!transcript)return {transcript:'',intentUnderstood:false,oneImprovement:'No clear speech was detected. Try speaking a little closer to the microphone, then record again.',grammarFeedback:'No transcript was returned, so the Japanese could not be evaluated.',naturalAlternative:input.targetPhrase,partnerReply:'もう一度お願いします。',replyMeaning:'One more time, please.',hint:'Try a short phrase, one chunk at a time.'};
 return evaluateTranscriptText({...input,transcript});
}

export async function generateScene(input:{apiKey:string;model:string;setting:string;goal:string;level:string;duration:number;allowNew:boolean;knownPhrases:string[]}):Promise<GeneratedScene>{
 const prompt=`You are a careful Japanese speaking coach for an English-speaking beginner. Return ONLY valid JSON matching this structure exactly: {"title":"string","setting":"string","learnerGoal":"string","estimatedMinutes":number,"level":"starter|beginner|elementary","targetPatterns":[{"japanese":"string","kana":"string","romanization":"string","meaning":"string","usageNote":"string","pattern":"string"}],"newVocabulary":[same phrase object],"npcOpeningLine":"string","turnPrompts":["string"],"expectedUsefulPhrases":[same phrase object],"hints":["string"],"translations":["string"],"culturalNotes":"string","transferVariations":["string"]}. Japanese must be natural polite beginner language. Include kana readings and Hepburn-style romanization. No unsupported claims about the learner. Make a playable scene with one clear goal, 2–4 target phrases, no more than ${input.allowNew?4:1} truly new phrases, 2–6 learner turns, at least 1 transfer variation, concise English guidance. Avoid unsafe or offensive content.\nSetting: ${input.setting}\nLearner goal: ${input.goal}\nLevel: ${input.level}\nApprox minutes: ${input.duration}\nAllowed new vocabulary: ${input.allowNew?'yes, max 4':'mostly known language, nearly none'}\nKnown phrases to reuse: ${input.knownPhrases.slice(0,20).join(' | ')||'こんにちは; すみません; もう一度お願いします'}\nUse ${input.level==='Complete beginner'?'only familiar polite structures and very short turns':'short polite beginner turns'}. Do not put HTML in output.`;
 const schema=z.object({
  title:z.string().min(2).max(70),setting:z.string().min(2).max(100),learnerGoal:z.string().min(4).max(180),estimatedMinutes:z.number().int().min(3).max(20),level:z.enum(['starter','beginner','elementary']),
  targetPatterns:z.array(phraseSchema).min(1).max(4),newVocabulary:z.array(phraseSchema).max(8),npcOpeningLine:z.string().min(1).max(160),turnPrompts:z.array(z.string().min(1).max(180)).min(2).max(8),expectedUsefulPhrases:z.array(phraseSchema).min(1).max(8),hints:z.array(z.string().min(1).max(140)).max(8),translations:z.array(z.string().min(1).max(180)).min(1).max(8),culturalNotes:z.string().max(360),transferVariations:z.array(z.string().min(1).max(180)).min(1).max(4)
 });
 let raw=''; try {raw=await generateText(input.apiKey,input.model,prompt,2200);return parseJson(raw,schema);} catch(first){
  const repair=`Convert the following response to valid JSON matching the exact schema described earlier. Do not add commentary. Keep the Japanese conservative and beginner-friendly. Response to repair:\n${raw.slice(0,8000)}\nOriginal error: ${first instanceof Error?first.message:'schema validation failed'}`;
  raw=await generateText(input.apiKey,input.model,repair,2200);return parseJson(raw,schema);
 }
}
export async function roleplayTurn(input:{apiKey:string;model:string;scene:GeneratedScene;history:{speaker:'npc'|'learner';text:string}[];learnerText:string}):Promise<{japanese:string;kana:string;romanization:string;meaning:string;coaching:string;nextPrompt:string}>{
 const schema=z.object({japanese:z.string().min(1).max(180),kana:z.string().min(1).max(200),romanization:z.string().min(1).max(240),meaning:z.string().min(1).max(180),coaching:z.string().max(240),nextPrompt:z.string().max(180)});
 const prompt=`You are the NPC in this Japanese beginner roleplay. Stay in context. Use short polite Japanese with mostly known phrases. Give one concise correction at most. Never grade pronunciation because no audio was evaluated. Reply ONLY as JSON: {"japanese":"...","kana":"...","romanization":"...","meaning":"...","coaching":"supportive feedback or empty string","nextPrompt":"what the learner can say next in English"}. Scene: ${JSON.stringify(input.scene).slice(0,9000)}. Recent conversation: ${JSON.stringify(input.history.slice(-8))}. Learner just said: ${input.learnerText.slice(0,500)}`;
 const raw=await generateText(input.apiKey,input.model,prompt,700);
 try{return parseJson(raw,schema);}catch{throw new Error('Invalid JSON response');}
}
export async function tutorExplain(input:{apiKey:string;model:string;japanese:string;learnerAttempt?:string;question?:string}):Promise<{explanation:string;standardVersion:string;naturalVariants:string[];tip:string}>{
 const schema=z.object({explanation:z.string().min(1).max(800),standardVersion:z.string().min(1).max(160),naturalVariants:z.array(z.string().min(1).max(160)).max(4),tip:z.string().min(1).max(240)});
 const prompt=`Act as a cautious Japanese tutor for an English-speaking beginner. Explain briefly, mark uncertainty when relevant, never claim native-speaker verification. Return only JSON: {"explanation":"plain English","standardVersion":"Japanese","naturalVariants":["Japanese"],"tip":"one practical tip"}. Target phrase: ${input.japanese}. Learner attempt: ${(input.learnerAttempt??'not provided').slice(0,300)}. Question: ${(input.question??'Explain the meaning and usage').slice(0,300)}. Include kana/reading and short transliteration in explanation if useful. Do not output HTML.`;
 return parseJson(await generateText(input.apiKey,input.model,prompt,700),schema);
}
const roadmapFocusSchema=z.enum(['kana','minna','kanji','grammar','listening','scenes','speaking','review','jlpt-n5','ai']);
const roadmapPhaseSchema=z.object({
 title:z.string().min(2).max(100),outcome:z.string().min(10).max(260),
 vocabularyFocus:z.string().min(8).max(260),grammarFocus:z.string().min(8).max(260),
 kanjiFocus:z.string().min(8).max(260),listeningFocus:z.string().min(8).max(260),
 speakingMission:z.string().min(8).max(260),checkpoint:z.string().min(8).max(260),
 primaryRoute:roadmapFocusSchema,
});
const generatedRoadmapSchema=z.object({
 title:z.string().min(3).max(100),summary:z.string().min(30).max(650),
 phases:z.array(roadmapPhaseSchema).min(6).max(10),
});
type GeneratedRoadmapResponse = z.infer<typeof generatedRoadmapSchema>;
export type GeneratedRoadmap = Omit<GeneratedRoadmapResponse,'phases'> & { phases: LearningRoadmapPhase[] };

/** Generates a structured learning blueprint. Daily entries are then deterministically expanded on-device for the full chosen timeline. */
export async function generateLearningRoadmap(input:{
 apiKey:string;model:string;goal:string;details?:string;level:Profile['level'];purpose:LearningPurpose;target:LearningTarget;
 timelineDays:LearningTimelineDays;studyDaysPerWeek:3|4|5|6|7;dailyMinutes:5|10|15|20|30;nativeLanguage:string;targetLanguage:string;
}):Promise<GeneratedRoadmap>{
 const prompt=`You are a careful, structured Japanese curriculum designer. Create a realistic, progressive learning roadmap for one learner. Return ONLY JSON matching exactly: {"title":"...","summary":"...","phases":[{"title":"...","outcome":"...","vocabularyFocus":"...","grammarFocus":"...","kanjiFocus":"...","listeningFocus":"...","speakingMission":"...","checkpoint":"...","primaryRoute":"kana|minna|kanji|grammar|listening|scenes|speaking|review|jlpt-n5|ai"}]}. Provide 8 distinct phases (minimum 6, maximum 10), in prerequisite order. Each phase must be detailed enough to guide several daily sessions; do not make phases interchangeable or just rename them. For each phase specify exactly what to learn, practise, and check. Scaffold from the learner's current foundation toward the requested goal. For timelines of 730 days or more, reserve later phases for intermediate-to-advanced integration, authentic or graded input, nuance, and increasingly independent real-life tasks rather than stretching beginner topics across the whole plan. Include reading, kanji, listening, grammar, vocabulary, active recall, and speaking/application even if the goal emphasizes one skill. Give each phase a suitable primaryRoute. Do not invent that SceneSpeak contains a complete advanced or higher-level static course: the built-in structured course is mainly beginner/N5 and available practice destinations are kana, Minna companion lessons, kanji, grammar, listening, scenes, speaking, review, built-in JLPT N5, and AI roleplay. When a plan goes beyond that content, say in the summary/phases that the learner must supply or import verified target-level materials and use AI roleplay cautiously. Japanese learning details should be broadly accurate; prefer frequency and comprehension in context over arbitrary character quotas. Do not promise fluency, exam passes, or native-like comprehension by the deadline. The goal is a roadmap and measurable habits, not a guarantee. Use ${input.nativeLanguage} for explanations and teach ${input.targetLanguage}. User goal: ${input.goal.slice(0,500)}. Additional interests/context: ${(input.details??'Not specified').slice(0,1000)}. Chosen purpose: ${input.purpose}. Chosen target: ${input.target}. Starting level: ${input.level}. Total target calendar timeline: ${input.timelineDays} days. Practice schedule: ${input.studyDaysPerWeek} days per week, ${input.dailyMinutes} minutes each study day. Make the sequence realistic for this schedule and level. Keep every field actionable, concise and distinct. For JLPT N4-N1 or advanced media/work goals, be transparent that built-in exam content is N5-focused and matching-level material is necessary. Never output HTML or markdown fences.`;
 const raw=await generateText(input.apiKey,input.model,prompt,5000);
 const parsed=parseJson(raw,generatedRoadmapSchema);
 const phases:LearningRoadmapPhase[]=parsed.phases.map((p,index)=>({...p,id:`ai-phase-${index+1}`}));
 return {...parsed,phases};
}

export function toSavedScene(g:GeneratedScene,id=`ai-${Date.now()}`):SavedScene{
 const p:Phrase[]=[...g.targetPatterns,...g.newVocabulary,...g.expectedUsefulPhrases].slice(0,12).map((x,i)=>({id:`${id}-p${i+1}`,moduleId:'m12',nativeScript:x.japanese,kana:x.kana,romanization:x.romanization,meaning:x.meaning,usageNote:x.usageNote,pattern:x.pattern,tags:['ai-generated'],difficulty:g.level,example:x.japanese,exampleMeaning:x.meaning,category:'ai-generated',synthesizedAudio:true}));
 return {id,moduleId:'m12',order:99,title:g.title,description:g.learnerGoal,setting:g.setting,emoji:'✨',estimatedMinutes:g.estimatedMinutes,level:g.level,missionGoal:g.learnerGoal,phraseIds:p.map(x=>x.id),aiGenerated:true,createdAt:new Date().toISOString(),targetPhrases:p,turns:[{speaker:'npc',japanese:g.npcOpeningLine,meaning:g.translations[0]}]};
}


/** UI-facing provider contract keeps request details out of React components. */
export interface AiProvider {
 testConnection(apiKey:string,model:string):Promise<string>;
 generateScene(input:Parameters<typeof generateScene>[0]):Promise<GeneratedScene>;
 roleplayTurn(input:Parameters<typeof roleplayTurn>[0]):ReturnType<typeof roleplayTurn>;
 tutorExplain(input:Parameters<typeof tutorExplain>[0]):ReturnType<typeof tutorExplain>;
}
export class GeminiProvider implements AiProvider {
 testConnection= testConnection;
 generateScene= generateScene;
 roleplayTurn= roleplayTurn;
 tutorExplain= tutorExplain;
}
export const aiProvider:AiProvider=new GeminiProvider();
