import { createClient } from '@supabase/supabase-js';

const projectUrl = import.meta.env.VITE_SUPABASE_URL?.trim() ?? '';
const publishableKey = import.meta.env.VITE_SUPABASE_ANON_KEY?.trim() ?? '';

/**
 * Optional static-client Supabase integration. This deliberately uses only
 * the public/publishable key; all cloud rows are protected by user-scoped RLS.
 * Never put a service_role key in a VITE_* variable or ship it to a browser.
 */
export const supabaseConfigured = Boolean(projectUrl && publishableKey);
export const supabaseClient = supabaseConfigured
  ? createClient(projectUrl, publishableKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
    })
  : null;
