import { useCallback, useEffect, useRef, useState } from 'react';
import { Activity, AlertCircle, CheckCircle2, Clock3, Lightbulb, Mic, Play, RotateCcw, Send, ShieldCheck, Square, Volume2, X } from 'lucide-react';
import type { SpeechEvaluation } from '../services/ai';
import { evaluateTranscriptText, transcribeJapaneseAudio, mapAiError } from '../services/ai';
import { applyPractice } from '../domain/scoring';
import { scheduleNextReview } from '../domain/scheduler';
import type { SpeakingEvidence } from '../domain/enhancements';
import { addEvent, getProgress, saveProgress, saveSpeakingEvidence } from '../services/storage';

export interface SpeakingRecorderProps {
  phraseId: string;
  targetJapanese: string;
  targetMeaning: string;
  reading?: string;
  romanization?: string;
  contextTitle: string;
  contextDescription: string;
  partnerOpeningJapanese?: string;
  partnerOpeningMeaning?: string;
  sceneId: string;
  selectedModel: string;
  acceptedMeanings?: string[];
  conversationContext?: string;
  showModelAnswerInitially?: boolean;
  initialHintLevel?: number;
  assessmentSkill?: 'recall' | 'transfer';
  onEvaluated?: (evidence: SpeakingEvidence) => void | Promise<void>;
}

type RecorderStatus = 'idle' | 'recording' | 'ready' | 'sending' | 'transcribed' | 'evaluated';

function toBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read the temporary audio clip. Please record again.'));
    reader.onload = () => {
      const value = String(reader.result ?? '');
      const comma = value.indexOf(',');
      if (comma < 0) reject(new Error('The recorded audio could not be prepared for upload.'));
      else resolve(value.slice(comma + 1));
    };
    reader.readAsDataURL(blob);
  });
}
function normalizeAudioMime(mime: string): string {
  const clean = mime.split(';')[0].trim().toLowerCase();
  if (clean === 'audio/x-wav') return 'audio/wav';
  if (clean === 'audio/x-m4a' || clean === 'audio/mp4') return 'audio/m4a';
  return clean || 'audio/webm';
}
function sayJapanese(text: string, rate = 0.86, voiceURI?: string) {
  if (!('speechSynthesis' in window)) return false;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'ja-JP';
  utterance.rate = rate;
  const voices = window.speechSynthesis.getVoices().filter(item => item.lang.toLowerCase().startsWith('ja'));
  const voice = voices.find(item => item.voiceURI === voiceURI) ?? voices[0];
  if (voice) utterance.voice = voice;
  window.speechSynthesis.speak(utterance);
  return true;
}

export function SpeakingRecorder(props: SpeakingRecorderProps) {
  const { phraseId, targetJapanese, targetMeaning, reading, romanization, contextTitle, contextDescription, partnerOpeningJapanese = 'いらっしゃいませ。', partnerOpeningMeaning = 'Welcome! A common greeting in a café or shop.', sceneId, selectedModel, acceptedMeanings = [], conversationContext = '', showModelAnswerInitially = false, initialHintLevel = 0, assessmentSkill = 'recall', onEvaluated } = props;
  const [status, setStatus] = useState<RecorderStatus>('idle');
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState('');
  const [hintLevel, setHintLevel] = useState(Math.max(0, Math.min(3, initialHintLevel))); 
  const [showModelAnswer, setShowModelAnswer] = useState(showModelAnswerInitially);
  const [evaluation, setEvaluation] = useState<SpeechEvaluation | null>(null);
  const [recognizedTranscript, setRecognizedTranscript] = useState('');
  const [transcriptDraft, setTranscriptDraft] = useState('');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [busyAction, setBusyAction] = useState(false);
  const [showPartnerScript, setShowPartnerScript] = useState(false);
  const [showPartnerMeaning, setShowPartnerMeaning] = useState(false);
  const [voiceURI, setVoiceURI] = useState('');
  const [japaneseVoices, setJapaneseVoices] = useState<SpeechSynthesisVoice[]>([]);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const cancelledRef = useRef(false);
  const startedAtRef = useRef<number>(0);
  const tickRef = useRef<number | undefined>(undefined);
  const blobUrlRef = useRef('');

  const cleanupStream = useCallback(() => {
    streamRef.current?.getTracks().forEach(track => track.stop());
    streamRef.current = null;
    if (tickRef.current !== undefined) window.clearInterval(tickRef.current);
    tickRef.current = undefined;
  }, []);

  const clearAudio = useCallback(() => {
    if (blobUrlRef.current) URL.revokeObjectURL(blobUrlRef.current);
    blobUrlRef.current = '';
    setAudioUrl('');
    setAudioBlob(null);
  }, []);

  useEffect(() => {
    if (!audioBlob) return;
    const url = URL.createObjectURL(audioBlob);
    blobUrlRef.current = url;
    setAudioUrl(url);
    return () => {
      URL.revokeObjectURL(url);
      if (blobUrlRef.current === url) blobUrlRef.current = '';
    };
  }, [audioBlob]);

  useEffect(() => {
    if (!('speechSynthesis' in window)) return;
    const loadVoices = () => {
      const voices = window.speechSynthesis.getVoices().filter(voice => voice.lang.toLowerCase().startsWith('ja'));
      setJapaneseVoices(voices);
      setVoiceURI(current => current || voices[0]?.voiceURI || '');
    };
    loadVoices();
    window.speechSynthesis.addEventListener('voiceschanged', loadVoices);
    return () => window.speechSynthesis.removeEventListener('voiceschanged', loadVoices);
  }, []);

  useEffect(() => () => {
    cleanupStream();
    const recorder = recorderRef.current;
    if (recorder && recorder.state !== 'inactive') {
      try { recorder.stop(); } catch { /* recorder may already be stopping */ }
    }
    if (blobUrlRef.current) URL.revokeObjectURL(blobUrlRef.current);
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
  }, [cleanupStream]);

  const stopRecording = useCallback((cancel = false) => {
    cancelledRef.current = cancel;
    const recorder = recorderRef.current;
    if (recorder && recorder.state !== 'inactive') {
      try { recorder.stop(); } catch { cleanupStream(); }
    } else {
      cleanupStream();
      if (cancel) { clearAudio(); setStatus('idle'); }
    }
  }, [cleanupStream, clearAudio]);

  const startRecording = useCallback(async () => {
    setError(''); setNotice(''); setEvaluation(null); setRecognizedTranscript(''); setTranscriptDraft(''); clearAudio(); setRecordingSeconds(0);
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
      setError('This browser does not support microphone recording. Try a current Chrome, Edge, or Safari browser over HTTPS.');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
      streamRef.current = stream;
      const mimeCandidates = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus'];
      const supported = mimeCandidates.find(mime => MediaRecorder.isTypeSupported(mime));
      const recorder = supported ? new MediaRecorder(stream, { mimeType: supported }) : new MediaRecorder(stream);
      chunksRef.current = [];
      cancelledRef.current = false;
      recorderRef.current = recorder;
      recorder.ondataavailable = event => { if (event.data.size > 0) chunksRef.current.push(event.data); };
      recorder.onerror = () => { cleanupStream(); setStatus('idle'); setError('The browser could not record this clip. Check microphone permission and try again.'); };
      recorder.onstop = () => {
        cleanupStream();
        const type = recorder.mimeType || chunksRef.current.find((chunk): chunk is Blob => chunk instanceof Blob)?.type || 'audio/webm';
        const blob = new Blob(chunksRef.current, { type });
        chunksRef.current = [];
        recorderRef.current = null;
        if (cancelledRef.current) {
          setStatus('idle'); setNotice('Recording canceled. No audio was sent.');
          clearAudio();
        } else if (blob.size < 1200) {
          setStatus('idle'); setError('The clip is very short or silent. Record a full phrase and try again.');
        } else if (blob.size > 7_000_000) {
          setStatus('idle'); setError('This recording is too large. Keep the clip under 15 seconds and try again.');
        } else {
          setAudioBlob(blob); setStatus('ready'); setNotice('Recording ready. Play it back or send it for feedback.');
        }
      };
      recorder.start(250);
      startedAtRef.current = Date.now();
      setStatus('recording');
      setNotice('Recording is on. Speak Japanese naturally, then stop the recording.');
      tickRef.current = window.setInterval(() => {
        const seconds = Math.floor((Date.now() - startedAtRef.current) / 1000);
        setRecordingSeconds(seconds);
        if (seconds >= 15) stopRecording(false);
      }, 250);
    } catch (err) {
      cleanupStream();
      const name = err instanceof DOMException ? err.name : '';
      setError(name === 'NotAllowedError' || name === 'SecurityError'
        ? 'Microphone permission was denied. Allow microphone access for this site in your browser settings, then retry.'
        : name === 'NotFoundError'
          ? 'No microphone was found. Connect or enable a microphone and try again.'
          : 'Microphone access could not start. Confirm that you are on HTTPS or localhost and that no other app is blocking the microphone.');
    }
  }, [clearAudio, cleanupStream, stopRecording]);

  async function sendForFeedback() {
    if (!audioBlob || busyAction) return;
    setError(''); setNotice(''); setEvaluation(null);
    const key = (await import('../services/ai')).getGeminiKey();
    if (!key) {
      setError('A Gemini API key is required to transcribe this recording. Your clip has not been sent. Open Profile → AI provider, configure a key, then return to this practice.');
      return;
    }
    setBusyAction(true); setStatus('sending');
    try {
      const audioBase64 = await toBase64(audioBlob);
      const transcript = await transcribeJapaneseAudio({apiKey:key,audioBase64,mimeType:normalizeAudioMime(audioBlob.type)});
      if (!transcript.trim()) {
        setStatus('ready');
        setError('No clear transcript was returned. No speaking evidence was recorded. Play the clip, re-record, and try again.');
        return;
      }
      setRecognizedTranscript(transcript);
      setTranscriptDraft(transcript);
      setStatus('transcribed');
      setNotice('Transcript ready. Check for recognition errors, then request feedback. No learning result is saved until the transcript is evaluated.');
    } catch (err) {
      setStatus('ready'); setError(mapAiError(err));
    } finally {
      setBusyAction(false);
    }
  }

  async function evaluateDraftTranscript() {
    if (!transcriptDraft.trim() || busyAction) {
      if (!transcriptDraft.trim()) setError('Enter the Japanese transcript before requesting feedback.');
      return;
    }
    const key = (await import('../services/ai')).getGeminiKey();
    if (!key) { setError('No Gemini API key is available. Your recording and transcript remain on this screen; configure a key before requesting feedback.'); return; }
    setError(''); setNotice(''); setBusyAction(true); setStatus('sending');
    try {
      const result = await evaluateTranscriptText({
        apiKey:key, model:selectedModel, transcript:transcriptDraft.trim(),
        scene:contextTitle, goal:contextDescription, targetPhrase:targetJapanese,
        acceptedMeanings, conversationContext
      });
      setEvaluation(result);
      const transcriptEdited = result.transcript.trim() !== recognizedTranscript.trim();
      // A learner-corrected transcript helps improve feedback but is not counted as
      // independent speech evidence because the corrected words were not machine-heard.
      const effectiveHintLevel = transcriptEdited ? Math.max(1,hintLevel) : hintLevel;
      const independent = result.intentUnderstood && effectiveHintLevel === 0 && !transcriptEdited;
      const evidence: SpeakingEvidence = {
        id: `speech-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        phraseId, targetJapanese, targetMeaning, sceneId, context: contextTitle, transcript: result.transcript,
        transcriptEdited, intentUnderstood: result.intentUnderstood, oneImprovement: result.oneImprovement,
        grammarFeedback: result.grammarFeedback, naturalAlternative: result.naturalAlternative,
        partnerReply: result.partnerReply, replyMeaning: result.replyMeaning, hintLevel:effectiveHintLevel,
        at: new Date().toISOString(), source: 'gemini-audio-understanding', independent
      };
      await saveSpeakingEvidence(evidence);
      const previous = await getProgress(phraseId);
      const practiceResult = result.intentUnderstood ? (independent ? 'independent' : 'hinted') : 'missed';
      const next = applyPractice(previous, phraseId, assessmentSkill, practiceResult, new Date(), result.oneImprovement);
      const scheduleOutcome = result.intentUnderstood ? (independent ? 'good' : 'hinted') : 'missed';
      const schedule = scheduleNextReview({ outcome: scheduleOutcome, successfulReviews: next.consecutiveSuccessfulReviews });
      next.nextReviewAt = schedule.nextReviewAt;
      await saveProgress(next);
      await addEvent({
        id: `event-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, at: new Date().toISOString(), phraseId, sceneId,
        type: 'speaking-evaluated', detail: JSON.stringify({ transcript: result.transcript, transcriptEdited, intentUnderstood: result.intentUnderstood, hintLevel:effectiveHintLevel, context: contextTitle, skill: assessmentSkill, source: 'gemini-3.8-flash-inline-audio' })
      });
      setStatus('evaluated');
      setNotice(transcriptEdited
        ? 'Corrected transcript used for feedback. This attempt is saved as supported practice, not independent speech evidence.'
        : independent ? 'Independent spoken retrieval recorded.' : result.intentUnderstood ? 'Supported spoken retrieval recorded.' : 'Attempt saved for focused review.');
      await onEvaluated?.(evidence);
    } catch (err) {
      setStatus('transcribed'); setError(mapAiError(err));
    } finally {
      setBusyAction(false);
    }
  }

  const progressiveHints = [
    'Context clue: focus on what you need to communicate, not the exact textbook sentence.',
    `First cue: ${Array.from(targetJapanese).slice(0, 2).join('')}…`,
    `Key phrase: ${targetJapanese.split(/[をはがにで]/)[0] || targetMeaning}`,
    `Full model: ${targetJapanese}`
  ];
  const elapsed = `0:${String(Math.min(15, recordingSeconds)).padStart(2, '0')}`;
  return <section className="ss-voice-card" aria-labelledby="ss-voice-title">
    <div className="ss-voice-head"><div><span className="ss-eyebrow">SPEAKING · REAL AUDIO</span><h3 id="ss-voice-title">Your turn: say it in Japanese</h3><p>{contextTitle}</p></div><span className={`ss-record-status ${status==='recording'?'is-recording':''}`}><i/>{status==='recording'?'Recording':status==='sending'?'Processing':status==='transcribed'?'Transcript ready':status==='evaluated'?'Evaluated':status==='ready'?'Ready to send':'Mic idle'}</span></div>
    <div className="ss-partner-opening">
      <div className="ss-partner-opening-avatar">店</div>
      <div className="ss-partner-opening-content"><span className="ss-eyebrow">YOUR CONVERSATION PARTNER</span><strong>Listen to the partner first</strong>
        <div className="ss-opening-actions"><button type="button" className="ss-soft-button" onClick={() => {if(!sayJapanese(partnerOpeningJapanese,0.86,voiceURI))setError('Speech synthesis is unavailable on this device. Read the Japanese text when you reveal it.');}}><Volume2 size={15}/> Replay</button><button type="button" className="ss-soft-button" onClick={() => {if(!sayJapanese(partnerOpeningJapanese,0.58,voiceURI))setError('Speech synthesis is unavailable on this device. Read the Japanese text when you reveal it.');}}>Slower</button></div>
        <div className="ss-opening-reveal-actions"><button type="button" className="ss-inline-link" onClick={() => setShowPartnerScript(v=>!v)}>{showPartnerScript?'Hide Japanese transcript':'Reveal Japanese transcript'}</button><button type="button" className="ss-inline-link" onClick={() => setShowPartnerMeaning(v=>!v)}>{showPartnerMeaning?'Hide translation':'Reveal translation'}</button></div>
        {showPartnerScript&&<p className="ss-opening-japanese" lang="ja">{partnerOpeningJapanese}</p>}{showPartnerMeaning&&<p className="ss-opening-meaning">{partnerOpeningMeaning}</p>}
      </div>
    </div>
    {japaneseVoices.length>1&&<label className="ss-voice-picker">Japanese voice<select value={voiceURI} onChange={e=>setVoiceURI(e.target.value)}>{japaneseVoices.map(voice=><option key={voice.voiceURI} value={voice.voiceURI}>{voice.name} · {voice.lang}</option>)}</select></label>}
    <div className="ss-voice-goal"><span className="ss-situation-emoji">🎙️</span><div><strong>{contextDescription}</strong><small>Try before looking at the answer. You can request help at any time.</small></div></div>
    <div className="ss-voice-controls">
      {status==='recording' ? <button type="button" className="ss-record-button recording" onClick={() => stopRecording(false)} aria-label="Stop recording"><Square size={20}/><span>Stop recording</span></button> : <button type="button" className="ss-record-button" onClick={() => void startRecording()} disabled={status==='sending'} aria-label="Start microphone recording"><Mic size={21}/><span>{audioBlob?'Record again':'Start recording'}</span></button>}
      {status==='recording'&&<><span className="ss-record-clock"><Activity size={16}/>{elapsed} / 0:15</span><button type="button" className="ss-soft-button" onClick={() => stopRecording(true)}><X size={15}/> Cancel</button></>}
      {audioUrl&&status!=='recording'&&<audio className="ss-audio-preview" src={audioUrl} controls aria-label="Recorded speaking attempt playback"/>}
    </div>
    {notice&&<p className="ss-voice-notice" role="status">{notice}</p>}
    {error&&<div className="ss-voice-error" role="alert"><AlertCircle size={18}/><span>{error}</span></div>}
    <div className="ss-voice-actions">
      <button type="button" className="ss-soft-button" onClick={() => {setHintLevel(v=>Math.min(3,v+1));setError('');}} disabled={status==='recording'||status==='sending'||hintLevel>=3}><Lightbulb size={16}/>{hintLevel===0?'Get a hint':hintLevel===3?'Full model shown':`More help (${hintLevel}/3)`}</button>
      {status==='ready'&&<button type="button" className="ss-primary-button" onClick={() => void sendForFeedback()} disabled={!audioBlob||busyAction}><Send size={16}/>{busyAction?'Transcribing…':'Send audio for transcript'}</button>}
      {status==='transcribed'&&<button type="button" className="ss-primary-button" onClick={() => void evaluateDraftTranscript()} disabled={busyAction||!transcriptDraft.trim()}><CheckCircle2 size={16}/>{busyAction?'Evaluating…':'Confirm transcript & get feedback'}</button>}
      {status==='evaluated'&&<button type="button" className="ss-primary-button" onClick={() => {setEvaluation(null);setRecognizedTranscript('');setTranscriptDraft('');setHintLevel(0);setShowModelAnswer(false);setStatus('idle');clearAudio();setNotice('Ready for another spoken attempt.');}}><RotateCcw size={16}/> Try again</button>}
    </div>
    {hintLevel>0&&<div className="ss-progressive-hint"><Lightbulb size={16}/><div><strong>Hint {hintLevel} of 3</strong><p>{progressiveHints[hintLevel-1]}</p></div></div>}
    <div className="ss-privacy-note"><ShieldCheck size={17}/><p>Your recording stays temporary in this page until you send it. When you choose “Send audio for transcript,” the audio is sent directly to Google and processed with Gemini 3.8 Flash’s documented audio-input path. The resulting transcript is sent to your selected Gemini model for coaching. SceneSpeak does not save the raw audio. Transcripts and learning evidence are saved locally.</p></div>
    {(status==='transcribed'||(status==='sending'&&Boolean(recognizedTranscript)&&!evaluation))&&<div className="ss-transcript-editor" aria-live="polite"><label htmlFor="ss-transcript-draft"><strong>Transcript from your recording</strong><span>Correct any recognition errors before getting feedback. If you edit it, the app will not count the attempt as independent speech evidence.</span></label><textarea id="ss-transcript-draft" value={transcriptDraft} onChange={event=>setTranscriptDraft(event.target.value.slice(0,600))} maxLength={600} rows={3} lang="ja" autoComplete="off" disabled={status==='sending'}/><small>{transcriptDraft.length}/600 characters{transcriptDraft!==recognizedTranscript?' · Edited':''}</small></div>}
    {(evaluation?.transcript || status==='evaluated')&&evaluation&&<div className="ss-speech-result" aria-live="polite">
      <div className="ss-result-title"><div><span className="ss-eyebrow">TRANSCRIPT USED FOR FEEDBACK</span><h4>{evaluation.transcript}</h4></div><span className={`ss-intent-pill ${evaluation.intentUnderstood?'understood':'retry'}`}>{evaluation.intentUnderstood?'Intent communicated':'Try a repair'}</span></div>
      <div className="ss-feedback-grid"><div><strong>One useful improvement</strong><p>{evaluation.oneImprovement}</p></div><div><strong>Grammar and naturalness</strong><p>{evaluation.grammarFeedback}</p></div></div>
      <div className="ss-natural-alternative"><span>Natural example</span><strong>{evaluation.naturalAlternative}</strong><button type="button" className="ss-soft-button" onClick={() => {if(!sayJapanese(evaluation.naturalAlternative,0.86,voiceURI))setError('Speech synthesis is unavailable on this device. Use the written example instead.');}}><Volume2 size={15}/> Hear example</button><button type="button" className="ss-soft-button" onClick={() => {if(!sayJapanese(evaluation.naturalAlternative,0.58,voiceURI))setError('Speech synthesis is unavailable on this device.');}}>Slower</button></div>
      <div className="ss-partner-reply"><span className="ss-partner-avatar">店</span><div><small>PARTNER RESPONDS TO THE TRANSCRIPT YOU CONFIRMED</small><strong>{evaluation.partnerReply}</strong><p>{evaluation.replyMeaning}</p><button type="button" className="ss-inline-link" onClick={() => {if(!sayJapanese(evaluation.partnerReply,0.86,voiceURI))setError('Speech synthesis is unavailable on this device.');}}><Play size={14}/> Replay partner</button></div></div>
      <button type="button" className="ss-soft-button" onClick={() => {setShowModelAnswer(v=>!v);if(!showModelAnswer)setHintLevel(v=>Math.max(v,3));}}>{showModelAnswer?'Hide meaning':'Show phrase and meaning'}</button>
      {showModelAnswer&&<div className="ss-answer-reveal"><strong>{targetJapanese}</strong>{romanization&&<small>{romanization}</small>}{reading&&reading!==targetJapanese&&<small>{reading}</small>}<p>{targetMeaning}</p></div>}
      <p className="ss-assessment-caveat"><CheckCircle2 size={15}/> This feedback is based on the transcript and model interpretation, not a validated pronunciation or accent score. Recognition errors can happen. Your transcript was visible for correction before this feedback was evaluated.</p>
    </div>}
  </section>;
}
