import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, BookOpen, Check, CheckCircle2, GraduationCap, Headphones, PencilLine, RotateCcw, Search, Volume2 } from 'lucide-react';
import { N5_KANJI, getKanjiForLesson, getKanjiForModule, type N5Kanji } from '../data/kanji';
import { addEvent, getEvents } from '../services/storage';
import type { PracticeEvent } from '../domain/types';
import '../styles/kanji.css';

const makeId=(prefix:string)=>`${prefix}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
type QuizMode='meaning'|'reading'|'recall'|'write';
function speakJapanese(text:string,rate=0.78){if(!('speechSynthesis'in window))return false;window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='ja-JP';u.rate=rate;const voice=window.speechSynthesis.getVoices().find(v=>v.lang.toLowerCase().startsWith('ja'));if(voice)u.voice=voice;window.speechSynthesis.speak(u);return true;}
function shuffle<T>(items:T[]):T[]{const result=[...items];for(let i=result.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[result[i],result[j]]=[result[j],result[i]];}return result;}
function answerFor(item:N5Kanji,mode:QuizMode){if(mode==='meaning')return item.meanings[0];if(mode==='reading')return item.exampleReading;if(mode==='recall')return item.character;return item.character;}
function choicesFor(item:N5Kanji,mode:QuizMode,pool:N5Kanji[],turn:number){
 const target=answerFor(item,mode);const distractors=pool.filter(k=>k.id!==item.id).map(k=>answerFor(k,mode)).filter((v,i,a)=>v!==target&&a.indexOf(v)===i).slice(0,16);
 return shuffle([target,...shuffle(distractors).slice(0,3)]).sort((a,b)=>((a.charCodeAt(0)+turn)%3)-((b.charCodeAt(0)+turn)%3));
}
function recordAnswer(item:N5Kanji,mode:QuizMode,answer:string,correct:boolean,source:string,lessonNumber?:number,sceneId?:string){
 const event:PracticeEvent={id:makeId('kanji-practice'),at:new Date().toISOString(),sceneId, type:'kanji-practice-answer',detail:JSON.stringify({kanjiId:item.id,character:item.character,mode,answer,correct,source,lessonNumber})};
 return addEvent(event);
}
function safeKanjiDetail(event:PracticeEvent):{kanjiId?:string;correct?:boolean;source?:string}|null{try{return JSON.parse(event.detail??'') as {kanjiId?:string;correct?:boolean;source?:string};}catch{return null;}}

export function KanjiPracticePage(){
 const [searchParams]=useSearchParams();
 const initialLesson=searchParams.get('lesson')??'all';
 const initialModule=searchParams.get('module')??'';
 const returnPack=searchParams.get('pack')??'';
 const [lessonFilter,setLessonFilter]=useState(initialLesson);
 const [moduleFilter]=useState(initialModule);
 const [query,setQuery]=useState('');
 const [mode,setMode]=useState<QuizMode>('meaning');
 const [index,setIndex]=useState(0);
 const [choice,setChoice]=useState('');
 const [typed,setTyped]=useState('');
 const [checked,setChecked]=useState(false);
 const [attempts,setAttempts]=useState<PracticeEvent[]>([]);
 const [notice,setNotice]=useState('');
 useEffect(()=>{void getEvents().then(events=>setAttempts(events.filter(e=>e.type==='kanji-practice-answer')));},[]);
 const baseItems=useMemo(()=>{
  if(lessonFilter!=='all')return getKanjiForLesson(Number(lessonFilter));
  if(moduleFilter)return getKanjiForModule(moduleFilter);
  return N5_KANJI;
 },[lessonFilter,moduleFilter]);
 const items=useMemo(()=>{
  const q=query.trim().toLowerCase();
  return baseItems.filter(k=>!q||[k.character,...k.meanings,...k.onReadings,...k.kunReadings,k.example,k.exampleReading,k.exampleMeaning].join(' ').toLowerCase().includes(q));
 },[baseItems,query]);
 const current=items.length?items[index%items.length]:undefined;
 const choices=useMemo(()=>current&&mode!=='write'?choicesFor(current,mode,items.length>3?items:N5_KANJI,index):[],[current,mode,items,index]);
 const correctCount=attempts.filter(e=>safeKanjiDetail(e)?.correct===true).length;
 const attemptsForCurrent=current?attempts.filter(e=>safeKanjiDetail(e)?.kanjiId===current.id).length:0;
 const questionPrompt=mode==='meaning'?'What does this kanji commonly mean?':mode==='reading'?'How do you read this word?':mode==='recall'?'Which kanji matches this meaning?':'Type the kanji for this meaning.';
 const currentCorrect=Boolean(current)&&(mode==='write'?typed.trim()===current!.character:choice===answerFor(current!,mode));
 function next(){setIndex(i=>(i+1)%Math.max(1,items.length));setChoice('');setTyped('');setChecked(false);setNotice('');}
 async function submit(){
  if(!current)return;
  const answer=mode==='write'?typed.trim():choice;
  if(!answer){setNotice(mode==='write'?'Type the kanji before checking.':'Choose an answer first.');return;}
  const correct=answer===answerFor(current,mode);
  setChecked(true);
  await recordAnswer(current,mode,answer,correct,'dedicated',lessonFilter==='all'?undefined:Number(lessonFilter));
  const events=await getEvents();
  setAttempts(events.filter(e=>e.type==='kanji-practice-answer'));
  setNotice(correct?'Correct — this attempt is recorded as evidence of kanji practice.':'Not quite. Study the reading and example, then try again later.');
 }
 const currentCard = current ? (
  <div className="ss-kanji-practice-card">
   <div className="ss-kanji-counter">CHARACTER {index+1} / {items.length}<span>{attemptsForCurrent} prior attempt{attemptsForCurrent===1?'':'s'}</span></div>
   <div className="ss-kanji-prompt">{questionPrompt}</div>
   <div className="ss-kanji-question-content">
    {mode==='reading' ? (
     <div className="ss-kanji-example-word">{current.example}<button aria-label="Hear example word" onClick={()=>{if(!speakJapanese(current.example))setNotice('Japanese speech synthesis is unavailable on this device.');}}><Volume2 size={18}/></button></div>
    ) : mode==='recall'||mode==='write' ? (
     <div className="ss-kanji-meaning-prompt">{current.meanings[0]}</div>
    ) : (
     <div className="ss-kanji-character">{current.character}<button aria-label="Hear example word" onClick={()=>{if(!speakJapanese(current.example))setNotice('Japanese speech synthesis is unavailable on this device.');}}><Volume2 size={18}/></button></div>
    )}
    {mode==='write' ? (
     <label className="ss-kanji-type-input"><span>Japanese character (use your device’s Japanese keyboard/IME)</span><input value={typed} onChange={e=>setTyped(e.target.value)} placeholder="Type the kanji" disabled={checked} autoComplete="off"/><small>Exact character matching only; this does not evaluate handwriting or stroke order.</small></label>
    ) : (
     <div className={`ss-kanji-options ${mode==='recall'?'ss-kanji-character-options':''}`}>
      {choices.map(value=><button key={value} className={`${choice===value?'selected':''} ${checked&&value===answerFor(current,mode)?'correct':''} ${checked&&choice===value&&value!==answerFor(current,mode)?'incorrect':''}`} onClick={()=>{if(!checked)setChoice(value);}} disabled={checked}>{value}</button>)}
     </div>
    )}
    {checked&&<div className={`ss-kanji-feedback ${currentCorrect?'good':'retry'}`}>
     <strong>{currentCorrect?'Correct':'Review this one'}</strong>
     <div className="ss-kanji-answer-detail"><span className="ss-kanji-inline-character">{current.character}</span><div>
      <strong>{current.meanings.join(' · ')}</strong>
      <p>On: {current.onReadings.join('、')||'—'} · Kun: {current.kunReadings.join('、')||'—'}</p>
      <p className="ss-kanji-example-line">{current.example}（{current.exampleReading}）— {current.exampleMeaning}</p>
      <small>{current.strokeCount} strokes · N5-oriented · linked to lesson{current.lessonNumbers.length===1?'':'s'} {current.lessonNumbers.join(', ')}</small>
     </div></div>
    </div>}
    {notice&&<p className="ss-kanji-status" role="status">{notice}</p>}
    <div className="ss-kanji-actions">
     {!checked?<button className="ss-kanji-primary" onClick={()=>void submit()}>Check answer <Check size={17}/></button>:<button className="ss-kanji-primary" onClick={next}>Next kanji <ArrowRight size={17}/></button>}
     <button className="ss-kanji-secondary" onClick={()=>{if(!speakJapanese(current.example))setNotice('Japanese speech synthesis is unavailable on this device.');}}><Volume2 size={16}/> Hear example</button>
    </div>
   </div>
  </div>
 ) : (
  <div className="ss-kanji-empty"><h2>No characters match</h2><p>Try another lesson or search term.</p><button onClick={()=>{setLessonFilter('all');setQuery('');}}>Show all characters</button></div>
 );
 return (
  <div className="ss-kanji-page">
   <Link to={lessonFilter!=='all'?`/minna/${lessonFilter}${returnPack?`?pack=${encodeURIComponent(returnPack)}`:''}`:moduleFilter?'/scenes':'/'} className="ss-kanji-back"><ArrowLeft size={16}/> {lessonFilter!=='all'?`Back to Minna lesson ${lessonFilter}`:moduleFilter?'Back to scenes':'Home'}</Link>
   <header className="ss-kanji-hero"><div><span className="ss-kanji-eyebrow"><GraduationCap size={15}/> KANJI · JLPT N5-ORIENTED</span><h1>Kanji practice</h1><p>Learn the character, common readings, and a real beginner word. Then retrieve its meaning or reading without hints.</p><div className="ss-kanji-hero-tags"><span>{N5_KANJI.length} curated characters</span><span>Minna lesson links</span><span>Scene-linked practice</span></div></div><div className="ss-kanji-big-symbol" aria-hidden="true">漢</div></header>
   <div className="ss-kanji-note"><BookOpen size={18}/><p><strong>Study note:</strong> This is a curated N5-oriented practice set, not an official exhaustive JLPT kanji list. Readings depend on the word and context; learn them through examples rather than memorizing a single reading per character.</p></div>
   <div className="ss-kanji-summary"><div><strong>{N5_KANJI.length}</strong><span>characters in this set</span></div><div><strong>{attempts.length}</strong><span>practice attempts</span></div><div><strong>{correctCount}</strong><span>correct answers recorded</span></div><div><strong>{Math.round(attempts.length?correctCount/attempts.length*100:0)}%</strong><span>all-time practice accuracy</span></div></div>
   <section className="ss-kanji-workspace">
    <div className="ss-kanji-controls">
     <label><span>Minna lesson</span><select value={lessonFilter} onChange={e=>{setLessonFilter(e.target.value);setIndex(0);setChoice('');setTyped('');setChecked(false);}}><option value="all">All N5-oriented kanji</option>{Array.from({length:25},(_,i)=>i+1).map(n=><option key={n} value={String(n)}>Lesson {n}</option>)}</select></label>
     <label className="ss-kanji-search"><span>Search</span><div><Search size={16}/><input value={query} onChange={e=>{setQuery(e.target.value);setIndex(0);setChecked(false);}} placeholder="Character, meaning, or word"/></div></label>
    </div>
    <div className="ss-kanji-mode-tabs" role="group" aria-label="Kanji practice mode">
     {([{id:'meaning',label:'Meaning',icon:<BookOpen size={15}/>},{id:'reading',label:'Reading',icon:<Headphones size={15}/>},{id:'recall',label:'Recall kanji',icon:<RotateCcw size={15}/>},{id:'write',label:'Type kanji',icon:<PencilLine size={15}/>} ] as {id:QuizMode;label:string;icon:ReactNode}[]).map(m=><button key={m.id} className={mode===m.id?'active':''} onClick={()=>{setMode(m.id);setChoice('');setTyped('');setChecked(false);setNotice('');}}>{m.icon}{m.label}</button>)}
    </div>
    {currentCard}
   </section>
   <section className="ss-kanji-reference"><div><span className="ss-kanji-eyebrow">REFERENCE</span><h2>Characters in this study set</h2><p>Open a Minna lesson to focus practice on kanji associated with that lesson’s topic.</p></div><div className="ss-kanji-reference-grid">{items.slice(0,36).map(k=><button key={k.id} onClick={()=>{setIndex(items.findIndex(it=>it.id===k.id));setChoice('');setTyped('');setChecked(false);setMode('meaning');}}><strong>{k.character}</strong><span>{k.meanings[0]}</span><small>{k.example} · {k.exampleReading}</small></button>)}</div></section>
  </div>
 );
}

function KanjiMiniPractice({items,source,lessonNumber,sceneId,moduleId,packId,heading}:{items:N5Kanji[];source:'minna'|'scene';lessonNumber?:number;sceneId?:string;moduleId?:string;packId?:string;heading:string}){
 const [index,setIndex]=useState(0);const [choice,setChoice]=useState('');const [checked,setChecked]=useState(false);const [feedback,setFeedback]=useState('');const current=items[index%Math.max(1,items.length)];
 const options=useMemo(()=>current?choicesFor(current,'meaning',N5_KANJI,index):[],[current,index]);
 if(!current)return null;
 async function check(){if(!choice)return;const correct=choice===current.meanings[0];setChecked(true);await recordAnswer(current,'meaning',choice,correct,source,lessonNumber,sceneId);setFeedback(correct?'Correct meaning. This answer was saved as a kanji practice attempt.':`Not quite. ${current.character} means ${current.meanings.join(' / ')} here.`);}
 return <section className="ss-kanji-mini"><div className="ss-kanji-mini-head"><div><span className="ss-kanji-eyebrow">KANJI MOMENT</span><h3>{heading}</h3><p>Learn the character as well as the kana reading.</p></div><span className="ss-kanji-mini-badge">{index+1}/{items.length}</span></div><div className="ss-kanji-mini-body"><div className="ss-kanji-mini-character">{current.character}</div><div className="ss-kanji-mini-quiz"><strong>What does this kanji mean?</strong><div className="ss-kanji-mini-options">{options.map(option=><button key={option} className={`${choice===option?'selected':''} ${checked&&option===current.meanings[0]?'correct':''}`} disabled={checked} onClick={()=>setChoice(option)}>{option}</button>)}</div>{checked&&<div className="ss-kanji-mini-answer"><strong>{current.character} · {current.meanings.join(' / ')}</strong><p>Reading in a useful word: {current.example}（{current.exampleReading}）— {current.exampleMeaning}</p><small>On: {current.onReadings.join('、')||'—'} · Kun: {current.kunReadings.join('、')||'—'}</small><p>{feedback}</p></div>}<div className="ss-kanji-mini-actions">{!checked?<button className="ss-kanji-mini-primary" disabled={!choice} onClick={()=>void check()}>Check meaning</button>:<button className="ss-kanji-mini-primary" onClick={()=>{setIndex(i=>(i+1)%items.length);setChoice('');setChecked(false);setFeedback('');}}>Next character <ArrowRight size={15}/></button>}<Link to={source==='minna'?`/kanji?lesson=${lessonNumber}${packId&&packId!== 'scenespeak-minna-n5' ? `&pack=${encodeURIComponent(packId)}`:''}`:`/kanji?module=${encodeURIComponent(moduleId??items[0].moduleIds[0]??'m1')}`} className="ss-kanji-mini-link">Full kanji practice <ArrowRight size={14}/></Link></div></div></div></section>;
}

export function MinnaKanjiPanel({lessonNumber,packId}:{lessonNumber:number;packId:string}){const items=getKanjiForLesson(lessonNumber);return <KanjiMiniPractice items={items} source="minna" lessonNumber={lessonNumber} packId={packId} heading={`Lesson ${lessonNumber} kanji`} />;}
export function SceneKanjiSpotlight({moduleId,sceneId,sceneTitle}:{moduleId:string;sceneId:string;sceneTitle:string}){const items=getKanjiForModule(moduleId);if(!items.length)return null;return <KanjiMiniPractice items={items.slice(0,Math.min(4,items.length))} source="scene" sceneId={sceneId} moduleId={moduleId} heading={`Useful kanji for ${sceneTitle}`} />;}
