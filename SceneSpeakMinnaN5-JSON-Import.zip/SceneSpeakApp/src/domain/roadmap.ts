import type {
  LearningPurpose, LearningRoadmapPhase, LearningRoadmapPlan, LearningTarget,
  LearningTimelineDays, Profile, RoadmapFocusRoute,
} from './types';

export interface RoadmapPlanInput {
  id: string;
  purpose: LearningPurpose;
  target: LearningTarget;
  targetDays: LearningTimelineDays;
  studyDaysPerWeek: 3|4|5|6|7;
  dailyMinutes: 5|10|15|20|30;
  learnerLevel: Profile['level'];
  goal: string;
  startDate?: string;
  createdAt?: string;
}
export interface RoadmapDayTask {
  dayNumber: number;
  weekNumber: number;
  phase: LearningRoadmapPhase;
  title: string;
  activity: string;
  route: string;
  isRestDay: boolean;
  focusLabel: string;
  estimatedMinutes: number;
  phaseSession: number;
  cycleLabel: string;
  successCheck: string;
}

const routePaths:Record<RoadmapFocusRoute,string>={
  kana:'/kana',minna:'/minna',kanji:'/kanji',grammar:'/grammar',listening:'/listening',
  scenes:'/scenes',speaking:'/speaking',review:'/review','jlpt-n5':'/jlpt-n5',ai:'/ai','memory-to-mouth':'/memory-to-mouth',
};
export function roadmapRoute(focus:RoadmapFocusRoute):string{return routePaths[focus]??'/scenes';}

function phase(id:string,title:string,outcome:string,vocabularyFocus:string,grammarFocus:string,kanjiFocus:string,listeningFocus:string,speakingMission:string,checkpoint:string,primaryRoute:RoadmapFocusRoute):LearningRoadmapPhase{
  return {id,title,outcome,vocabularyFocus,grammarFocus,kanjiFocus,listeningFocus,speakingMission,checkpoint,primaryRoute};
}

function jlptPhases(target:LearningTarget):LearningRoadmapPhase[]{
  const levels=['N5 foundations','N4 everyday Japanese','N3 independent Japanese','N2 complex language','N1 nuance and precision'];
  const targetN=Number(target.slice(-1));
  const levelCount=targetN===1?5:targetN===2?4:targetN===3?3:targetN===4?2:1;
  const targetLabel=`JLPT ${target.toUpperCase().replace('JLPT-','')}`;
  const foundations:LearningRoadmapPhase[]=[
    phase('jp-script','Script and sound foundations','Read hiragana and katakana quickly; learn how Japanese sound units fit together.','Greetings, numbers, classroom words and core expressions.','Sentence order, は, です and simple questions.','Learn a first small set of common characters through words, not isolated shapes.','Match short spoken phrases to kana and meaning.','Introduce yourself and ask one simple question without reading.','Read a short kana line and understand its basic intent.','kana'),
    phase('jp-core-words','Core vocabulary and sentence building','Build a useful vocabulary base and retrieve words from short prompts.','People, places, time, food, everyday actions and adjectives.','の, も, を, に, で and basic sentence frames.','Common N5 kanji in everyday words; review readings in context.','Notice known words in slow, short utterances.','Describe a person, place, or simple need.','Recall the right word or particle in new examples.','minna'),
    phase('jp-grammar','Grammar patterns and verb forms','Understand core forms and choose them based on meaning and context.','Actions, routine verbs, time words and common counters.','Verb groups, present/past, affirmative/negative, て-form or level-appropriate patterns.','Connect readings and meanings to vocabulary already studied.','Listen for tense, particles and sentence endings.','Ask and answer short follow-up questions.','Explain why a form fits a sentence.','grammar'),
    phase('jp-reading','Kanji and short reading','Read short sentences without relying on romanization.','High-frequency nouns, verbs, adjectives and compounds.','Connect clauses and understand common modifiers at the target level.','Use radicals/components as memory cues and learn words with multiple readings.','Use context to infer a known word from connected speech.','Read a short notice or message and explain the key point.','Answer comprehension questions from a short text.','kanji'),
    phase('jp-listening','Listening and response speed','Recognize familiar language when it is spoken in connected phrases.','Question words, time, reasons, plans and common reactions.','Common linking and response patterns for the target level.','Review characters and vocabulary found in listening scripts.','Listen once for the situation, then again for key information.','Respond to a prompt in a short, natural turn.','Choose the best response and identify the clue.','listening'),
    phase('jp-reading-speed','Reading fluency and mixed skills','Combine vocabulary, grammar, kanji and context to understand short passages.','Topic vocabulary linked to school, daily life, travel and public information.','Review confusable patterns and common grammar contrasts.','Read short compound words and phrases in context.','Pair transcript comprehension with audio after a first listen.','Summarize a message or tell someone what you understood.','Complete a mixed reading/listening/grammar set and review every miss.','grammar'),
    phase('jp-applied','Real-life language transfer','Use learned language in a fresh scenario instead of repeating memorized examples.','Target-level vocabulary for errands, plans, questions and small problems.','Choose forms that fit politeness and intent.','Read kanji words inside signs, messages and dialogue.','Respond to changed wording and unfamiliar voices where audio permits.','Complete a multi-turn scene and ask for clarification when needed.','Apply patterns in a new situation without a model answer.','scenes'),
    phase('jp-checkpoint',`${targetLabel} consolidation checkpoint`,'Identify gaps, revisit weak areas and check readiness with available practice data.','Review words missed most often; add targeted packs as needed.','Revisit grammar with the lowest independent recall.','Review weak kanji and their readings in vocabulary.','Repeat difficult listening items with reduced text support.','Complete a capstone and explain what still feels uncertain.','Review a mixed practice set and make a next-cycle plan.','jlpt-n5'),
  ];
  if(levelCount<=1)return foundations.map((p,i)=>i===7?{...p,title:'JLPT N5 consolidation checkpoint'}:p);
  const targetIndex=levelCount-1;
  return foundations.map((p,i)=>{
    if(i===0)return {...p,title:`Foundation refresh for ${targetLabel}`,outcome:`Refresh prerequisite kana and sentence patterns, then begin the level-by-level route toward ${targetLabel}.`};
    if(i>=1&&i<=5){
      const levelIndex=Math.min(i-1,targetIndex);const level=levels[levelIndex];
      const levelNote=levelIndex===0?'Use the bundled beginner/N5 lessons for the core material.':'Use verified course books, lesson packs, vocabulary, kanji, grammar explanations and audio for this level; SceneSpeak’s built-in structured catalogue is mainly beginner/N5.';
      if(i===1)return {...p,title:`${level}: core vocabulary and sentence building`,outcome:`Secure the vocabulary and core sentence patterns needed for the ${targetLabel} prerequisite sequence. ${levelNote}`,vocabularyFocus:`${level}: high-frequency words, collocations, and vocabulary from verified target-level materials.`,grammarFocus:`${level}: core sentence patterns and the most common form/meaning contrasts.`,kanjiFocus:`Learn characters through high-frequency words and examples appropriate to ${level}.`};
      if(i===2)return {...p,title:`${level}: grammar and word building`,outcome:`Build on the previous level instead of skipping prerequisites on the way to ${targetLabel}. ${levelNote}`,vocabularyFocus:`${level}: expand topic vocabulary and practice recall in short original sentences.`,grammarFocus:`${level}: learn the level’s core patterns and compare confusable forms using verified examples.`,kanjiFocus:`Read common compounds and connect character readings to words and sentences.`};
      if(i===3)return {...p,title:`${level}: kanji and reading`,outcome:`Read longer and denser text appropriate to ${level}; higher-level content must come from verified materials. ${levelNote}`,kanjiFocus:`Use the verified ${level} syllabus or pack to study characters through vocabulary, compounds and sentences.`,listeningFocus:`Pair verified ${level} reading passages with audio when available, and identify the main point plus supporting details.`};
      if(i===4)return {...p,title:`${level}: listening and response speed`,outcome:`Improve comprehension of connected speech at ${level}, with scripts and practice items from a trusted level-matched source. ${levelNote}`,listeningFocus:`Use verified ${level} audio: listen for gist first, then details, speaker intent and linking cues.`,speakingMission:`Summarize a ${level}-appropriate listening item and answer a related follow-up in your own words.`};
      return {...p,title:`${level}: mixed reading and skill transfer`,outcome:`Combine vocabulary, grammar, kanji, reading and listening at ${level}; maintain an error log and revisit weaknesses. ${levelNote}`,vocabularyFocus:`Review spaced vocabulary from ${level} and prioritise words missed repeatedly.`,grammarFocus:`Apply ${level} grammar to unfamiliar examples and explain why alternative answers do not fit.`,kanjiFocus:`Review weak ${level} kanji inside the words and passages where they occur.`};
    }
    if(i===6)return {...p,title:`${targetLabel}: applied language transfer`,outcome:`Use the level’s knowledge in unfamiliar contexts and identify what remains to be learned. Higher-level practice needs verified, level-matched input.`,vocabularyFocus:`Read and hear ${targetLabel}-appropriate topics from trusted course material; build a personal weak-word list.`,grammarFocus:`Apply patterns across reading, listening and short written or spoken responses.`,kanjiFocus:`Recognize high-utility target-level kanji in vocabulary, notices, passages and dialogue.`,listeningFocus:`Practise target-level audio from verified sources and check the transcript only after a first listen.`,primaryRoute:'scenes'};
    return {...p,title:`${targetLabel} consolidation checkpoint`,outcome:`Use verified ${targetLabel}-level timed and untimed materials to assess readiness, revisit gaps, and plan the next review cycle. The built-in exam trainer remains N5-focused; this roadmap alone cannot establish exam readiness.`};
  });
}

function longHorizonPhases(phases:LearningRoadmapPhase[],purpose:LearningPurpose):LearningRoadmapPhase[]{
 const advanced:Record<Exclude<LearningPurpose,'jlpt'>,LearningRoadmapPhase[]>= {
  travel:[
   phase('long-travel-1','Long stays and daily-life independence','Move beyond tourist exchanges into repeated everyday tasks and unexpected changes.','Bills, appointments, neighbourhood services, deliveries, and recurring errands.','Requests, explanations, comparisons, reasons, and confirmation patterns.','Read common kanji in local notices, forms, labels and service messages.','Follow routine announcements and identify what action is required.','Explain a practical problem and confirm the next step.','Handle three different daily-life scenarios with less scripted support.','scenes'),
   phase('long-travel-2','Independent problem-solving in Japan','Integrate listening, reading and polite speaking when a situation changes.','Personal weak vocabulary from errands, transport, health, housing and services.','Choose an appropriate level of politeness and clarify ambiguity.','Read short practical notices and messages from trusted materials.','Summarize the situation and two important details before acting.','Resolve a changed booking, delivery, or service problem in roleplay.','Complete a multi-step daily-life capstone and document remaining gaps.','speaking'),
  ],
  conversation:[
   phase('long-conv-1','Intermediate conversation: reasons and viewpoints','Move from short exchanges to connected explanations, opinions, stories and follow-ups.','Experiences, goals, relationships, work/study, society and personal interests.','Cause/effect, contrast, conditionals, quoting, comparisons and connected clauses.','Read topic vocabulary and common compounds in messages and short articles.','Follow longer conversations for gist, supporting details and the speaker’s stance.','Explain an opinion with reasons, respond to a counterpoint and ask a follow-up.','Hold a multi-turn conversation on a less familiar topic and repair misunderstandings.','speaking'),
   phase('long-conv-2','Advanced conversational range and nuance','Develop flexible comprehension and expression across topics, register and implicit meaning.','Topic-specific vocabulary, collocations, reactions, disagreement and nuance.','Register shifts, indirect requests, hedging and more complex sentence linking from verified study material.','Read longer texts and messages; use context to infer unknown compounds.','Listen to authentic or well-levelled input and note gist, intent and uncertainty.','Summarize a viewpoint, politely disagree, and adapt wording to the listener.','Complete several fresh conversations and self-audit vocabulary, clarity, and repair skills.','scenes'),
  ],
  'work-study':[
   phase('long-work-1','Intermediate workplace and study communication','Handle longer instructions, reports, discussions and collaborative tasks.','Meetings, deadlines, project updates, feedback and field-specific terms.','Explain reasons, propose alternatives, summarize and confirm responsibilities.','Study compounds and written terms from verified industry or academic materials.','Follow a short meeting or instruction set and capture decisions and next actions.','Give a status update, describe a blocker and suggest a next step.','Complete a multi-turn meeting roleplay with a written action summary.','speaking'),
   phase('long-work-2','Advanced workplace independence','Build greater independence with nuanced requests, longer input and field-specific language.','Verified field vocabulary, document terms, professional reactions and follow-up phrases.','Appropriate formal/casual choices, indirect phrasing and advanced patterns from trusted materials.','Read level-matched workplace documents and note unfamiliar compounds for review.','Summarize key decisions and confirm uncertainty rather than guessing.','Lead a simulated discussion, clarify an ambiguous instruction, and negotiate a next action.','Complete a field-specific capstone; record which tasks still require help from a human speaker.','scenes'),
  ],
  media:[
   phase('long-media-1','Intermediate colloquial speech and subtext','Understand more casual dialogue, contractions, omissions and relationship cues.','Reactions, idioms, emotion, disagreement and recurring genre vocabulary.','Plain/polite contrasts, sentence-final nuance, ellipsis and casual contractions from reliable explanations.','Build a deck of recurring kanji words from verified subtitles and contextual examples.','Listen first without subtitles, infer intent, then compare with a reliable transcript.','Retell a scene and explain one line’s intent rather than translating word-for-word.','Understand the gist and several important details of a short, level-appropriate clip.','listening'),
   phase('long-media-2','Advanced authentic-media comprehension project','Build a repeatable workflow for fast speech, implied meaning and genre-specific language.','Choose a genre-specific vocabulary bank and track frequent expressions in context.','Study nuance, tone, wordplay and register with trustworthy explanations; note uncertainty.','Review recurring kanji compounds found in longer text, subtitles and notes.','Use authentic or appropriately levelled material; compare first-pass notes with verified subtitles.','Summarize a sequence, explain motivation and reuse one suitable expression in a real-life conversation.','Complete a multi-clip comprehension portfolio without assuming full native-speed comprehension.','ai'),
  ],
  foundation:[
   phase('long-base-1','Intermediate Japanese bridge','Extend beginner skills into connected reading, longer conversation and less predictable situations.','Topic vocabulary for routines, plans, experiences, reasons and opinions.','Connected clauses, contrast, conditionals, quoting and form changes through verified examples.','Add common compounds and review readings through real words and sentences.','Follow longer dialogues for gist and supporting details.','Explain an experience or opinion and answer a follow-up without a full script.','Transfer learned patterns to an unfamiliar everyday context.','speaking'),
   phase('long-base-2','Upper-level integration and independent study','Build a sustainable path toward advanced study using real, level-matched materials.','Personal topic vocabulary, collocations, and words repeatedly missed.','Advanced patterns and register choices from a trustworthy level-matched course.','Read longer passages and keep a kanji/vocabulary notebook.','Use authentic or graded audio, first for meaning and then for detail.','Discuss an unfamiliar topic, clarify uncertainty and self-correct.','Complete a capstone, identify remaining gaps, and build the next verified level plan.','review'),
  ],
 };
 const key=purpose as Exclude<LearningPurpose,'jlpt'>;const extras=advanced[key]??advanced.foundation;
 if(phases.length<2)return phases;
 const capstone={...phases[phases.length-1],title:({travel:'Japan long-stay independence capstone',conversation:'Japanese conversational independence capstone','work-study':'Work and study independence capstone',media:'Authentic-media comprehension capstone',foundation:'Japanese foundations-to-independence capstone'} as Partial<Record<LearningPurpose,string>>)[purpose]??'Advanced integration capstone',outcome:'Combine the full roadmap in realistic new contexts, review the evidence of what you can do independently, and document remaining gaps. This is a learning milestone, not a certification or fluency guarantee.'};
 return [...phases.slice(0,phases.length-1),...extras,capstone];
}

export function guidedRoadmapPhases(purpose:LearningPurpose,target:LearningTarget):LearningRoadmapPhase[]{
 if(purpose==='jlpt')return jlptPhases(target);
 if(purpose==='travel')return [
  phase('travel-1','Script, sounds and survival basics','Recognize kana and use a few reliable phrases politely.','Greetings, thanks, numbers and polite repair phrases.','です/ます, simple questions and polite requests.','Read common words on signs such as 駅, 水 and 店.','Hear greetings, numbers and simple requests.','Greet someone and ask for help.','Use five core phrases from memory.','kana'),
  phase('travel-2','Food, cafés and shopping','Order, pay, ask prices and handle common shop exchanges.','Food, drinks, prices, quantities and payment.','これ/それ, いくら, をください and simple counters.','Read common menu and shop words in context.','Identify prices, choices and short staff replies.','Order an item and answer a follow-up question.','Complete a café or shop mission with less support.','minna'),
  phase('travel-3','Transport and directions','Buy or ask about tickets and find places.','Stations, platforms, time, locations and directions.','に/で, あります/います and where/how questions.','Recognize 駅, 電車, 入口, 出口 and common number displays.','Understand destination, time and direction words.','Ask where something is and clarify the answer.','Find a route using a short exchange.','kanji'),
  phase('travel-4','Hotel, plans and daily logistics','Handle check-in, simple plans, and routine needs.','Reservations, dates, room items and schedule words.','Past/present, requests and polite confirmation.','Read dates, room numbers and high-frequency signs.','Listen for names, dates, times and conditions.','Explain a reservation or simple request.','Roleplay check-in and a schedule change.','grammar'),
  phase('travel-5','Problems and conversation repair','Recover when you do not understand or plans change.','Lost items, health needs, delays and help phrases.','Please repeat, speak slowly, and simple reason patterns.','Recognize key kanji on signs, notices and help prompts.','Spot key information even when you miss a phrase.','Ask for repetition and confirm one key detail.','Use a repair phrase independently in two contexts.','listening'),
  phase('travel-6','Listen for the meaning, not every word','Understand short connected replies in familiar settings.','Common responses, reactions and question words.','Connect short clauses and notice sentence endings.','Read common travel compounds and message fragments.','Listen first, infer the situation, then check the transcript.','Respond naturally to a changed follow-up.','Complete a scene without opening translations first.','speaking'),
  phase('travel-7','Flexible travel conversations','Transfer known patterns across different places and people.','Review weak words and add context-specific vocabulary.','Choose useful forms based on intent and politeness.','Read menus, signs and short practical messages.','Handle small variations in speed and wording.','Complete a multi-turn travel scene and ask clarifying questions.','Pass a mixed scene challenge with limited hints.','scenes'),
  phase('travel-8','Travel-ready capstone and review','Combine reading, listening, recall and speaking for common travel tasks.','Personal weak list from previous practice.','Review only patterns that caused difficulty.','Review the kanji and words encountered in missions.','Repeat the most difficult listening items.','Complete a journey from arrival to asking for help.','Build a realistic next-stage plan from remaining gaps.','review'),
 ];
 if(purpose==='conversation')return [
  phase('conv-1','First conversations','Introduce yourself and exchange simple personal information.','Names, countries, languages, work/study and greetings.','です, ですか, は, の and polite question frames.','Read common identity and country words in context.','Recognize introductions and basic follow-ups.','Introduce yourself and ask two questions.','Hold a short introduction without a script.','kana'),
  phase('conv-2','Daily life and routines','Talk about when, where and how often things happen.','Time, days, places, daily actions and family.','に/で/を/へ and routine verbs.','Recognize days, times and common life words.','Catch the time and action in short descriptions.','Describe a normal day in three sentences.','Answer a follow-up about your routine.','minna'),
  phase('conv-3','Likes, hobbies and opinions','Explain preferences and ask someone about theirs.','Hobbies, food, entertainment and adjectives.','好き/きらい, adjectives and reason starters.','Read high-frequency words related to hobbies and media.','Recognize preferences and contrast words.','Talk about a hobby and ask one natural follow-up.','Keep a three-turn exchange going.','grammar'),
  phase('conv-4','Invitations and future plans','Make a plan, agree, refuse politely and negotiate time.','Days, places, invitations, transport and availability.','Future meaning, ましょう, ませんか and time expressions.','Read calendar, time and place words.','Hear dates, times and agreement/disagreement cues.','Invite someone and settle one detail.','Complete a plan-making roleplay.','listening'),
  phase('conv-5','Talk about past experiences','Describe what happened and ask about someone’s experience.','Events, travel, food, feelings and common verbs.','Past forms, sequencing and simple reasons.','Read common past-event vocabulary in short text.','Track who did what and when in a short story.','Tell a short story with a beginning and result.','Answer an unscripted follow-up about a past event.','minna'),
  phase('conv-6','Reactions and conversation repair','React, clarify and politely recover from misunderstandings.','Reactions, clarification, repetition and agreement.','Natural response patterns, そうですか and repair questions.','Notice useful words in chat and short messages.','Hear the intention even when not every word is known.','Ask for clarification and rephrase your meaning.','Recover a conversation without switching to English immediately.','speaking'),
  phase('conv-7','Longer exchanges and opinions','Connect ideas and keep a conversation moving beyond one-line replies.','Personal interests, reasons, preferences and plans.','Connectors and level-appropriate opinion patterns.','Read short posts/messages and identify main ideas.','Follow several turns and identify the speaker’s point.','Explain a preference and respond to a counterpoint.','Complete a 5–7 turn conversation.','scenes'),
  phase('conv-8','Conversation capstone','Apply known language in fresh contexts and identify your next gaps.','Review weak words and personal topics.','Repair the grammar patterns that repeatedly block expression.','Review vocabulary kanji encountered in daily practice.','Re-listen to difficult turns without the transcript first.','Speak about your day, preference and plan with fewer prompts.','Complete two different scene contexts independently.','review'),
 ];
 if(purpose==='media')return [
  phase('media-1','Read the script quickly','Build enough kana comfort to spend attention on meaning.','Kana-based everyday words, sound changes and common expressions.','Sentence boundaries and basic particles.','Connect kana readings to familiar kanji words.','Match clear audio phrases to text.','Read and repeat a short line, then explain it.','Recognize a short sentence without romanization.','kana'),
  phase('media-2','Everyday vocabulary behind dialogue','Recognize common nouns, actions, reactions and descriptions.','People, places, school, food, family, emotions and routines.','Present/past forms and question patterns.','Learn common beginner kanji as part of real words.','Listen for known words and phrase chunks.','Describe who is doing what in a simple dialogue.','Identify the key words in an unfamiliar short line.','minna'),
  phase('media-3','Grammar and sentence endings','Notice how particles, verb forms and endings affect meaning.','Verbs, adjectives, feelings and common reaction words.','Particles, requests, permission/prohibition and plain/polite contrasts as appropriate.','Review kanji words found in scripts and subtitles.','Compare a line with its transcript after a first listen.','Paraphrase what a character wants or feels.','Explain the role of a key ending in context.','grammar'),
  phase('media-4','Listening in chunks','Train your ear to group words into meaningful chunks.','Connectors, fillers, reaction phrases and common verbs.','Listening for particles, tense and omitted subjects.','Use kanji vocabulary to anchor the meaning of a line.','Listen, write down what you catch, then compare with a verified transcript.','Repeat a line for meaning and timing without claiming accent scoring.','Understand the main intent of a short scene.','listening'),
  phase('media-5','Casual speech and relationships','Notice register, familiarity and context without copying every phrase.','Casual variants, reactions, disagreement and emotion words.','Politeness contrasts and omitted subjects.','Read common kanji compounds that recur in scripts.','Identify tone and relationship cues from dialogue.','Convert a familiar polite idea into an appropriate casual form.','Explain when a phrase may be too casual for real life.','grammar'),
  phase('media-6','Genres and topic vocabulary','Build vocabulary around the genres you care about.','School, work, fantasy/action, daily life, comedy or romance terms.','Patterns for intention, possibility, reason and contrast.','Create a personal list of recurring kanji words from verified subtitles.','Listen for topic words and scene transitions.','Summarize a scene in simple Japanese or English.','Use a personal media vocabulary list in a comprehension check.','kanji'),
  phase('media-7','Episode-level comprehension habits','Follow the gist before looking up every line.','Review recurring expressions and weak vocabulary.','Review grammar that changes character intent.','Review repeated kanji compounds rather than isolated rare forms.','Listen once for gist, then note two key details.','Explain what happened and why using simple language.','Finish a short clip with a gist/detail checklist.','listening'),
  phase('media-8','Media capstone and personal deck','Measure comprehension in familiar genres and plan the next stretch.','Review personal vocabulary, not only prebuilt lists.','Revisit confusing endings and register choices.','Review the kanji terms appearing most often in your own material.','Re-listen to saved excerpts without the transcript first.','Retell a scene and connect it to a real-world conversation.','Complete a personal comprehension check without assuming native-level understanding.','ai'),
 ];
 if(purpose==='work-study')return [
  phase('work-1','Foundations and polite communication','Build a reliable base for introductions, questions and requests.','Names, roles, departments, dates and everyday office words.','Polite です/ます, basic questions and requests.','Read common role, location and date words.','Understand greetings and straightforward instructions.','Introduce yourself and clarify a simple request.','Use polite basics accurately in a short scene.','kana'),
  phase('work-2','Workplace routines and schedules','Discuss time, tasks, appointments and simple procedures.','Calendar, meetings, tasks, location and status words.','Time markers, routine verbs and polite requests.','Read dates, times and key labels in simple notices.','Identify task, person and deadline in short instructions.','Confirm a meeting time and task.','Explain a schedule change.','minna'),
  phase('work-3','Asking for clarification','Ask for repetition, examples and confirmation in a tactful way.','Clarification, explanation, repetition and confirmation.','Question forms and repair patterns.','Recognize key kanji on labels and basic notices.','Listen for action and deadline; confirm the key point.','Restate instructions to verify understanding.','Recover from a misunderstanding politely.','listening'),
  phase('work-4','Practical reading and documents','Read short messages, forms and notices for key information.','Names, dates, amounts, locations, tasks and status.','Sentence connectors and time expressions.','Learn high-use workplace compounds from trusted course materials.','Pair a short message with spoken context.','Summarize a short message and ask a follow-up.','Find required information in a simple notice.','kanji'),
  phase('work-5','Explaining needs and progress','Describe what you are doing, need or cannot yet do.','Task verbs, tools, blockers, progress and requests.','Can/cannot, wants/needs and reason patterns by level.','Review kanji words related to tasks and daily work.','Hear an issue and distinguish problem from proposed solution.','Give a brief status update and ask a question.','Explain a simple problem plus next action.','grammar'),
  phase('work-6','Meetings and collaborative exchange','Respond to questions and make short contributions.','Opinions, proposals, agreement, alternatives and follow-ups.','Suggestion and opinion patterns with suitable politeness.','Read meeting agenda words and common labels.','Listen for proposal, agreement and next steps.','Share an idea and respond to another person.','Complete a short meeting roleplay.','speaking'),
  phase('work-7','Independent workplace scenarios','Handle routine interactions with less preparation.','Personal field vocabulary and common workplace topics.','Review useful formal versus casual choices.','Read simple workplace messages with key kanji.','Follow longer instructions and ask targeted questions.','Explain a process or clarify responsibility.','Complete a multi-turn work scene.','scenes'),
  phase('work-8','Work/study capstone','Combine polite speaking, practical reading and listening.','Review weak vocabulary from previous scenes.','Revisit recurring grammar and politeness gaps.','Build a verified field-specific kanji list.','Summarize instructions and confirm details.','Explain a project or study need in a short roleplay.','Complete a capstone and list next-stage professional language needs.','review'),
 ];
 return [
  phase('base-1','Kana and sound foundations','Read hiragana and katakana and connect written forms to sound.','Greetings, numbers, classroom words and common expressions.','Japanese sentence order, は, です and basic questions.','Connect common kanji to words once kana feels comfortable.','Match short audio to familiar kana words.','Say your name and one simple need.','Read a short kana line without relying on romaji.','kana'),
  phase('base-2','Essential vocabulary and recall','Recall useful words in small, repeated contexts.','People, places, time, food, actions and adjectives.','の, も, を, に, で and question words.','Common N5 kanji learned through vocabulary.','Hear known words inside short phrases.','Describe one daily activity.','Retrieve words with the meaning hidden.','minna'),
  phase('base-3','Build accurate sentences','Turn vocabulary into usable sentence patterns.','Routine verbs, time, location and preferences.','Verb forms, polite requests and simple tense contrasts.','Review reading and meaning through compound words.','Listen for particles and sentence endings.','Answer a familiar question with your own information.','Create a new sentence using a known pattern.','grammar'),
  phase('base-4','Kanji and reading habits','Connect characters, readings, vocabulary and short text.','High-frequency nouns, verbs, days, time and daily life.','Read sentence frames and notice modifiers.','Use memory cues and review both readings only when common; learn words in context.','Infer the main idea from a short text plus audio.','Read a sign, label or short message and explain it.','Answer a comprehension question about a short paragraph.','kanji'),
  phase('base-5','Listening confidence','Understand common responses and clarify what you missed.','Questions, reactions, directions and daily routines.','Repair phrases, polite follow-up questions and common connectors.','Revisit kanji vocabulary that blocked comprehension.','Listen once for gist, once for key details and then check text.','Respond to a short prompt with less visual support.','Explain the key information heard.','listening'),
  phase('base-6','Flexible everyday communication','Use learned patterns with changed names, objects and settings.','Plans, shopping, hobbies, needs and simple problems.','Choose forms based on intention and context.','Read common words within scene dialogue.','Recognize meaning despite a changed phrase.','Complete a multi-turn conversation.','Transfer one pattern to two different contexts.','scenes'),
  phase('base-7','Build toward independence','Combine reading, listening, grammar and recall.','Personal weak vocabulary and a new everyday topic.','Review patterns that repeatedly cause confusion.','Review the kanji encountered across readings and scenes.','Follow a slightly longer dialogue for gist and details.','Explain a plan, need, or experience in a short roleplay.','Complete a mixed practice set and correct weak areas.','speaking'),
  phase('base-8','Consolidation and next-level bridge','Demonstrate what is reliable and identify the next level of learning.','Review high-frequency words and personal weak list.','Consolidate core patterns before adding complexity.','Review common kanji in context and add new target-level words only from reliable material.','Re-listen to difficult phrases without text first.','Complete a capstone scene, then repeat it with a variation.','Make a next-stage plan based on demonstrated strengths and gaps.','review'),
 ];
}

export function createGuidedRoadmap(input:RoadmapPlanInput):LearningRoadmapPlan{
 let phases=guidedRoadmapPhases(input.purpose,input.target).map(p=>({...p}));
 if(input.targetDays>=730&&input.purpose!=='jlpt')phases=longHorizonPhases(phases,input.purpose);
 const title=({travel:'Japan travel roadmap',conversation:'Everyday conversation roadmap',jlpt:`${input.target.toUpperCase().replace('JLPT-','JLPT ')} study roadmap`,'work-study':'Work & study in Japan roadmap',media:'Anime & media comprehension roadmap',foundation:'Japanese foundations roadmap'} as Record<LearningPurpose,string>)[input.purpose];
 const summary=`A ${input.targetDays}-day, ${input.dailyMinutes}-minute daily plan progressing through ${phases.length} phases. Tasks rotate between new learning, recall, reading/kanji, listening, and real-context use; rest days are optional review days.`;
 const today=input.startDate??localDateKey(new Date());
 return {id:input.id,mode:'guided',title,summary,goal:input.goal,createdAt:input.createdAt??new Date().toISOString(),startDate:today,targetDays:input.targetDays,studyDaysPerWeek:input.studyDaysPerWeek,dailyMinutes:input.dailyMinutes,learnerLevel:input.learnerLevel,purpose:input.purpose,target:input.target,phases,completedDayNumbers:[]};
}

export function createAiRoadmap(input:RoadmapPlanInput & {title:string;summary:string;phases:LearningRoadmapPhase[]}):LearningRoadmapPlan{
 return {...input,mode:'ai-custom',createdAt:input.createdAt??new Date().toISOString(),startDate:input.startDate??localDateKey(new Date()),completedDayNumbers:[]};
}

function localDateKey(date:Date){return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;}

const roadmapTopicBanks:Record<LearningPurpose,string[]>={
 travel:['Greetings, polite requests and repair phrases','Numbers, prices, and paying','Food orders, menus, and dietary needs','Stations, tickets, transfers, and platform signs','Hotel check-in, reservations, and room requests','Time, dates, and changing plans','Shopping, sizes, quantities, and returns','Directions, landmarks, and confirming routes','Pharmacies, lost items, and asking for help','Weather, delays, and cancellations','Reading short signs and public notices','Friendly small talk and polite reactions','Combining travel tasks into a full-day itinerary','Reviewing the phrases and kanji that caused mistakes'],
 conversation:['Self-introductions and follow-up questions','Family, work, study, and personal background','Daily routines, time, and frequency','Food preferences and ordering together','Hobbies, entertainment, and interests','Invitations, agreeing, and polite refusals','Past experiences and telling short stories','Plans, hopes, and simple reasons','Feelings, reactions, and showing interest','Opinions, comparisons, and gentle disagreement','Apologies, clarification, and repairing misunderstandings','Natural short responses and conversation fillers','Longer multi-turn conversations with topic changes','Talking about your week with fewer prompts'],
 jlpt:['Core vocabulary recall and word families','Particles and basic sentence structure','Verb/adjective forms and tense contrasts','Kanji recognition through words and compounds','Reading for the main idea and key details','Listening for speaker, place, time, and intent','Question patterns and choosing a natural response','Confusable grammar and distractor analysis','Short notices, messages, and practical reading','Mixed skill sets and error logs','Timed practice with deliberate review','Retesting weak vocabulary and kanji','Target-level text/audio using verified materials','Readiness audit and a focused next review cycle'],
 'work-study':['Introductions, roles, and appropriate politeness','Schedules, deadlines, dates, and meeting times','Clarifying instructions and confirming details','Tasks, tools, progress, and blockers','Short emails, notices, and workplace messages','Requests, proposals, and offering alternatives','Meeting participation and follow-up questions','Apologies, delays, and status updates','Department-specific vocabulary from verified materials','Reading forms, labels, and key kanji compounds','Explaining a problem and proposed next action','Formal versus casual language choices','Multi-turn workplace or school roleplays','Reviewing misunderstandings and missing vocabulary'],
 media:['Kana speed and word chunking','Everyday vocabulary in school and home scenes','Feelings, reactions, and interpersonal relationships','Particles and verb endings that change intent','Polite versus casual speech and register','Common contractions and omitted subjects','High-frequency kanji in subtitles and signs','Genre vocabulary from the media you actually watch','Listening once for gist before reading subtitles','Catching reasons, contrasts, and implied meaning','Summarizing a short scene in your own words','Noticing humor, sarcasm, and uncertainty cautiously','Collecting recurring phrases with verified context','Retelling a scene, then reusing its language in real life'],
 foundation:['Hiragana recognition and sound combinations','Katakana recognition and loanwords','Greetings, names, numbers, and classroom language','Particles and short sentence frames','People, places, time, and daily-life vocabulary','Verbs, routines, and polite requests','Common kanji connected to useful words','Adjectives, preferences, and descriptions','Listening for known words in short phrases','Reading short sentences without romaji','Changing one detail to create a new sentence','Asking follow-up and clarification questions','Combining vocabulary, grammar, kanji, and speaking','Reviewing weak points and choosing the next level'],
};
function topicForRoadmapWeek(plan:LearningRoadmapPlan,weekNumber:number):string{
 const topics=roadmapTopicBanks[plan.purpose]??roadmapTopicBanks.foundation;
 let topic=topics[Math.floor((weekNumber-1)/4)%topics.length];
 if(plan.purpose==='jlpt'&&plan.target!=='jlpt-n5'){
  const n=Number(plan.target.slice(-1));const level=plan.target.toUpperCase().replace('JLPT-','JLPT ');
  const advancedTopics=['Prerequisite review and diagnostic','Level-matched vocabulary and collocations','Grammar contrasts and sentence patterns','Kanji compounds and contextual readings','Longer reading and paragraph structure','Listening for speaker intent and inference','Mixed question practice and error logging','Timed and untimed checks with deliberate review','Verified topic passages and weak-skill repair','Readiness audit and next-cycle planning'];
  topic=`${level}: ${advancedTopics[Math.floor((weekNumber-1)/4)%advancedTopics.length]}`;
 }
 return plan.mode==='ai-custom'?`${topic} Apply it to your custom goal: ${plan.goal.slice(0,180)}`:topic;
}
export function getCurrentRoadmapDay(plan:LearningRoadmapPlan,now=new Date()):number{
 const [year,month,day]=plan.startDate.split('-').map(Number);
 const start=new Date(year,month-1,day);start.setHours(0,0,0,0);
 const today=new Date(now.getFullYear(),now.getMonth(),now.getDate());today.setHours(0,0,0,0);
 const elapsed=Math.floor((today.getTime()-start.getTime())/86400000)+1;
 return Math.max(1,Math.min(plan.targetDays,elapsed));
}
/** Number of planned learning days, excluding recovery/rest days from the completion denominator. */
function studyWeekIndexes(studyDaysPerWeek:number):number[]{
 if(studyDaysPerWeek>=7)return [0,1,2,3,4,5,6];
 return Array.from({length:studyDaysPerWeek},(_,index)=>Math.round(index*6/(studyDaysPerWeek-1)));
}
export function getRoadmapStudyDayCount(plan:LearningRoadmapPlan):number{
 const fullWeeks=Math.floor(plan.targetDays/7);const remainder=plan.targetDays%7;
 return fullWeeks*plan.studyDaysPerWeek+studyWeekIndexes(plan.studyDaysPerWeek).filter(index=>index<remainder).length;
}
export function phaseForRoadmapDay(plan:LearningRoadmapPlan,dayNumber:number):LearningRoadmapPhase{
 const safeDay=Math.max(1,Math.min(plan.targetDays,dayNumber));
 const index=Math.min(plan.phases.length-1,Math.floor(((safeDay-1)*plan.phases.length)/plan.targetDays));
 return plan.phases[index]??guidedRoadmapPhases(plan.purpose,plan.target)[0];
}

export function taskForRoadmapDay(plan:LearningRoadmapPlan,dayNumber:number):RoadmapDayTask{
 const safeDay=Math.max(1,Math.min(plan.targetDays,dayNumber));
 const weekNumber=Math.floor((safeDay-1)/7)+1;
 const dayOfWeek=(safeDay-1)%7;
 const currentPhase=phaseForRoadmapDay(plan,safeDay);
 const phaseIndex=Math.min(plan.phases.length-1,Math.floor(((safeDay-1)*plan.phases.length)/plan.targetDays));
 const phaseFirstDay=Math.ceil(phaseIndex*plan.targetDays/plan.phases.length)+1;
 const phaseSession=safeDay-phaseFirstDay+1;
 const cycleIndex=(weekNumber-1)%4;
 const cycleLabels=['Learn the basics','Practise with support','Transfer to a new context','Retrieve and check'];
 const cycleInstructions=[
  'Build the basics: study a small amount carefully and understand the examples before trying to memorize them.',
  'Practise with support: use examples or hints when needed, then repeat the task with the answer hidden.',
  'Transfer to a new context: change the person, place, topic, or intention and apply the same skill again.',
  'Retrieve and check: attempt the skill from memory first, review mistakes, then try once more without help.',
 ];
 const activeWeekIndexes=studyWeekIndexes(plan.studyDaysPerWeek);
 const studyOrdinal=activeWeekIndexes.indexOf(dayOfWeek);
 if(studyOrdinal<0){
  return {dayNumber:safeDay,weekNumber,phase:currentPhase,title:'Rest, catch up, or optional review',activity:'No new lesson is required today. Rest, or spend up to 5 minutes revisiting a difficult phrase or kanji. Missed days never erase earlier progress.',route:'/review',isRestDay:true,focusLabel:'Recovery & retention',estimatedMinutes:Math.min(5,plan.dailyMinutes),phaseSession,cycleLabel:'Rest and retain',successCheck:'Rest without guilt, or recall one phrase or kanji before revealing its meaning.'};
 }
 const allSlots:Array<{title:string;focus:string;route:RoadmapFocusRoute;activity:(p:LearningRoadmapPhase)=>string}>= [
  {title:currentPhase.title,focus:'Learn',route:currentPhase.primaryRoute,activity:p=>`${p.outcome} Start with the suggested activity, then write down one thing you can now understand or say. Grammar to notice: ${p.grammarFocus}`},
  {title:'Vocabulary & kanji in context',focus:'Words and writing',route:plan.purpose==='media'||plan.purpose==='jlpt'?'kanji':'minna',activity:p=>`Work on this phase's vocabulary: ${p.vocabularyFocus} Kanji focus: ${p.kanjiFocus}`},
  {title:'Grammar and sentence patterns',focus:'Build accurate sentences',route:'grammar',activity:p=>`${p.grammarFocus} Make two examples about your own life and check whether the meaning fits.`},
  {title:'Listen for meaning',focus:'Listening',route:'listening',activity:p=>`${p.listeningFocus} Listen for the situation and one key detail before revealing the text.`},
  {title:'Use Japanese in a scene',focus:'Real-world transfer',route:plan.purpose==='media'?'ai':plan.purpose==='work-study'?'speaking':'scenes',activity:p=>`${p.speakingMission} Change one detail so you are not simply repeating a memorized answer. Checkpoint: ${p.checkpoint}`},
  {title:'Speak, recall, and repair',focus:'Active recall',route:'memory-to-mouth',activity:p=>`Try ${p.speakingMission.toLowerCase()} without looking at the model first. If stuck, use a hint, then retry independently.`},
  {title:'Weekly checkpoint',focus:'Review and test',route:plan.target==='jlpt-n5'?'jlpt-n5':'review',activity:p=>`${p.checkpoint} Review mistakes and mark one weak point for the next study cycle.`},
 ];
 // Fit the skill mix to the learner's schedule. Short schedules combine skills instead of accidentally omitting speaking or listening.
 const scheduleByDays:Record<number,number[]>={
  3:[0,2,4],
  4:[0,1,3,4],
  5:[0,1,2,3,4],
  6:[0,1,2,3,4,5],
  7:[0,1,2,3,4,5,6],
 };
 const schedule=scheduleByDays[plan.studyDaysPerWeek]??scheduleByDays[5];
 const slotIndex=schedule[studyOrdinal]??0;
 let slot=allSlots[slotIndex]??allSlots[0];
 if(plan.studyDaysPerWeek===3&&studyOrdinal===0){slot={...slot,title:`${slot.title} + vocabulary preview`,activity:p=>`${p.outcome} Start with the suggested activity, then preview these words: ${p.vocabularyFocus}`};}
 if(plan.studyDaysPerWeek===3&&studyOrdinal===1){slot={...slot,title:'Grammar, kanji, and sentence building',activity:p=>`${p.grammarFocus} Kanji focus: ${p.kanjiFocus} Write two short examples and check their meanings.`};}
 if(plan.studyDaysPerWeek===3&&studyOrdinal===2){slot={...slot,title:'Listening, speaking, and weekly transfer',route:plan.purpose==='media'?'ai':plan.purpose==='work-study'?'speaking':'scenes',activity:p=>`${p.listeningFocus} Then complete this speaking mission: ${p.speakingMission} Checkpoint: ${p.checkpoint}`};}
 if(plan.studyDaysPerWeek===4&&studyOrdinal===2){slot={...slot,title:'Grammar and listening together',activity:p=>`${p.grammarFocus} Then listen for this phase's target: ${p.listeningFocus}`};}
 if(plan.studyDaysPerWeek===4&&studyOrdinal===3){slot={...slot,title:'Scene practice and weekly checkpoint',activity:p=>`${p.speakingMission} Checkpoint: ${p.checkpoint}`};}
 const successChecks=[
  'Explain the phase outcome in your own words or produce one original Japanese line.',
  'Recall at least 3–5 target words or kanji from meaning/reading without looking at the answer first.',
  'Make two original examples and explain what the grammar pattern changes in meaning.',
  'State the gist and one key detail before opening a transcript or translation.',
  'Complete a scene with one changed detail; ask a clarification question when you get stuck.',
  'Try the mission phrase from memory, then independently retry the first item you missed.',
  'Name three weak points and choose one specific item to review in the next study cycle.',
 ];
 const combinedCycleText=`${cycleInstructions[cycleIndex]} Topic for this four-week block: ${topicForRoadmapWeek(plan,weekNumber)}. Phase session ${phaseSession}.`;
 return {dayNumber:safeDay,weekNumber,phase:currentPhase,title:slot.title,activity:`${combinedCycleText} ${slot.activity(currentPhase)}`,route:roadmapRoute(slot.route),isRestDay:false,focusLabel:slot.focus,estimatedMinutes:plan.dailyMinutes,phaseSession,cycleLabel:cycleLabels[cycleIndex],successCheck:successChecks[slotIndex]??successChecks[0]};
}
