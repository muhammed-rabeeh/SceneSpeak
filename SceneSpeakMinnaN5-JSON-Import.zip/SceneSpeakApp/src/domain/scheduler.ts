export type ReviewOutcome = 'missed'|'revealed'|'hinted'|'hard'|'good'|'easy';
export interface ScheduleInput { outcome: ReviewOutcome; successfulReviews?: number; now?: Date }
export interface ScheduleResult { nextReviewAt: string; intervalDays: number; retryThisSession: boolean; rationale: string }
const DAY=24*60*60*1000;
export function scheduleNextReview(input: ScheduleInput): ScheduleResult {
 const now=input.now??new Date(); const history=Math.max(0,input.successfulReviews??0);
 let days:number, retry=false, rationale='';
 switch(input.outcome){
  case 'missed': case 'revealed': days=1; retry=true; rationale='Revisit soon; seeing the answer is practice, not independent retrieval.'; break;
  case 'hinted': days=1; rationale='Use a short interval after a hinted response.'; break;
  case 'hard': days=2; rationale='Short interval after a difficult independent recall.'; break;
  case 'good': days=4; rationale='A moderate interval after a successful independent recall.'; break;
  case 'easy': days=history>=2?Math.min(21,7+Math.max(0,history-2)*3):7; rationale='Extend gradually after repeated easy retrievals.'; break;
 }
 const next=new Date(now.getTime()+days*DAY);
 return {nextReviewAt:next.toISOString(),intervalDays:days,retryThisSession:retry,rationale};
}
export function isDue(nextReviewAt: string|undefined, now=new Date()):boolean { return !nextReviewAt || new Date(nextReviewAt).getTime()<=now.getTime(); }
