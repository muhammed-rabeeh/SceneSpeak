export type SkillName = 'recognition' | 'listening' | 'recall' | 'transfer';
export type Difficulty = 'starter' | 'beginner' | 'elementary';
export interface CourseModule {
  id: string; order: number; title: string; subtitle: string; icon: string; accent: string; outcomes: string[];
}
export interface Phrase {
  id: string; moduleId: string; sceneId?: string; nativeScript: string; kana: string; romanization: string;
  meaning: string; usageNote: string; pattern: string; tags: string[]; difficulty: Difficulty; example: string;
  exampleMeaning: string; category: string; synthesizedAudio: true;
}
export interface Scene {
  id: string; moduleId: string; order: number; title: string; description: string; setting: string;
  emoji: string; estimatedMinutes: number; level: Difficulty; missionGoal: string; phraseIds: string[];
}
export interface GrammarEntry {
  id: string; title: string; pattern: string; explanation: string; examples: { jp: string; reading: string; romanization: string; en: string }[];
  contrast: string; moduleId: string; quiz: { prompt: string; answer: string; explanation: string };
}
export interface PhraseProgress {
  phraseId: string; recognitionScore: number; listeningScore: number; recallScore: number; transferScore: number;
  attempts: number; correctWithoutHint: number; correctWithHint: number; incorrectAttempts: number;
  lastReviewedAt?: string; nextReviewAt?: string; consecutiveSuccessfulReviews: number; lastDifficultyRating?: 'again'|'hard'|'good'|'easy';
  history: { at: string; skill: SkillName; result: 'independent'|'hinted'|'revealed'|'missed'; note?: string }[];
}
export interface SessionRecord {
  id: string; sceneId: string; startedAt: string; completedAt?: string; phrasesRetrieved: number; phrasesSpoken: number;
  hintsUsed: number; answerRevealed: boolean; transferSuccessful: boolean; summary: string; lastStep?: number;
}
export interface Profile {
  nativeLanguage: string; targetLanguage: string; level: 'Complete beginner'|'Beginner'|'Returning learner';
  dailyGoalMinutes: 5|10|15; goal: string; onboardingComplete: boolean; showRomanization: boolean;
}
export interface SavedScene extends Scene { aiGenerated?: boolean; createdAt?: string; targetPhrases?: Phrase[]; turns?: { speaker: 'npc'|'learner'; japanese: string; reading?: string; romanization?: string; meaning?: string }[] }
export interface AppSettings {
  selectedModel: string; aiEnabled: boolean; installDismissed?: boolean; lastBackupAt?: string; lastRoute?: string;
}
export interface PracticeEvent {
  id: string; at: string; phraseId?: string; sceneId?: string; type: string; detail?: string;
}
export interface AppBackup {
  schema: 'scenespeak-backup'; version: 1|2|3; exportedAt: string;
  profile: Profile; settings: AppSettings; progress: PhraseProgress[]; sessions: SessionRecord[];
  favorites: string[]; notes: Record<string,string>; savedScenes: SavedScene[]; kanaProgress: Record<string,number>;
  grammarProgress: Record<string,number>; events: PracticeEvent[]; activeRoleplay?: ActiveRoleplay|null;
  speakingEvidence?: import('./enhancements').SpeakingEvidence[]; minnaSessions?: import('./enhancements').MinnaSession[];
  jlptAttempts?: import('./enhancements').JLPTAttempt[]; personalVocabulary?: import('./enhancements').PersonalVocabulary[];
  minnaPacks?: import('./enhancements').MinnaContentPack[];
}

export interface ActiveRoleplay { id: string; scenario: SavedScene; generated: import('../services/ai').GeneratedScene; turns: { speaker:'npc'|'learner'; japanese:string; meaning?:string; romanization?:string; coaching?:string }[]; updatedAt:string }
