import type { PhraseProgress, SkillName } from './types';
import type { ReviewOutcome } from './scheduler';
export type ResultKind = 'independent'|'hinted'|'revealed'|'missed';
export function emptyProgress(phraseId:string):PhraseProgress {
 return {phraseId,recognitionScore:0,listeningScore:0,recallScore:0,transferScore:0,attempts:0,correctWithoutHint:0,correctWithHint:0,incorrectAttempts:0,consecutiveSuccessfulReviews:0,history:[]};
}
export function outcomeValue(result:ResultKind):number { return result==='independent'?100:result==='hinted'?55:0; }
export function boundedScore(value:number):number { if(!Number.isFinite(value)) return 0; return Math.max(0,Math.min(100,Math.round(value))); }
export function applyPractice(progress:PhraseProgress|undefined, phraseId:string, skill:SkillName, result:ResultKind, at=new Date(), note?:string):PhraseProgress {
 const current=progress?structuredClone(progress):emptyProgress(phraseId);
 // Answer exposure is useful instruction, but it is not evidence of recognition, listening, recall, or transfer.
 // Keep the event for an audit trail without changing skill scores, attempt counts, or success streaks.
 current.history.push({at:at.toISOString(),skill,result,note});
 if(result==='revealed') return current;
 const scoreKey = ({recognition:'recognitionScore',listening:'listeningScore',recall:'recallScore',transfer:'transferScore'} as const)[skill];
 const nextValue=outcomeValue(result);
 // Reveals are excluded from the average denominator as well as from successful-recall counters.
 const priorCount=current.history.filter(h=>h.skill===skill&&h.result!=='revealed').length-1;
 current[scoreKey]=boundedScore(priorCount<=0?nextValue:(current[scoreKey]*priorCount+nextValue)/(priorCount+1));
 if(skill==='recall'){
  current.attempts+=1;
  if(result==='independent') current.correctWithoutHint+=1;
  if(result==='hinted') current.correctWithHint+=1;
  if(result==='missed') current.incorrectAttempts+=1;
  if(result==='independent') current.consecutiveSuccessfulReviews+=1;
  else if(result==='missed') current.consecutiveSuccessfulReviews=0;
  current.lastReviewedAt=at.toISOString();
 }
 return current;
}
export function outcomeToSchedule(result:ResultKind):ReviewOutcome {
 return result==='independent'?'good':result==='hinted'?'hinted':result==='revealed'?'revealed':'missed';
}
export function abilityLabel(score:number, count=1):string {
 if(count===0||score===0) return 'Getting started';
 if(score<40) return 'Needs another try';
 if(score<70) return 'Building recall';
 if(score<90) return 'Building confidence';
 return 'Ready to test';
}
