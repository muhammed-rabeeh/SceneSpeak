# SceneSpeak Minna content-pack JSON format

SceneSpeak ships an original, JLPT N5-aligned Minna Shokyu I companion pack. Other levels can be imported in the Minna lesson selector with **Import level pack JSON**.

## Recommended workflow

1. Open SceneSpeak → Minna no Nihongo → **Download JSON** on the built-in N5 pack.
2. Make a copy of that JSON file. Edit the top-level `id`, `name`, `level`, and `description` to describe your new pack (for example `minna-n4-companion`, `Minna companion · N4 extension`, `JLPT N4`).
3. Replace or edit the `lessons` array. Each lesson should use the same structure as the downloaded pack.
4. Import the edited file. SceneSpeak validates it before storing it and keeps it separate from the built-in N5 pack. Imported vocabulary is marked `user-imported`.

The built-in N5 pack is not replaced by imports. Imported packs and their lesson sessions are stored in IndexedDB on the current device and are included in version 3 full backups. Importing a file never executes JavaScript or HTML; its values are rendered as text.

## Required top-level fields

- `schema`: exactly `scenespeak-minna-pack`
- `version`: exactly `1`
- `id`: 3–80 letters, digits, dots, underscores, or hyphens; should be stable and unique
- `name`: human-readable pack name, at most 120 characters
- `level`: label such as `JLPT N4` or `Business Japanese`, at most 40 characters
- `description`: a short description, at most 1,000 characters
- `lessons`: an array of 1–60 lesson objects

Each lesson must include `lessonNumber` (unique integer), `title`, `topic`, `situation`, non-empty `objectives`, `vocabulary`, `grammar`, `dialogue`, `listeningQuestion`, and `exitQuestion`. Vocabulary entries need `id`, `japanese`, `reading`, `romanization`, `meaning`, `exampleJapanese`, and `exampleMeaning`. Grammar entries need `id`, `title`, `pattern`, `meaning`, `form`, `explanation`, `commonMistake`, and one or more `examples` containing `japanese`, `reading`, `romanization`, and `meaning`. Dialogue turns use `speaker` (`A` or `B`), `japanese`, `reading`, and `meaning`. Each quiz question has a `prompt`, at least two `options`, an `answerIndex` pointing to one of those options, and an `explanation`.

The app also bundles the generated pack at `public/lesson-packs/scenespeak-minna-n5-pack.json`; the in-app **Download JSON** control exports the same structured data. Import files are limited to 5 MB. The downloadable N5 JSON is the canonical working example. It contains 25 original companion lessons with 10 vocabulary records per lesson. Lessons 1–15 are tagged as the N5-focused core; lessons 16–25 preserve the Minna Shokyu I companion sequence and are tagged bridge/enrichment because some structures may extend beyond strict N5 focus. The JLPT organiser does not publish a current exhaustive vocabulary/kanji/grammar checklist, so SceneSpeak describes this material as N5-aligned rather than official or exhaustive.

## Content guidance

- Write original lesson explanations, examples, dialogues, and practice questions. Do not bundle copied textbook pages, commercial audio, or answer keys.
- Add readings and a natural English gloss for beginner Japanese; use conservative common phrasing.
- Keep one correct answer for each multiple-choice question and make distractors plausible.
- Include no API keys, personal data, or executable code in a pack.
