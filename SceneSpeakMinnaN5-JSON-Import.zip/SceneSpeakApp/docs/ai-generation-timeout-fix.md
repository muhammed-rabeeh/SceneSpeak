
## Follow-up fix: structured-response correction and diagnostics

If Gemini returns a response that is valid text but does not satisfy the app's strict lesson/roadmap data schema, the app now makes one bounded correction request before failing. This correction is attempted only for malformed JSON or schema-validation problems, not for quota, permission, network, or timeout failures.

The error mapper now distinguishes common API/network failures, output-token truncation, and invalid structured data. For otherwise unknown errors, it displays a short redacted diagnostic rather than replacing every failure with the same generic sentence. API-key-like strings and request URLs are removed from diagnostic text before it is shown.

This can recover from an incomplete field or minor JSON format issue, but it cannot solve a revoked key, exhausted quota, unavailable model, blocked network, or provider outage. If generation still fails, share the visible diagnostic with support; never share the API key itself.
