# Daily Learning Roadmap

SceneSpeak's Learning Path is now a saved, day-by-day roadmap rather than only a timeline estimate and XP milestones.

## Guided roadmap

The learner chooses a purpose, target, timeline, study days per week, daily minutes, and a plain-language goal. SceneSpeak creates eight progressive phases and generates a dated task for every calendar day in the target timeline. Study days are spread across the week according to the selected frequency (rather than clumping all study days at the start of the week) and rotate through new learning, vocabulary/kanji, grammar, listening, contextual use, active recall, and/or review. Each card includes estimated minutes, a four-step practice cycle (learn, supported practice, transfer, retrieve/check), and a measurable success check. Non-study days are optional rest/recovery days, and do not count against the study-progress denominator. A learner can browse the entire plan by week and manually mark a day complete.

Daily tasks link to existing app features. Completions are stored in the optional `Profile.learningPathPlan` property in IndexedDB using the existing profile record. No new IndexedDB object store or schema version is needed. The existing profile object is included in JSON backup/restore and Supabase cloud snapshots, so the roadmap is carried along with the rest of the profile. Backups from older app versions remain valid because the property is optional.

## AI-custom roadmap

The AI-custom option uses the Gemini key that the learner already configured in Profile & Settings. Gemini generates a structured phase blueprint with learning outcomes, vocabulary, grammar, kanji/reading, listening, speaking missions, checkpoints, and allowed in-app practice destinations. SceneSpeak expands the phases into the complete daily schedule on-device. The API key is used for generation only and is not copied into the roadmap.

AI-generated text should be checked by the learner. It is not certified curriculum. The bundled structured curriculum remains mainly beginner/N5; roadmaps aimed at JLPT N4–N1 or advanced workplace/media comprehension must use verified matching-level packs/materials and should not be treated as proof of exam readiness or fluency.

## Data model

- `LearningRoadmapPlan` is optional on `Profile` and therefore backward-compatible.
- `LearningRoadmapPhase` provides eight core guided stages (expanded to ten for long non-JLPT horizons) or 6–10 AI-produced phase blueprints.
- `completedDayNumbers` stores calendar day numbers marked complete by the learner; the percentage is measured against planned study days, excluding rest days.
- Daily tasks are computed deterministically from the plan settings and phase blueprints; a separate record for each of 30–1,095 days is not stored. Weeks across the roadmap follow a repeating four-part cycle—learn the basics, practise with support, transfer to a changed context, then retrieve/check. The topic changes in four-week blocks using purpose-specific theme banks, while each selected phase controls the vocabulary, grammar, kanji, listening, speaking mission, and checkpoint detail. Study days are distributed across the week rather than all being clumped first.

The roadmapping logic is in `src/domain/roadmap.ts`; Gemini blueprint generation is in `src/services/ai.ts`; UI is in `PathPlannerPage` within `src/App.tsx`.
