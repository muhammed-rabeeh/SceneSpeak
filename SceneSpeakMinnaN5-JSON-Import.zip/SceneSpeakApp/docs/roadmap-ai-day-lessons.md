# On-demand AI lessons for the Learning Path

Each day card in Learning Path opens `/path/day/:dayNumber`; it no longer sends the learner directly to a generic kana, kanji, grammar, scene, or review route. When the day has no cached lesson, SceneSpeak uses the Gemini key configured by the learner to generate a complete lesson from the active roadmap, phase, level, learning target, daily time budget, and task success check.

## What each generated lesson includes

- Daily goals and a time plan
- A warm-up with a model answer
- Target vocabulary with kana readings, romanization, translations, and example sentences
- One to three grammar patterns with examples
- Relevant kanji and useful words when appropriate for the learner's phase
- A contextual dialogue with readings and translations, plus optional browser speech synthesis
- Listening prompts and guided practice with model answers
- A scored multiple-choice knowledge check, retrieval prompts, and a speaking/transfer mission
- A recap and the roadmap's success check

The content is generated when first opened, rather than bundled for every possible day in the app download. It is then stored inside the active learning roadmap in the local IndexedDB profile. A rolling cache keeps at most 30 recently generated daily lessons to limit storage growth. The currently cached lesson can be reused without another model call and can be reviewed offline. A learner can explicitly regenerate a cached lesson while online.

The quiz requires all questions to be answered and a score of at least 60% (rounded up) before the lesson's completion button enables. The passing threshold is a product-level checkpoint, not a validated proficiency exam. The learner can still open a previously completed lesson to review it.

## Requirements and limitations

- A Gemini API key must be configured in Profile & Settings, and the device must be online to generate a new lesson. Without a key, cached lessons and all existing curated learning areas remain available; a missing lesson cannot be generated offline.
- The app uses the model selected in Settings. Invalid keys, unavailable models, quota limits, network errors, and malformed AI responses are surfaced as errors so the app does not silently substitute an unrelated activity.
- The lesson is saved in the profile and included in existing backup/cloud snapshot data. AI-generated Japanese may contain mistakes and is not claimed to be reviewed by a native-speaker editor. Advanced goals and JLPT N4–N1 still need reliable level-matched sources.
- Speech playback depends on voices installed by the browser or device. The app does not claim that a saved audio file is generated.

## Smoke-test checklist

1. Create a guided roadmap, open a day with Gemini configured, and confirm the generated lesson matches its title, target, phase, and success check.
2. Complete the quiz with fewer than 60% correct and confirm that the completion action remains disabled.
3. Pass the quiz and confirm the day is saved as completed and the app returns to Learning Path.
4. Reopen that day and confirm its cached lesson loads without another generation call.
5. Open a different day and confirm its material is independently generated.
6. Remove the API key and open an uncached day; confirm that the page explains how to configure Gemini instead of opening a generic activity.
7. Export a backup and check that the active plan and its recent cached lessons are included.
