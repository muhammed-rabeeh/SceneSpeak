# SceneSpeak IndexedDB recovery migration (schema v4)

SceneSpeak now opens `scenespeak-local` at schema version 4. The v4 upgrade checks every required object store and index individually and creates only missing ones. It does not delete, clear, or recreate existing stores, so existing learning progress is preserved.

If the browser shows a database-load error after deployment:

1. Close other SceneSpeak tabs or installed-app windows that may still be open.
2. Reload the latest deployment so the v4 migration can run.
3. If the error panel appears, use **Retry storage connection**.
4. Do not clear browser site data unless you have exported a backup; clearing site data may permanently remove local progress.

The welcome screen now surfaces the database error and catches the onboarding save failure rather than leaving the button appearing to do nothing.
