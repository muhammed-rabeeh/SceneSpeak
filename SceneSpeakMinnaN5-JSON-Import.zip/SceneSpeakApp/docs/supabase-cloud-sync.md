# SceneSpeak cloud sync with Supabase (no custom server)

SceneSpeak stays local-first. Cloud sync is optional and user-triggered: upload a full snapshot from one device, then merge it on another device. The app is still hosted as static files on Netlify; Supabase provides managed authentication and a small Postgres table.

## Before starting

- Create or select a Supabase project at <https://supabase.com/dashboard>.
- Make sure you can access the project's **Project URL** and public **publishable key**. A legacy `anon` key is also accepted by the app.
- Never put a `service_role` key or secret key in the browser or in a `VITE_*` variable. The publishable/anon key is public by design; row-level security is what restricts records to the signed-in user.

## 1. Create the sync table securely

1. Open the Supabase project's **SQL Editor**.
2. Open `supabase/scenespeak_cloud_sync.sql` from this repository and copy/paste the complete contents into a new query.
3. Run it once. It creates `public.scenespeak_cloud_backups`, enables Row Level Security, revokes default broad grants, grants authenticated users the operations required for their own backup, and adds separate policies that compare `user_id` to `auth.uid()`.
4. In **Table Editor**, confirm the table exists and RLS is enabled. Do not disable RLS or add a public/anonymous policy.

The security model follows Supabase's RLS guidance: grants and policies are both needed, and the `service_role` key bypasses RLS and must remain secret. Reference: <https://supabase.com/docs/guides/database/postgres/row-level-security>.

## 2. Enable email/password authentication

1. In Supabase, go to **Authentication → Providers → Email** and ensure email/password sign-in is enabled.
2. Decide whether users must confirm their email. If confirmation is enabled, SceneSpeak displays a message after account creation; confirm the email, then sign in.
3. In **Authentication → URL Configuration**, set the **Site URL** to your actual published HTTPS Netlify URL. Add that same URL under allowed redirect URLs if your project's configuration requires it. This prevents confirmation links from sending you to a localhost URL.

Supabase Auth documentation: <https://supabase.com/docs/reference/javascript/auth-signup> and <https://supabase.com/docs/reference/javascript/auth-signinwithpassword>.

## 3. Add the two public environment variables to Netlify

1. Open Netlify and select the SceneSpeak site.
2. Go to **Site configuration → Environment variables** (the precise menu wording may vary).
3. Add:
   - `VITE_SUPABASE_URL` = the Supabase **Project URL**
   - `VITE_SUPABASE_ANON_KEY` = the Supabase **publishable key** (or legacy `anon` public key)
4. Trigger a new deploy. Vite embeds `VITE_*` values into the static build, so these variables are read during the build rather than at runtime. A deploy is required after changing them.

The project includes an `.env.example` for local development. Do not commit a real `.env` file.

## 4. Sync your phone and PC

1. Deploy the configured build and open the site on your phone.
2. Open **Profile → Supabase cloud sync** and create an account or sign in.
3. Before the first upload, download a local JSON backup from **Profile → Local data & backup** as an extra precaution.
4. On the device that has the most up-to-date learning history, choose **Upload this device**. This replaces the cloud snapshot with that device's current full backup.
5. On the PC, open the same published site, sign in with the same account, and choose **Merge from cloud & sync**. The app validates the downloaded snapshot, merges by record ID, and uploads the combined snapshot afterward.
6. Repeat **Merge from cloud & sync** on whichever device needs the latest merged data. Sign-in sessions persist in that browser, but each device has its own browser storage.

### What merge means

- The cloud snapshot is a versioned SceneSpeak backup containing progress, sessions, notes, favorites, locally saved scenes, review history, learning preferences, Minna sessions, JLPT attempts, imported lesson packs, and other records represented by the app backup schema.
- When a record uses the same ID on both devices, the cloud version takes precedence. Local records with different IDs are retained. Profile/settings are restored from the cloud snapshot during merge.
- The buttons are intentional safeguards; there is no silent last-write-wins sync in the background. Uploading replaces the cloud snapshot. Download a local JSON backup before first sync or before major changes.
- Gemini API keys and Supabase credentials are not included in learning backups. Configure Gemini separately on each device if you use those optional features.
- Supabase stores the backup JSON in one row per account. Keep the backup personal; anyone who can sign into the account may access it. Use a strong password and do not share it.

## Troubleshooting

- **Cloud sync setup message remains:** confirm the two Netlify environment variables are spelled exactly as shown and redeploy after saving them.
- **Table not found:** run `supabase/scenespeak_cloud_sync.sql` in the correct Supabase project.
- **Permission/RLS error:** confirm RLS is enabled, all four policies exist, the authenticated grants were applied, and you are signed in. Do not fix this by disabling RLS or adding a public policy.
- **Sign-up asks for email confirmation:** confirm the email first, then return and sign in.
- **No cloud backup yet:** upload from the device that contains your current progress first.
- **Data looks older after merge:** the snapshot from the cloud overwrites matching record IDs; use the device with the newest data to upload before merging from another device. Keep local JSON exports as checkpoints.

Supabase is a managed service, so you do not need to run your own web/API server. Its current plan limits and inactivity behavior can change; review the pricing page for your project before relying on it for long-term storage: <https://supabase.com/pricing>.
