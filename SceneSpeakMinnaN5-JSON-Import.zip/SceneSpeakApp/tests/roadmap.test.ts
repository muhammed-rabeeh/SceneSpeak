import { describe, expect, it } from 'vitest';
import { createGuidedRoadmap, getCurrentRoadmapDay, getRoadmapStudyDayCount, phaseForRoadmapDay, taskForRoadmapDay } from '../src/domain/roadmap';

describe('daily learning roadmap',()=>{
 const plan=createGuidedRoadmap({id:'test-roadmap',purpose:'travel',target:'travel-ready',targetDays:180,studyDaysPerWeek:5,dailyMinutes:15,learnerLevel:'Complete beginner',goal:'Handle travel conversations',startDate:'2026-01-01',createdAt:'2026-01-01T00:00:00.000Z'});
 it('creates a progressive roadmap that spans the entire timeline',()=>{
  expect(plan.phases.length).toBeGreaterThanOrEqual(6);
  expect(phaseForRoadmapDay(plan,1).title).toBe('Script, sounds and survival basics');
  expect(phaseForRoadmapDay(plan,23).title).toBe('Script, sounds and survival basics');
  expect(phaseForRoadmapDay(plan,24).title).toBe('Food, cafés and shopping');
  expect(phaseForRoadmapDay(plan,180).title).toBe('Travel-ready capstone and review');
  expect(plan.completedDayNumbers).toEqual([]);
  expect(getRoadmapStudyDayCount(plan)).toBe(128);
 });
 it('builds a different practical task for each study day and optional rest days',()=>{
  expect(taskForRoadmapDay(plan,1).route).toBe('/kana');
  expect(taskForRoadmapDay(plan,2).title).toBe('Vocabulary & kanji in context');
  expect(taskForRoadmapDay(plan,3).route).toBe('/grammar');
  expect(taskForRoadmapDay(plan,4).route).toBe('/listening');
  expect(taskForRoadmapDay(plan,5).route).toBe('/scenes');
  expect(taskForRoadmapDay(plan,1).successCheck.length).toBeGreaterThan(20);
  expect(taskForRoadmapDay(plan,1).estimatedMinutes).toBe(15);
  expect(taskForRoadmapDay(plan,1).cycleLabel).toBe('Learn the basics');
  expect(taskForRoadmapDay(plan,8).cycleLabel).toBe('Practise with support');
  expect(taskForRoadmapDay(plan,15).cycleLabel).toBe('Transfer to a new context');
  expect(taskForRoadmapDay(plan,22).cycleLabel).toBe('Retrieve and check');
  expect(taskForRoadmapDay(plan,6).isRestDay).toBe(true);
  expect(taskForRoadmapDay(plan,7).isRestDay).toBe(true);
 });
 it('clamps the current day to the plan range and works with calendar dates',()=>{
  expect(getCurrentRoadmapDay(plan,new Date('2025-12-31T10:00:00.000Z'))).toBe(1);
  expect(getCurrentRoadmapDay(plan,new Date('2026-01-01T10:00:00.000Z'))).toBe(1);
  expect(getCurrentRoadmapDay(plan,new Date('2026-01-08T10:00:00.000Z'))).toBe(8);
  expect(getCurrentRoadmapDay(plan,new Date('2027-01-01T10:00:00.000Z'))).toBe(180);
 });
 it('keeps higher JLPT roadmaps honest about built-in coverage',()=>{
  const n3=createGuidedRoadmap({id:'n3',purpose:'jlpt',target:'jlpt-n3',targetDays:730,studyDaysPerWeek:5,dailyMinutes:20,learnerLevel:'Complete beginner',goal:'Prepare for JLPT N3',startDate:'2026-01-01'});
  expect(n3.phases.some(p=>p.outcome.includes('built-in exam trainer remains N5-focused'))).toBe(true);
  expect(phaseForRoadmapDay(n3,730).title).toContain('N3 consolidation checkpoint');
 });
 it('adds advanced integration stages for long conversation/media paths',()=>{
  const conversation=createGuidedRoadmap({id:'long-conv',purpose:'conversation',target:'daily-conversation',targetDays:1095,studyDaysPerWeek:5,dailyMinutes:20,learnerLevel:'Complete beginner',goal:'Live in Japan and talk about a wide range of topics',startDate:'2026-01-01'});
  expect(conversation.phases.length).toBe(10);
  expect(conversation.phases.some(p=>p.title.includes('Advanced conversational range'))).toBe(true);
  const media=createGuidedRoadmap({id:'long-media',purpose:'media',target:'media-understanding',targetDays:730,studyDaysPerWeek:5,dailyMinutes:20,learnerLevel:'Beginner',goal:'Understand more anime dialogue',startDate:'2026-01-01'});
  expect(media.phases.some(p=>p.title.includes('Advanced authentic-media'))).toBe(true);
 });
 it('sequences higher JLPT targets through prerequisite levels',()=>{
  const n1=createGuidedRoadmap({id:'n1',purpose:'jlpt',target:'jlpt-n1',targetDays:1095,studyDaysPerWeek:6,dailyMinutes:30,learnerLevel:'Complete beginner',goal:'Prepare for JLPT N1',startDate:'2026-01-01'});
  expect(n1.phases.some(p=>p.title.includes('N5 foundations'))).toBe(true);
  expect(n1.phases.some(p=>p.title.includes('N4 everyday Japanese'))).toBe(true);
  expect(n1.phases.some(p=>p.title.includes('N3 independent Japanese'))).toBe(true);
  expect(n1.phases.some(p=>p.title.includes('N2 complex language'))).toBe(true);
  expect(n1.phases.some(p=>p.title.includes('N1 nuance and precision'))).toBe(true);
  expect(n1.phases.some(p=>p.outcome.includes('exam trainer remains N5-focused'))).toBe(true);
 });
});
