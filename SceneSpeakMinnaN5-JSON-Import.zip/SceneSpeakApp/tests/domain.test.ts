import { describe, expect, it } from 'vitest';
import { scheduleNextReview, isDue } from '../src/domain/scheduler';
import { applyPractice, emptyProgress, outcomeValue, boundedScore } from '../src/domain/scoring';
import { courseValidation, dialogueVariants, modules, scenes, phrases, grammarEntries } from '../src/data/course';
import { kanaUnique } from '../src/data/kana';
import { validateBackup } from '../src/services/storage';
import { GEMINI_MODELS, mapAiError, GeminiProvider, aiProvider } from '../src/services/ai';

describe('review scheduling heuristic', () => {
 const now=new Date('2026-01-01T12:00:00.000Z');
 it('uses shorter intervals after missed, revealed or hinted responses',()=>{
  expect(scheduleNextReview({outcome:'missed',now}).intervalDays).toBe(1);
  expect(scheduleNextReview({outcome:'revealed',now}).intervalDays).toBe(1);
  expect(scheduleNextReview({outcome:'hinted',now}).intervalDays).toBe(1);
  expect(scheduleNextReview({outcome:'hard',now}).intervalDays).toBe(2);
 });
 it('extends intervals for independent good/easy recall with a cap',()=>{
  expect(scheduleNextReview({outcome:'good',now}).intervalDays).toBe(4);
  expect(scheduleNextReview({outcome:'easy',successfulReviews:0,now}).intervalDays).toBe(7);
  expect(scheduleNextReview({outcome:'easy',successfulReviews:99,now}).intervalDays).toBe(21);
 });
 it('returns ISO dates and correctly identifies due time',()=>{
  const result=scheduleNextReview({outcome:'good',now});
  expect(result.nextReviewAt).toBe('2026-01-05T12:00:00.000Z');
  expect(isDue(result.nextReviewAt,new Date('2026-01-05T12:00:00.000Z'))).toBe(true);
 });
});

describe('skill scoring',()=>{
 it('does not count a revealed answer as an attempt or independent recall',()=>{
  const reveal=applyPractice(undefined,'p1','recall','revealed',new Date('2026-01-01T00:00:00.000Z'));
  expect(reveal.attempts).toBe(0);expect(reveal.correctWithoutHint).toBe(0);expect(reveal.correctWithHint).toBe(0);
  expect(reveal.recallScore).toBe(0);expect(reveal.history[0].result).toBe('revealed');
 });
 it('does not let answer exposure lower a previously earned skill score or reset the streak',()=>{
  const first=applyPractice(undefined,'p1','recall','independent',new Date('2026-01-01T00:00:00.000Z'));
  const second=applyPractice(first,'p1','recall','revealed',new Date('2026-01-02T00:00:00.000Z'));
  expect(second.recallScore).toBe(100);expect(second.attempts).toBe(1);expect(second.consecutiveSuccessfulReviews).toBe(1);
 });
 it('distinguishes independent and hinted responses',()=>{
  const first=applyPractice(undefined,'p1','recall','hinted');
  expect(first.attempts).toBe(1);expect(first.correctWithHint).toBe(1);expect(first.correctWithoutHint).toBe(0);expect(first.recallScore).toBe(55);
  const second=applyPractice(first,'p1','recall','independent');
  expect(second.correctWithoutHint).toBe(1);expect(second.consecutiveSuccessfulReviews).toBe(1);expect(second.recallScore).toBeGreaterThan(55);
 });
 it('keeps unrelated skill scores independent and clamps invalid values',()=>{
  const p=applyPractice(emptyProgress('p1'),'p1','listening','independent');
  expect(p.listeningScore).toBe(100);expect(p.recallScore).toBe(0);expect(outcomeValue('revealed')).toBe(0);
  expect(boundedScore(-20)).toBe(0);expect(boundedScore(190)).toBe(100);expect(boundedScore(Number.NaN)).toBe(0);
 });
});

describe('curated course integrity',()=>{
 it('has 12 modules, at least 30 playable scenes, and 250+ phrases',()=>{
  expect(modules).toHaveLength(12);expect(scenes.length).toBeGreaterThanOrEqual(30);expect(phrases.length).toBeGreaterThanOrEqual(250);expect(dialogueVariants.length).toBeGreaterThanOrEqual(100);
  expect(grammarEntries.length).toBeGreaterThanOrEqual(15);expect(courseValidation()).toEqual([]);
 });
 it('includes core phrases and complete kana families',()=>{
  const texts=new Set(phrases.map(p=>p.nativeScript));
  expect(texts.has('コーヒーをください')).toBe(true);expect(texts.has('水をください')).toBe(true);
  expect(texts.has('トイレはどこですか')).toBe(true);expect(texts.has('もう一度お願いします')).toBe(true);
  expect(kanaUnique.some(k=>k.character==='きゃ'&&k.kind==='hiragana')).toBe(true);
  expect(kanaUnique.some(k=>k.character==='ピョ'&&k.kind==='katakana')).toBe(true);
  expect(kanaUnique.some(k=>k.character==='っ'&&k.kind==='hiragana')).toBe(true);
  expect(kanaUnique.some(k=>k.character==='ー'&&k.kind==='katakana')).toBe(true);
 });
});

describe('backup schema validation',()=>{
 it('rejects arbitrary objects and wrong backup versions',()=>{
  expect(validateBackup({})).toMatchObject({ok:false});
  expect(validateBackup({schema:'scenespeak-backup',version:98})).toMatchObject({ok:false});
 });
 it('accepts an empty but structurally valid version-one backup',()=>{
  const value={schema:'scenespeak-backup',version:1,exportedAt:'2026-01-01T00:00:00.000Z',profile:{nativeLanguage:'English',targetLanguage:'Japanese',level:'Complete beginner',dailyGoalMinutes:10,goal:'Speak while traveling',onboardingComplete:false,showRomanization:true},settings:{selectedModel:'gemini-3.8-flash',aiEnabled:false},progress:[],sessions:[],favorites:[],notes:{},savedScenes:[],kanaProgress:{},grammarProgress:{},events:[],activeRoleplay:null};
  expect(validateBackup(value).ok).toBe(true);
 });
});


describe('Gemini provider configuration',()=>{
 it('keeps the requested model IDs centralized and defaults to Flash',()=>{
  expect(GEMINI_MODELS.map(m=>m.id)).toEqual(['gemini-4-argon','gemini-3.1-pro-preview','gemini-3.8-flash']);
  expect(GEMINI_MODELS.find(m=>m.id==='gemini-3.8-flash')?.badge).toBe('Default');
 });
 it('exposes an adapter and maps key errors without returning raw exception text',()=>{
  expect(aiProvider).toBeInstanceOf(GeminiProvider);
  const message=mapAiError(new Error('401 invalid API key: SECRET-DO-NOT-DISPLAY'));
  expect(message).toContain('Google rejected this API key');
  expect(message).not.toContain('SECRET-DO-NOT-DISPLAY');
 });
});
