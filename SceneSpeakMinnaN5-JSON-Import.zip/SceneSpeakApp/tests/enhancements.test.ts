import { describe, expect, it } from 'vitest';
import { BUILTIN_MINNA_PACK, minnaLessons, N5_SECTIONS, n5Questions, validateMinnaContent, validateMinnaPack, summarizeSpeakingEvidence, type SpeakingEvidence } from '../src/domain/enhancements';

function evidence(overrides: Partial<SpeakingEvidence> = {}): SpeakingEvidence {
  return {
    id: 'speech-1', phraseId: 'phrase-1', targetJapanese: 'コーヒーをください', targetMeaning: 'Coffee, please.',
    sceneId: 'cafe', context: 'Cafe', transcript: 'コーヒーをください', intentUnderstood: true,
    oneImprovement: 'Good.', grammarFeedback: 'Natural.', naturalAlternative: 'コーヒーをください',
    partnerReply: 'はい、どうぞ。', replyMeaning: 'Here you are.', hintLevel: 0,
    at: '2026-01-01T12:00:00.000Z', source: 'gemini-audio-understanding', independent: true, ...overrides,
  };
}

describe('Minna companion and JLPT N5 content', () => {
  it('contains all 25 companion lesson modules with required fields and original question data', () => {
    expect(minnaLessons).toHaveLength(25);
    expect(minnaLessons.every(lesson => lesson.vocabulary.length >= 10)).toBe(true);
    expect(minnaLessons.reduce((count, lesson) => count + lesson.vocabulary.length, 0)).toBeGreaterThanOrEqual(250);
    expect(minnaLessons.filter(lesson => lesson.examAlignment === 'n5-core')).toHaveLength(15);
    expect(minnaLessons.filter(lesson => lesson.examAlignment === 'bridge')).toHaveLength(10);
    expect(validateMinnaContent()).toEqual([]);
    expect(n5Questions.length).toBeGreaterThanOrEqual(30);
    for (const question of n5Questions) {
      expect(question.options.length).toBeGreaterThanOrEqual(2);
      expect(question.answerIndex).toBeGreaterThanOrEqual(0);
      expect(question.answerIndex).toBeLessThan(question.options.length);
      expect(question.explanation.length).toBeGreaterThan(0);
    }
  });
  it('exports a valid built-in JSON pack and rejects malformed imported packs', () => {
    const checked = validateMinnaPack(BUILTIN_MINNA_PACK);
    expect(checked.ok).toBe(true);
    if (checked.ok) {
      expect(checked.data.lessons).toHaveLength(25);
      expect(checked.data.lessons[0].vocabulary.every(item => item.source === 'user-imported')).toBe(true);
    }
    const malformed = structuredClone(BUILTIN_MINNA_PACK) as typeof BUILTIN_MINNA_PACK;
    malformed.lessons[0].listeningQuestion.answerIndex = 99;
    const rejected = validateMinnaPack(malformed);
    expect(rejected.ok).toBe(false);
    const emptyDescription = structuredClone(BUILTIN_MINNA_PACK) as typeof BUILTIN_MINNA_PACK;
    emptyDescription.description = '  ';
    expect(validateMinnaPack(emptyDescription).ok).toBe(false);
  });
  it('uses the official N5 answer-time allocations', () => {
    expect(N5_SECTIONS.map(section => [section.id, section.minutes])).toEqual([
      ['vocabulary', 20], ['grammar-reading', 40], ['listening', 30],
    ]);
  });
});

describe('Memory-to-Mouth independent-use threshold', () => {
  it('does not count failures or hinted responses as independent success', () => {
    const records = [
      evidence({ id: 'a', context: 'Cafe', at: '2026-01-01T12:00:00Z' }),
      evidence({ id: 'b', context: 'Bakery', at: '2026-01-02T12:00:00Z', intentUnderstood: false, independent: false }),
      evidence({ id: 'c', context: 'Store', at: '2026-01-03T12:00:00Z', hintLevel: 2, independent: false }),
    ];
    const summary = summarizeSpeakingEvidence(records);
    expect(summary.attempts).toBe(3);
    expect(summary.independentSuccesses).toBe(1);
    expect(summary.usableIndependently).toBe(false);
  });
  it('requires two successes in two contexts on two dates', () => {
    expect(summarizeSpeakingEvidence([
      evidence({ id: 'a', context: 'Cafe', at: '2026-01-01T12:00:00Z' }),
      evidence({ id: 'b', context: 'Cafe', at: '2026-01-02T12:00:00Z' }),
    ]).usableIndependently).toBe(false);
    expect(summarizeSpeakingEvidence([
      evidence({ id: 'a', context: 'Cafe', at: '2026-01-01T12:00:00Z' }),
      evidence({ id: 'b', context: 'Bakery', at: '2026-01-01T17:00:00Z' }),
    ]).usableIndependently).toBe(false);
    expect(summarizeSpeakingEvidence([
      evidence({ id: 'a', context: 'Cafe', at: '2026-01-01T12:00:00Z' }),
      evidence({ id: 'b', context: 'Bakery', at: '2026-01-02T12:00:00Z' }),
    ]).usableIndependently).toBe(true);
  });
  it('requires transcript-confirmed, unedited evidence for the independent threshold', () => {
    const records = [
      evidence({ id: 'a', context: 'Cafe', at: '2026-01-01T12:00:00Z' }),
      evidence({ id: 'b', context: 'Bakery', at: '2026-01-02T12:00:00Z', transcriptEdited: true, independent: true }),
    ];
    expect(summarizeSpeakingEvidence(records).usableIndependently).toBe(false);
  });

});
