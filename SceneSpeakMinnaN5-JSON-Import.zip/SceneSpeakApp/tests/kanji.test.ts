import { describe, expect, it } from 'vitest';
import { N5_KANJI, getKanjiForLesson, getKanjiForModule, validateKanjiData } from '../src/data/kanji';

describe('curated kanji study data', () => {
  it('has unique stable IDs and complete example records', () => {
    expect(validateKanjiData()).toEqual([]);
    expect(N5_KANJI.length).toBeGreaterThanOrEqual(100);
  });
  it('links kanji to each of the 25 Minna lesson numbers', () => {
    for (let lesson = 1; lesson <= 25; lesson += 1) expect(getKanjiForLesson(lesson).length).toBeGreaterThan(0);
  });
  it('links kanji into practical scene modules', () => {
    for (const moduleId of ['m1','m2','m3','m4','m5','m6','m7','m8','m9','m10','m11','m12']) {
      expect(getKanjiForModule(moduleId).length).toBeGreaterThan(0);
    }
  });
  it('provides an example reading for all kanji', () => {
    expect(N5_KANJI.every(k => k.example && k.exampleReading && k.exampleMeaning)).toBe(true);
  });
});
