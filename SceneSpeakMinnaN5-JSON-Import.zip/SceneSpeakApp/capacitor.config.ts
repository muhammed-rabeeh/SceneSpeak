import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'app.scenespeak.japanese', appName: 'SceneSpeak', webDir: 'dist',
  backgroundColor: '#fff7ef', server: { androidScheme: 'https' }
};
export default config;
